#!/usr/bin/env bash
# Iran Relay 1.0.0: isolated Xray REALITY transport; English terminal manager.
set -Eeuo pipefail
umask 077
if [[ ${EUID} -ne 0 ]]; then
  echo 'Run with sudo: sudo bash iran-relay-oneclick.sh manager-install' >&2
  exit 1
fi
if [[ ${1:-menu} == manager-install ]]; then
  if ! command -v python3 >/dev/null || ! command -v curl >/dev/null || ! command -v unzip >/dev/null || ! command -v ip >/dev/null || ! command -v tmux >/dev/null || [[ ! -s /etc/ssl/certs/ca-certificates.crt ]]; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq
    apt-get install -y -qq --no-install-recommends python3 ca-certificates curl unzip iproute2 tmux
  fi
fi
export IR_RELAY_SOURCE
IR_RELAY_SOURCE=$(readlink -f -- "${BASH_SOURCE[0]}")
exec python3 - "$@" <<'IRAN_RELAY_PYTHON'
import argparse, base64, contextlib, copy, fcntl, hashlib, ipaddress, io, json, os, pathlib, platform, re, secrets, shutil, socket, ssl, subprocess, sys, tempfile, termios, time, urllib.parse, uuid, zipfile
VERSION='1.0.0'
CORE_VERSION='v26.3.27'
ROOT=pathlib.Path('/opt/iran-relay')
CURRENT=ROOT/'current'
BIN=ROOT/'xray'
MANAGER=pathlib.Path('/usr/local/sbin/iran-relay')
UNIT=pathlib.Path('/etc/systemd/system/iran-relay.service')
SERVICE='iran-relay.service'
class Failure(Exception): pass
class Cancelled(Exception): pass

def run(args,timeout=30,check=True,**kwargs):
    try: p=subprocess.run([str(x) for x in args],capture_output=True,text=True,timeout=timeout,**kwargs)
    except subprocess.TimeoutExpired: raise Failure('Command timed out: '+str(args[0])+'; run iran-relay doctor.')
    if check and p.returncode: raise Failure(str(args[0])+' failed (exit '+str(p.returncode)+'). Run iran-relay doctor; credentials are not printed in errors.')
    return p

def atomic(path,text,mode=0o600):
    path=pathlib.Path(path)
    if path.is_symlink(): raise Failure('Refusing symlink: '+str(path))
    fd,name=tempfile.mkstemp(prefix='.'+path.name,dir=path.parent)
    try:
        with os.fdopen(fd,'w') as f: f.write(text); f.flush(); os.fsync(f.fileno())
        os.chmod(name,mode); os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)

def host(value):
    if not value or len(value)>253:raise Failure('Missing or invalid hostname/IP.')
    try:return str(ipaddress.ip_address(value))
    except ValueError:pass
    value=value.lower().rstrip('.')
    if not all(re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?',p) for p in value.split('.')) or '.' not in value:raise Failure('Invalid hostname; paste a hostname without https:// or a path.')
    return value

def public_ip(value):
    try:a=ipaddress.ip_address(value)
    except ValueError:raise Failure('Enter an IPv4 or IPv6 address.')
    if not a.is_global or a.is_multicast:raise Failure('A public unicast IP address is required.')
    return str(a)

def resolve(value):
    value=host(value)
    try:return [public_ip(value)]
    except Failure:
        try:ipaddress.ip_address(value)
        except ValueError:pass
        else:raise
    code='import socket,json,sys;print(json.dumps(sorted({x[4][0] for x in socket.getaddrinfo(sys.argv[1],None,type=socket.SOCK_STREAM)})))'
    p=run([sys.executable,'-c',code,value],timeout=12,check=False)
    if p.returncode:raise Failure('DNS failed for '+value+'. Check the server resolver.')
    addresses=json.loads(p.stdout)
    if not addresses:raise Failure('DNS returned no addresses for '+value)
    # Reject mixed private/public answers as well as private-only answers.
    return sorted({public_ip(a) for a in addresses},key=lambda a:(':' in a,a))

def port(value):
    try:p=int(value)
    except (TypeError,ValueError):raise Failure('Port must be an integer.')
    if not 1<=p<=65535:raise Failure('Port must be 1..65535.')
    return p

def uri(value):
    value=value.strip()
    if len(value)>8192 or any(c.isspace() for c in value):raise Failure('Paste one complete config link with no spaces or line wrapping.')
    try:
        u=urllib.parse.urlsplit(value); p=port(u.port); h=host(u.hostname)
    except (ValueError,TypeError):raise Failure('Invalid config link address/port.')
    if u.scheme not in ('vless','hysteria2','hy2','anytls','ss'):raise Failure('Supported links: VLESS REALITY, Hysteria 2, AnyTLS, and Shadowsocks TLS.')
    if not u.username or u.password is not None:raise Failure('Unexpected credential format.')
    q={}
    for k,v in urllib.parse.parse_qsl(u.query,keep_blank_values=True):
        if k in q:raise Failure('Duplicate query field: '+k)
        q[k]=v
    if q.get('insecure','0').lower() not in ('0','false',''):raise Failure('insecure=1 is not accepted. Use a verified certificate or pinSHA256.')
    if u.scheme=='vless':
        if q.get('security')!='reality' or q.get('type','tcp') not in ('tcp','raw'):raise Failure('VLESS links must use TCP/RAW + REALITY.')
        try:uuid.UUID(urllib.parse.unquote(u.username))
        except ValueError:raise Failure('VLESS UUID is invalid.')
        if q.get('encryption','none')!='none' or q.get('flow','') not in ('','xtls-rprx-vision'):raise Failure('Unsupported VLESS encryption/flow.')
        if not q.get('sni') or not re.fullmatch(r'[A-Za-z0-9_-]{43}',q.get('pbk','')):raise Failure('REALITY link requires sni and a valid pbk.')
        host(q['sni'])
        if not re.fullmatch(r'(?:[0-9a-fA-F]{2}){0,8}',q.get('sid','')):raise Failure('Invalid REALITY short ID.')
        # Preserve the fingerprint for end clients; the outer tunnel always uses chrome.
    elif u.scheme in ('hysteria2','hy2','anytls'):
        if 'sni' not in q:
            try:ipaddress.ip_address(h)
            except ValueError:q['sni']=h
            else:raise Failure('TLS config using an IP must include an explicit sni.')
        host(q['sni'])
        if q.get('obfs') and q['obfs']!='salamander':raise Failure('Unsupported Hysteria obfuscation.')
        if q.get('obfs')=='salamander' and not q.get('obfs-password'):raise Failure('Salamander password is missing.')
        if q.get('pinSHA256') and not re.fullmatch(r'[0-9a-fA-F]{64}',q['pinSHA256']):raise Failure('Invalid certificate pin SHA-256.')
        if 'mport' in q:raise Failure('Hysteria port hopping is not supported in a fixed-port relay.')
    else:
        plugin=q.get('plugin','')
        if not plugin.startswith('v2ray-plugin;') or 'tls' not in plugin.split(';'):raise Failure('Shadowsocks must include the TLS v2ray-plugin used by your existing script.')
        if not any(x.startswith('host=') for x in plugin.split(';')):raise Failure('Shadowsocks TLS plugin host is missing.')
        host(next(x[5:] for x in plugin.split(';') if x.startswith('host=')))
        try:decoded=base64.urlsafe_b64decode(u.username+'='*((-len(u.username))%4)).decode()
        except Exception:raise Failure('Invalid Shadowsocks credentials encoding.')
        if ':' not in decoded:raise Failure('Invalid Shadowsocks method/password.')
    return dict(link=value,scheme=u.scheme,host=h,port=p,query=q,network='udp' if u.scheme in ('hy2','hysteria2') else 'tcp')

def outbound(link,address=None,tag='outer'):
    n=uri(link)
    if n['scheme']!='vless' or n['query'].get('flow')!='xtls-rprx-vision':raise Failure('The outer tunnel needs a VLESS REALITY + Vision link from the foreign server.')
    q=n['query']; u=urllib.parse.urlsplit(link)
    rs={'fingerprint':'chrome','serverName':q['sni'],'password':q['pbk'],'shortId':q.get('sid',''),'spiderX':q.get('spx','/')}
    if q.get('pqv'):rs['mldsa65Verify']=q['pqv']
    return {'tag':tag,'protocol':'vless','settings':{'vnext':[{'address':address or n['host'],'port':n['port'],'users':[{'id':urllib.parse.unquote(u.username),'encryption':'none','flow':'xtls-rprx-vision-udp443'}]}]},'streamSettings':{'network':'tcp','security':'reality','realitySettings':rs},'mux':{'enabled':False}}

def rewritten(link,endpoint,local_port):
    n=uri(link);u=urllib.parse.urlsplit(link);a='['+endpoint+']' if ':' in endpoint else endpoint
    return urllib.parse.urlunsplit((u.scheme,u.netloc.rsplit('@',1)[0]+'@'+a+':'+str(local_port),u.path,urllib.parse.urlencode(n['query']),urllib.parse.quote('IR-'+urllib.parse.unquote(u.fragment or n['scheme']),safe='')))

def keypair():
    result=run([BIN,'x25519'],timeout=10).stdout
    values={k.lower().replace(' ',''):v.strip() for line in result.splitlines() if ':' in line for k,v in [line.split(':',1)]}
    priv=values.get('privatekey');pub=values.get('password(publickey)') or values.get('password') or values.get('publickey')
    if not all(re.fullmatch(r'[A-Za-z0-9_-]{43}',x or '') for x in (priv,pub)):raise Failure('Unexpected Xray key format.')
    return {'private_key':priv,'public_key':pub,'uuid':str(uuid.uuid4()),'short_id':secrets.token_hex(8)}

def exported(m,endpoint):
    if uri(m['link'])['scheme']!='vless':return rewritten(m['link'],endpoint,m['local_port'])
    q=uri(m['link'])['query'];q={k:q[k] for k in ('sni',) if k in q}
    q.update({'encryption':'none','security':'reality','type':'tcp','flow':'xtls-rprx-vision','fp':'chrome','pbk':m['identity']['public_key'],'sid':m['identity']['short_id'],'spx':'/'})
    address='['+endpoint+']' if ':' in endpoint else endpoint
    return 'vless://'+m['identity']['uuid']+'@'+address+':'+str(m['local_port'])+'?'+urllib.parse.urlencode(q)+'#'+urllib.parse.quote('IR-REALITY-'+str(m['local_port']))

def config(state,listen=None):
    ins=[];outs=[{'tag':'block','protocol':'blackhole'}];rules=[]
    for g in state['groups']:
        tag='outer-'+g['name'];outs.append(outbound(g['transport'],g['transport_ip'],tag))
        for index,m in enumerate(g['maps']):
            itag=g['name']+'-'+str(index);n=uri(m['link'])
            if n['scheme']=='vless':
                key=m['identity'];target_tag=itag+'-tls-target'
                ins.append({'tag':itag,'listen':listen or ('::' if ':' in state['endpoint'] else '0.0.0.0'),'port':m['local_port'],'protocol':'vless','settings':{'clients':[{'id':key['uuid'],'flow':'xtls-rprx-vision'}],'decryption':'none'},'streamSettings':{'network':'tcp','security':'reality','realitySettings':{'target':'127.0.0.1:'+str(m['helper_port']),'serverNames':[n['query']['sni']],'privateKey':key['private_key'],'shortIds':[key['short_id']]}}})
                # TLS camouflage target is reached through the authenticated foreign
                # tunnel, so blocked target DNS/direct HTTPS in Iran is not required.
                ins.append({'tag':target_tag,'listen':'127.0.0.1','port':m['helper_port'],'protocol':'dokodemo-door','settings':{'address':n['query']['sni'],'port':443,'network':'tcp','followRedirect':False}})
                rules.append({'type':'field','inboundTag':[target_tag],'outboundTag':tag})
            else:
                ins.append({'tag':itag,'listen':listen or ('::' if ':' in state['endpoint'] else '0.0.0.0'),'port':m['local_port'],'protocol':'dokodemo-door','settings':{'address':m['target_ip'],'port':m['remote_port'],'network':m['network'],'followRedirect':False},'sniffing':{'enabled':False}})
            rules.append({'type':'field','inboundTag':[itag],'outboundTag':tag})
    return {'log':{'access':'none','loglevel':'warning'},'inbounds':ins,'outbounds':outs,'routing':{'domainStrategy':'AsIs','rules':rules}}

UNIT_TEXT='''[Unit]
Description=Iran encrypted fixed-port REALITY relay
After=network.target
StartLimitIntervalSec=60
StartLimitBurst=10
[Service]
Type=simple
DynamicUser=yes
ExecStart=/opt/iran-relay/xray run -c /opt/iran-relay/current/config.json
Restart=on-failure
RestartSec=5
TimeoutStartSec=15
TimeoutStopSec=15
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=strict
ProtectHome=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX AF_NETLINK
RestrictSUIDSGID=yes
LockPersonality=yes
UMask=0077
LimitNOFILE=65536
[Install]
WantedBy=multi-user.target
'''

@contextlib.contextmanager
def terminal(secret=False):
    try:f=io.TextIOWrapper(io.FileIO('/dev/tty','r+'),encoding='utf-8',write_through=True)
    except OSError:raise Failure('No interactive terminal. Install the manager first, then run sudo iran-relay setup as a separate command.')
    old=termios.tcgetattr(f.fileno());new=copy.deepcopy(old)
    new[0]|=termios.ICRNL;new[0]&=~(termios.IGNCR|termios.INLCR)
    new[3]|=termios.ICANON|termios.ISIG
    if secret:new[3]&=~termios.ECHO
    else:new[3]|=termios.ECHO
    termios.tcsetattr(f.fileno(),termios.TCSANOW,new)
    try:yield f
    finally:termios.tcsetattr(f.fileno(),termios.TCSANOW,old);f.close()

def ask(label,default='',secret=False):
    with terminal(secret) as f:
        f.write(label+(' ['+str(default)+']' if default!='' else '')+' (q=cancel): ');f.flush();v=f.readline()
        if secret:f.write('\n');f.flush()
    if not v or v.strip().lower()=='q':raise Cancelled()
    return v.strip() or str(default)

def ask_valid(label,validator,default=''):
    while True:
        try:return validator(ask(label,default))
        except Failure as e:print('INPUT: '+str(e),flush=True)

def links_input():
    values=[]
    with terminal(True) as f:
        f.write('Paste foreign config links, ONE per line; type done on a new line. q cancels. Input is hidden.\n');f.flush()
        while True:
            raw=f.readline()
            if not raw:raise Cancelled()
            v=raw.strip()
            if v.lower()=='q':raise Cancelled()
            if v.lower()=='done':break
            if not v:continue
            try:uri(v)
            except Failure as e:f.write('INPUT: '+str(e)+'\n');f.flush();continue
            if v not in values:values.append(v)
            f.write('Accepted link '+str(len(values))+'\n');f.flush()
            if len(values)>64:raise Failure('At most 64 links per group.')
    if not values:raise Failure('No links entered.')
    return values

def load():
    if not CURRENT.exists():return {'version':VERSION,'endpoint':'','groups':[],'ufw_owned':[]}
    return json.loads((CURRENT/'state.json').read_text())

def occupied(p,network,owned=False,family=socket.AF_INET):
    if owned:return False
    with socket.socket(family,socket.SOCK_DGRAM if network=='udp' else socket.SOCK_STREAM) as s:
        try:s.bind(('::' if family==socket.AF_INET6 else '0.0.0.0',p))
        except OSError:return True
    return False

def free(network,used,family=socket.AF_INET):
    for _ in range(256):
        p=secrets.randbelow(40000)+20000
        if (p,network) not in used and not occupied(p,network,family=family):return p
    raise Failure('No free port found.')

def detect():
    for url in ('https://api.ipify.org','https://ifconfig.co/ip'):
        try:return public_ip(run(['curl','-4','-fsS','--noproxy','*','--connect-timeout','4','--max-time','6',url],timeout=8).stdout.strip())
        except Failure:pass
    return ''

def choose_ip(value,endpoint):
    addresses=resolve(value)
    addresses=[a for a in addresses if a!=endpoint]
    if not addresses:raise Failure('Remote endpoint resolves to the Iran IP. Restore foreign DNS; do not point foreign certificate domains to Iran.')
    if len(addresses)==1:return addresses[0]
    print('Resolved public addresses for '+value+': '+', '.join(addresses),flush=True)
    return ask_valid('Choose a reachable foreign address',lambda v:v if v in addresses else invalid('Choose one of the resolved addresses.'),addresses[0])

def invalid(message):raise Failure(message)

def download():
    if BIN.is_file():
        receipt=json.loads((ROOT/'core-receipt.json').read_text())
        if hashlib.sha256(BIN.read_bytes()).hexdigest()!=receipt['binary_sha256']:raise Failure('Installed relay core hash changed; stopped before execution.')
        version=run([BIN,'version'],timeout=10).stdout
        if ('Xray '+CORE_VERSION[1:]+' ') not in version:raise Failure('Unexpected installed core version. Reinstall this relay manager/core explicitly.')
        return
    arch={'x86_64':'64','aarch64':'arm64-v8a'}.get(platform.machine())
    if not arch:raise Failure('Supported architectures: amd64 and arm64.')
    print('Downloading official Xray '+CORE_VERSION+' with SHA-256 verification ...',flush=True)
    def get(url,dest=None):
        args=['curl','-fLsS','--noproxy','*','--proto','=https','--proto-redir','=https','--retry','2','--connect-timeout','10','--max-time','120']
        if dest:args+=['-o',str(dest)]
        args+=[url]
        return run(args,timeout=390).stdout
    release=json.loads(get('https://api.github.com/repos/XTLS/Xray-core/releases/tags/'+CORE_VERSION))
    if release.get('draft') or release.get('prerelease') or release.get('tag_name')!=CORE_VERSION:raise Failure('Expected stable official release not found.')
    asset=next((a for a in release.get('assets',[]) if a['name']=='Xray-linux-'+arch+'.zip'),None)
    if not asset or not re.fullmatch(r'sha256:[0-9a-f]{64}',asset.get('digest') or ''):raise Failure('Official release asset SHA-256 is unavailable. Unverified downloads are refused.')
    url=asset['browser_download_url']
    if not url.startswith('https://github.com/XTLS/Xray-core/releases/download/'+CORE_VERSION+'/'):raise Failure('Unexpected asset origin.')
    with tempfile.TemporaryDirectory(prefix='iran-core-',dir=ROOT) as d:
        p=pathlib.Path(d);get(url,p/'core.zip')
        if 'sha256:'+hashlib.sha256((p/'core.zip').read_bytes()).hexdigest()!=asset['digest']:raise Failure('Official Xray archive hash mismatch.')
        with zipfile.ZipFile(p/'core.zip') as z:(p/'xray').write_bytes(z.read('xray'))
        (p/'xray').chmod(0o755);run([p/'xray','version'],timeout=10)
        (p/'xray').replace(BIN)
        atomic(ROOT/'core-receipt.json',json.dumps({'version':CORE_VERSION,'archive_sha256':asset['digest'],'binary_sha256':hashlib.sha256(BIN.read_bytes()).hexdigest()},indent=2))

def config_test(path):run([BIN,'run','-test','-c',path],timeout=20)

@contextlib.contextmanager
def probe(cfg):
    with tempfile.TemporaryDirectory(prefix='iran-probe-',dir=ROOT) as d:
        p=pathlib.Path(d);atomic(p/'config.json',json.dumps(cfg));config_test(p/'config.json')
        with open(p/'log','w') as log:
            process=subprocess.Popen([str(BIN),'run','-c',str(p/'config.json')],stdout=log,stderr=log)
            try:
                deadline=time.monotonic()+5
                while time.monotonic()<deadline:
                    if process.poll() is not None:raise Failure('Temporary relay core exited; config was not activated.')
                    ports=[x['port'] for x in cfg['inbounds'] if x.get('protocol')=='socks']
                    if not ports:break
                    try:
                        with socket.create_connection(('127.0.0.1',ports[0]),timeout=.2):break
                    except OSError:time.sleep(.05)
                else:raise Failure('Temporary test listener did not start.')
                yield process
            finally:
                if process.poll() is None:
                    process.terminate()
                    try:process.wait(timeout=4)
                    except subprocess.TimeoutExpired:process.kill();process.wait()

def socks_test(group):
    with socket.socket() as s:s.bind(('127.0.0.1',0));p=s.getsockname()[1]
    cfg={'log':{'access':'none','loglevel':'warning'},'inbounds':[{'listen':'127.0.0.1','port':p,'protocol':'socks','settings':{'auth':'noauth'}}],'outbounds':[outbound(group['transport'],group['transport_ip'])]}
    with probe(cfg):
        for url in ('https://www.google.com/generate_204','https://www.cloudflare.com/cdn-cgi/trace'):
            result=run(['curl','-fsS','--noproxy','','--proxy','socks5h://127.0.0.1:'+str(p),'--connect-timeout','6','--max-time','12','-o','/dev/null',url],timeout=15,check=False)
            if result.returncode==0:print('PASS outer REALITY authentication + HTTPS egress: '+group['name'],flush=True);return
    raise Failure('Outer REALITY authentication/HTTPS failed for '+group['name']+'. Check IP, TCP port, SNI, pbk, UUID and the Iran-to-foreign path. A successful foreign-local test is not sufficient.')

def socks_connect(s,ip,p):
    def exact(n):
        out=b''
        while len(out)<n:
            v=s.recv(n-len(out))
            if not v:raise OSError('SOCKS closed')
            out+=v
        return out
    s.sendall(b'\x05\x01\x00')
    if exact(2)!=b'\x05\x00':raise OSError('SOCKS greeting')
    try:
        addr=ipaddress.ip_address(ip);wire=(b'\x01' if addr.version==4 else b'\x04')+addr.packed
    except ValueError:
        name=host(ip).encode('idna');wire=b'\x03'+bytes([len(name)])+name
    s.sendall(b'\x05\x01\x00'+wire+p.to_bytes(2,'big'))
    header=exact(4)
    if header[1]!=0:raise OSError('Foreign target TCP connect rejected')
    length={1:4,4:16}.get(header[3])
    if header[3]==3:length=exact(1)[0]
    if length is None:raise OSError('SOCKS address')
    exact(length+2)

def camouflage_checks(group,socks_port):
    names={uri(mp['link'])['query']['sni'] for mp in group['maps'] if uri(mp['link'])['scheme']=='vless'}
    for name in sorted(names):
        try:
            with socket.create_connection(('127.0.0.1',socks_port),timeout=10) as s:
                s.settimeout(10);socks_connect(s,name,443)
                ctx=ssl.create_default_context();ctx.minimum_version=ssl.TLSVersion.TLSv1_3;ctx.set_alpn_protocols(['h2'])
                with ctx.wrap_socket(s,server_hostname=name) as tls:
                    if tls.version()!='TLSv1.3' or tls.selected_alpn_protocol()!='h2':raise Failure('REALITY camouflage target lacks TLS 1.3/h2: '+name)
        except OSError:raise Failure('REALITY camouflage target DNS/TLS/certificate failed through foreign tunnel: '+name)
        print('PASS camouflage target through encrypted tunnel: '+name+' | TLS 1.3, verified hostname/certificate, ALPN h2',flush=True)

def target_checks(group):
    with socket.socket() as s:s.bind(('127.0.0.1',0));p=s.getsockname()[1]
    cfg={'log':{'access':'none','loglevel':'warning'},'inbounds':[{'listen':'127.0.0.1','port':p,'protocol':'socks','settings':{'auth':'noauth'}}],'outbounds':[outbound(group['transport'],group['transport_ip'])]}
    with probe(cfg):
        camouflage_checks(group,p)
        for m in group['maps']:
            if uri(m['link'])['scheme']=='vless':
                print('REALITY will terminate on Iran and route through the foreign tunnel; end-client test is required.',flush=True);continue
            if m['network']=='udp':
                print('NOT VERIFIED: '+m['label']+' UDP application authentication; test Hysteria from a client after activation.',flush=True);continue
            try:
                with socket.create_connection(('127.0.0.1',p),timeout=8) as s:
                    s.settimeout(8);socks_connect(s,m['target_ip'],m['remote_port'])
                    node=uri(m['link']);sni=node['query'].get('sni')
                    if node['scheme']=='ss':sni=next(x[5:] for x in node['query']['plugin'].split(';') if x.startswith('host='))
                    with ssl.create_default_context().wrap_socket(s,server_hostname=sni):pass
            except OSError:raise Failure('Foreign TCP/TLS target unavailable through the tunnel: '+m['label']+'. Check service/provider firewall and public-IP hairpin/NAT. Previous relay settings are retained.')
            print('PASS foreign TCP + verified TLS reachable through encrypted tunnel: '+m['label']+' (application authentication still requires client test)',flush=True)

def rules_for(state):return {str(m['local_port'])+'/'+m['network'] for g in state['groups'] for m in g['maps']}

def ufw_active():
    return bool(shutil.which('ufw')) and 'Status: active' in run(['ufw','status'],check=False,env={**os.environ,'LC_ALL':'C'}).stdout

def add_rules(state,old):
    owned=set(old.get('ufw_owned',[])); added=[]
    if ufw_active():
        status=run(['ufw','status','numbered'],env={**os.environ,'LC_ALL':'C'}).stdout
        try:
            for r in sorted(rules_for(state)-rules_for(old)):
                if re.search(r'\b'+re.escape(r)+r'\b',status):print('Existing UFW rule retained for '+r+'; check source/family coverage.',flush=True);continue
                run(['ufw','allow',r,'comment','iran-relay']);owned.add(r);added.append(r)
        except BaseException:
            remove_rules(added)
            raise
    state['ufw_owned']=sorted(owned)
    return added

def remove_rules(rules):
    if not shutil.which('ufw'):return
    status=run(['ufw','status','numbered'],check=False,env={**os.environ,'LC_ALL':'C'}).stdout
    indexes=[]
    for line in status.splitlines():
        match=re.match(r'\[\s*(\d+)\]',line)
        if match and '# iran-relay' in line and any(re.search(r'\b'+re.escape(r)+r'\b',line) for r in rules):indexes.append(int(match[1]))
    # Numbered deletion avoids deleting similarly named administrator rules.
    for index in sorted(set(indexes),reverse=True):run(['ufw','--force','delete',str(index)],check=False)

def swap(path):
    tmp=ROOT/'.current-next';tmp.unlink(missing_ok=True);tmp.symlink_to(path);tmp.replace(CURRENT)

def activate(state,old):
    print('Activating isolated relay service; checking REALITY profiles ...',flush=True)
    cfg=config(state);old_target=CURRENT.resolve() if CURRENT.is_symlink() else None
    prior_unit=UNIT.read_text() if UNIT.exists() else None
    was_active=run(['systemctl','is-active','--quiet',SERVICE],check=False).returncode==0
    was_enabled=run(['systemctl','is-enabled','--quiet',SERVICE],check=False).returncode==0
    with tempfile.TemporaryDirectory(prefix='candidate-',dir=ROOT) as d:
        testpath=pathlib.Path(d)/'config.json';atomic(testpath,json.dumps(cfg));config_test(testpath)
    release=ROOT/('release-'+str(int(time.time()))+'-'+secrets.token_hex(3));release.mkdir(mode=0o755)
    added=[]
    try:
        added=add_rules(state,old)
        atomic(release/'state.json',json.dumps(state,indent=2),0o600)
        # Config has credentials; only the dedicated DynamicUser service can read it
        # via LoadCredential, rather than granting read access to all local users.
        atomic(release/'config.json',json.dumps(cfg,indent=2),0o600)
        atomic(release/'links.txt','\n'.join(exported(m,state['endpoint']) for g in state['groups'] for m in g['maps'])+'\n')
        text=UNIT_TEXT.replace('ExecStart=/opt/iran-relay/xray run -c /opt/iran-relay/current/config.json','LoadCredential=relay-config:/opt/iran-relay/current/config.json\nExecStart=/opt/iran-relay/xray run -c ${CREDENTIALS_DIRECTORY}/relay-config')
        atomic(UNIT,text,0o644);swap(release)
        run(['systemctl','daemon-reload']);run(['systemctl','restart',SERVICE],timeout=25)
        time.sleep(.5)
        if run(['systemctl','is-active','--quiet',SERVICE],check=False).returncode:raise Failure('Relay service failed after activation.')
        for group in state['groups']:
            for mapping in group['maps']:
                if uri(mapping['link'])['scheme']=='vless':
                    socks_test({'name':'Iran REALITY '+str(mapping['local_port']),'transport':exported(mapping,'127.0.0.1'),'transport_ip':'127.0.0.1'})
        run(['systemctl','enable',SERVICE])
    except BaseException:
        remove_rules(added)
        if old_target:swap(old_target)
        else:CURRENT.unlink(missing_ok=True)
        if prior_unit is not None:atomic(UNIT,prior_unit,0o644)
        else:UNIT.unlink(missing_ok=True)
        run(['systemctl','daemon-reload'],check=False)
        if was_active:run(['systemctl','restart',SERVICE],timeout=25,check=False)
        else:run(['systemctl','stop',SERVICE],timeout=25,check=False)
        if not was_enabled:run(['systemctl','disable',SERVICE],check=False)
        shutil.rmtree(release,ignore_errors=True)
        raise
    if old_target:
        previous=ROOT/'previous';previous.unlink(missing_ok=True);previous.symlink_to(old_target)
    obsolete=set(old.get('ufw_owned',[]))-rules_for(state)
    remove_rules(obsolete)
    state['ufw_owned']=sorted(set(state['ufw_owned'])-obsolete)
    atomic(release/'state.json',json.dumps(state,indent=2))
    print('READY: encrypted fixed-port relay. Provider firewall/NAT must allow: '+', '.join(sorted(rules_for(state))),flush=True)
    print('Local checks cannot prove client-to-Iran reachability or UDP application health. Import and test each link from another network.',flush=True)
    show_links()

def setup():
    old=load();state=copy.deepcopy(old)
    print('IRAN RELAY '+VERSION+' | Add/update one foreign-server group. q cancels; links are hidden.',flush=True)
    print('Iran-to-foreign uses REALITY TCP + Chrome uTLS. Hysteria UDP is carried over TCP; packet loss can reduce performance.',flush=True)
    print('Detecting Iran public IP (up to 16 seconds) ...',flush=True)
    endpoint=ask_valid('Iran PUBLIC IP; verify against provider dashboard',public_ip,state['endpoint'] or detect())
    if state['endpoint'] and endpoint!=state['endpoint']:print('Endpoint change updates exported links for ALL groups.',flush=True)
    state['endpoint']=endpoint
    name=ask_valid('Foreign server group name',lambda v:v if re.fullmatch(r'[a-zA-Z0-9_-]{1,32}',v) else invalid('Use 1..32 letters, digits, _ or -.'),'foreign1')
    while True:
        try:
            transport=ask('Foreign VLESS REALITY + Vision link',secret=True);node=uri(transport);outbound(transport)
            transport_ip=choose_ip(node['host'],endpoint);break
        except Failure as e:print('INPUT: '+str(e),flush=True)
    if node['port']!=443:print('NOTE: Outer foreign port is not TCP/443. Port 443 is preferred when your foreign installation provides it.',flush=True)
    previous=next((g for g in old['groups'] if g['name']==name),None)
    print('Paste ONLY links belonging to this foreign server. Do not change foreign domain DNS to point to Iran.',flush=True)
    values=links_input();state['groups']=[g for g in state['groups'] if g['name']!=name]
    used={(m['local_port'],m['network']) for g in state['groups'] for m in g['maps']}
    if sum(len(g['maps']) for g in state['groups'])+len(values)>128:raise Failure('Maximum 128 total mappings.')
    maps=[];cache={node['host']:transport_ip};family=socket.AF_INET6 if ':' in endpoint else socket.AF_INET
    old_keys={(m['local_port'],m['network']) for g in old['groups'] for m in g['maps']}
    for i,link in enumerate(values,1):
        n=uri(link)
        if n['host'] not in cache:
            addresses=resolve(n['host'])
            if transport_ip not in addresses:raise Failure('Config domain does not resolve to this foreign server: '+n['host']+'. Check foreign DNS or use a separate server group.')
            cache[n['host']]=transport_ip
            print('PASS DNS pinned to foreign server: '+n['host'],flush=True)
        target=cache[n['host']]
        # Keep groups tied to a single foreign host; no arbitrary cross-host bounce.
        if target!=transport_ip:raise Failure('All links in a group must resolve to the selected foreign server IP. Use a separate group for another server.')
        prev=next((m for m in (previous or {}).get('maps',[]) if m['link']==link),None)
        suggested=prev['local_port'] if prev else n['port']
        if (suggested,n['network']) in used or occupied(suggested,n['network'],(suggested,n['network']) in old_keys,family):suggested=free(n['network'],used,family)
        def valid_port(v):
            p=free(n['network'],used,family) if v=='r' else port(v)
            if (p,n['network']) in used:raise Failure('This protocol/port is already assigned in another mapping.')
            if occupied(p,n['network'],(p,n['network']) in old_keys,family):raise Failure('Port is occupied by another service. Choose another port or r.')
            return p
        local=ask_valid('Link '+str(i)+' '+n['scheme']+' Iran '+n['network'].upper()+' port (r=random)',valid_port,suggested)
        used.add((local,n['network']));maps.append({'link':link,'local_port':local,'remote_port':n['port'],'network':n['network'],'target_ip':target,'label':n['scheme']+'-'+str(i)})
    g={'name':name,'transport':transport,'transport_ip':transport_ip,'maps':maps};state['groups'].append(g)
    print('\nREVIEW '+name+': Iran '+endpoint+' -> REALITY '+transport_ip+':'+str(node['port']),flush=True)
    for m in maps:print(m['label']+' '+m['network'].upper()+'/'+str(m['local_port'])+' -> '+m['target_ip']+':'+str(m['remote_port']),flush=True)
    if ask('Apply? y=yes','N').lower()!='y':raise Cancelled()
    download();socks_test(g);target_checks(g)
    helpers={m['helper_port'] for group in state['groups'] for m in group['maps'] if 'helper_port' in m}
    for m in maps:
        if uri(m['link'])['scheme']=='vless':
            previous_map=next((v for v in (previous or {}).get('maps',[]) if v['link']==m['link']),None)
            m['identity']=copy.deepcopy(previous_map['identity']) if previous_map and 'identity' in previous_map else keypair()
            m['helper_port']=free('tcp',used|{(p,'tcp') for p in helpers})
            helpers.add(m['helper_port'])
    activate(state,old)

def show_links():
    s=load()
    if not s['groups']:raise Failure('No relay mappings installed. Run iran-relay setup.')
    for g in s['groups']:
        print('# '+g['name'])
        for m in g['maps']:print(exported(m,s['endpoint']))

def status():
    s=load();p=run(['systemctl','is-active',SERVICE],check=False)
    print('IRAN RELAY '+VERSION+' | '+p.stdout.strip()+' | endpoint '+s['endpoint'])
    for g in s['groups']:
        print('Group '+g['name']+' | encrypted transport '+g['transport_ip'])
        for m in g['maps']:print('  '+m['label']+' '+m['network']+'/'+str(m['local_port'])+' -> '+m['target_ip']+':'+str(m['remote_port']))

def test():
    s=load()
    if not s['groups']:raise Failure('No installed groups.')
    download()
    for g in s['groups']:socks_test(g);target_checks(g)
    config_test(CURRENT/'config.json')
    print('Core/config and outer transport checks passed. Hysteria/AnyTLS/SS/inner REALITY authentication must also be tested from end clients.')

def doctor():
    status()
    for args in (['systemd-detect-virt'],['systemctl','show',SERVICE,'-p','ActiveState','-p','SubState','-p','Result','-p','ExecMainStatus'],['ss','-lntu'],['systemctl','list-jobs','--no-pager']):
        if shutil.which(args[0]):print(run(args,timeout=12,check=False).stdout.strip())
    print('Logs: sudo journalctl -u iran-relay.service -n 60 --no-pager (review privately; logs may contain endpoint information).')
    print('If foreign-local tests pass but this tunnel fails: Iran outbound TCP, provider firewall, IP blocking, SNI/pbk/UUID, DNS, or server clock. TLS camouflage cannot fix an unreachable IP.')
    print('If outer authentication passes but a target fails: foreign service binding/firewall, NAT hairpin, or service port. If UDP client fails: check Iran inbound UDP and UDP-over-TCP loss/latency. No claim of censorship bypass is made.')

def remove():
    old=load()
    name=ask('Group name to remove')
    if not any(g['name']==name for g in old['groups']):raise Failure('Group not found.')
    state=copy.deepcopy(old);state['groups']=[g for g in old['groups'] if g['name']!=name]
    if not state['groups']:raise Failure('Last group: use iran-relay uninstall instead.')
    if ask('Remove this group? y=yes','N').lower()!='y':raise Cancelled()
    activate(state,old)

def uninstall():
    if ask('Remove relay service, credentials, core and manager? y=yes','N').lower()!='y':raise Cancelled()
    s=load();run(['systemctl','disable','--now',SERVICE],timeout=25,check=False);remove_rules(s.get('ufw_owned',[]))
    UNIT.unlink(missing_ok=True);run(['systemctl','daemon-reload'],check=False)
    if ROOT.is_symlink():raise Failure('Refusing symlink root.')
    shutil.rmtree(ROOT);MANAGER.unlink(missing_ok=True)
    print('Relay removed.')

def install_manager():
    source=pathlib.Path(os.environ.get('IR_RELAY_SOURCE',''))
    if not source.is_file():raise Failure('Run the original iran-relay-oneclick.sh with bash.')
    if MANAGER.is_symlink():raise Failure('Manager path is a symlink; stopped.')
    atomic(MANAGER,source.read_text(),0o700)
    print('Iran relay manager '+VERSION+' installed. Next: sudo iran-relay setup')

def main():
    parser=argparse.ArgumentParser(description='Encrypted fixed-port Iran-to-foreign relay; English menu, no panel.')
    parser.add_argument('action',nargs='?',default='menu',choices=['manager-install','setup','links','status','test','doctor','remove','uninstall','start','stop','restart','menu'])
    a=parser.parse_args()
    if os.geteuid()!=0:raise Failure('Run with sudo.')
    if not pathlib.Path('/run/systemd/system').exists() and a.action not in ('manager-install',):raise Failure('A running systemd host is required.')
    if ROOT.is_symlink():raise Failure('Relay root is a symlink; stopped.')
    ROOT.mkdir(mode=0o755,parents=True,exist_ok=True)
    ROOT.chmod(0o755)
    with open(ROOT/'manager.lock','a') as lock:
        try:fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise Failure('Another relay operation is running.')
        if a.action=='manager-install':install_manager();return
        actions={'setup':setup,'links':show_links,'status':status,'test':test,'doctor':doctor,'remove':remove,'uninstall':uninstall}
        if a.action in ('start','stop','restart'):run(['systemctl',a.action,SERVICE],timeout=25);status();return
        if a.action!='menu':actions[a.action]();return
        while True:
            print('\nIRAN RELAY '+VERSION+'\n1) Add/update foreign server  2) Config links  3) Status  4) Test\n5) Troubleshoot  6) Remove group  7) Restart  8) Stop  9) Uninstall  0) Exit',flush=True)
            choice=ask('Select','0')
            if choice=='0':return
            try:
                if choice=='7':run(['systemctl','restart',SERVICE]);status()
                elif choice=='8':run(['systemctl','stop',SERVICE]);status()
                elif choice in ('1','2','3','4','5','6','9'):{'1':setup,'2':show_links,'3':status,'4':test,'5':doctor,'6':remove,'9':uninstall}[choice]()
                else:print('Invalid menu option.')
                if choice=='9' and not ROOT.exists():return
            except Cancelled:print('Cancelled. Previous settings retained.')
            except Failure as e:print('ERROR: '+str(e),flush=True)

if __name__=='__main__':
    try:main()
    except (Cancelled,KeyboardInterrupt):print('\nCancelled. Existing relay settings retained.');sys.exit(130)
    except (Failure,OSError,ValueError,KeyError,json.JSONDecodeError) as e:
        print('ERROR: '+(str(e) if isinstance(e,Failure) else type(e).__name__+'; run iran-relay doctor.'),file=sys.stderr);sys.exit(1)

IRAN_RELAY_PYTHON
