import http.server
import importlib.util, pathlib, tempfile, socket, threading, subprocess, time, json, ssl, contextlib, os, urllib.parse
import types
m=types.ModuleType('relay')
script=pathlib.Path(__file__).resolve().parents[1]/'iran-relay-oneclick.sh'
source=script.read_text().split("<<'IRAN_RELAY_PYTHON'\n",1)[1].rsplit('\nIRAN_RELAY_PYTHON\n',1)[0]
exec(compile(source,str(script),'exec'),m.__dict__)
XRAY=pathlib.Path(os.environ['XRAY_BIN']).resolve()
def free(kind=socket.SOCK_STREAM):
    with socket.socket(type=kind) as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
def key():
    out=subprocess.check_output([XRAY,'x25519'],text=True)
    vals=dict(line.replace(' ','').split(':',1) for line in out.strip().splitlines())
    return vals['PrivateKey'],vals.get('Password',vals.get('Password(PublicKey)',vals.get('PublicKey')))
@contextlib.contextmanager
def proc(cfg,d,name):
    path=d/(name+'.json');path.write_text(json.dumps(cfg))
    r=subprocess.run([XRAY,'run','-test','-c',path],capture_output=True,text=True)
    if r.returncode:raise AssertionError(r.stdout+r.stderr)
    log=open(d/(name+'.log'),'w');p=subprocess.Popen([XRAY,'run','-c',path],stdout=log,stderr=log)
    try:
        time.sleep(.3)
        if p.poll() is not None:raise AssertionError((d/(name+'.log')).read_text())
        yield p
    finally:
        p.terminate()
        try:p.wait(timeout=3)
        except subprocess.TimeoutExpired:p.kill();p.wait()
        log.close()
def real_server(port,priv,target,name):
    return {'log':{'loglevel':'debug'},'inbounds':[{'listen':'127.0.0.1','port':port,'protocol':'vless','settings':{'clients':[{'id':'11111111-1111-4111-8111-111111111111','flow':'xtls-rprx-vision'}],'decryption':'none'},'streamSettings':{'network':'tcp','security':'reality','realitySettings':{'target':'127.0.0.1:'+str(target),'serverNames':[name],'privateKey':priv,'shortIds':['abcdef12']}}}],'outbounds':[{'protocol':'freedom'}]}
def link(port,pub,name='test.example'):
    q=urllib.parse.urlencode({'encryption':'none','security':'reality','sni':name,'fp':'chrome','pbk':pub,'sid':'abcdef12','type':'tcp','flow':'xtls-rprx-vision'})
    return 'vless://11111111-1111-4111-8111-111111111111@127.0.0.1:'+str(port)+'?'+q
with tempfile.TemporaryDirectory() as td:
    d=pathlib.Path(td);target=free();outer=free();inner=free();tcp=free();udp=free(socket.SOCK_DGRAM);utarget=free(socket.SOCK_DGRAM);hyport=free(socket.SOCK_DGRAM);hyrelay=free(socket.SOCK_DGRAM)
    subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(d/'key.pem'),'-out',str(d/'cert.pem'),'-days','1','-subj','/CN=test.example','-addext','subjectAltName=DNS:test.example'],check=True,capture_output=True)
    hy=pathlib.Path(os.environ['HYSTERIA_BIN']).resolve()
    fixture_text='s_server '+('0123456789abcdef'*131072)
    hcfg={'listen':'127.0.0.1:'+str(hyport),'tls':{'cert':str(d/'cert.pem'),'key':str(d/'key.pem')},'auth':{'type':'password','password':'fixture'},'obfs':{'type':'salamander','salamander':{'password':'fixture-obfs-password'}},'masquerade':{'type':'string','string':{'content':fixture_text,'statusCode':200},'listenHTTPS':'127.0.0.1:'+str(target)}}
    (d/'fixture.json').write_text(json.dumps(hcfg))
    srv=subprocess.Popen([str(hy),'server','-c',str(d/'fixture.json')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    usock=socket.socket(type=socket.SOCK_DGRAM);usock.bind(('127.0.0.1',utarget));usock.settimeout(.2);stop=threading.Event()
    def echo():
        while not stop.is_set():
            try:data,addr=usock.recvfrom(65535);usock.sendto(data,addr)
            except socket.timeout:pass
    thread=threading.Thread(target=echo,daemon=True);thread.start()
    try:
        time.sleep(.3);priv,pub=key();priv2,pub2=key()
        st={'endpoint':'127.0.0.1','groups':[{'name':'foreign1','transport':link(outer,pub),'transport_ip':'127.0.0.1','maps':[{'local_port':tcp,'remote_port':inner,'target_ip':'127.0.0.1','network':'tcp','link':link(inner,pub2),'identity':{'private_key':priv2,'public_key':pub2,'uuid':'11111111-1111-4111-8111-111111111111','short_id':'abcdef12'},'helper_port':free()},{'local_port':udp,'remote_port':utarget,'target_ip':'127.0.0.1','network':'udp','link':'hysteria2://password@127.0.0.1:'+str(utarget)+'/?sni=test.example'},{'local_port':hyrelay,'remote_port':hyport,'target_ip':'127.0.0.1','network':'udp','link':'hysteria2://fixture@127.0.0.1:'+str(hyport)+'/?sni=test.example'}]}]}
        stcfg=m.config(st,'127.0.0.1');stcfg['log']={'loglevel':'debug'}
        # Local fixture substitutes the public SNI:443 target with our TLS test server.
        helper=next(i for i in stcfg['inbounds'] if i['tag'].endswith('-tls-target'));helper['settings']['address']='127.0.0.1';helper['settings']['port']=target
        with proc(real_server(outer,priv,target,'test.example'),d,'outer'),proc(real_server(inner,priv2,target,'test.example'),d,'inner'),proc(stcfg,d,'relay'):
            # A real inner REALITY client crosses the opaque relay and outer REALITY.
            sp=free();client={'log':{'loglevel':'debug'},'inbounds':[{'listen':'127.0.0.1','port':sp,'protocol':'socks','settings':{'auth':'noauth'}}],'outbounds':[m.outbound(link(tcp,pub2),'127.0.0.1')]}
            with proc(client,d,'client'):
                result=subprocess.run(['curl','--http2','-ksS','--noproxy','','--proxy','socks5h://127.0.0.1:'+str(sp),'--connect-to','test.example:443:127.0.0.1:'+str(target),'--connect-timeout','5','--max-time','10','https://test.example/'],capture_output=True,text=True)
                if result.returncode:
                    for name in ('outer','relay','client','inner'):(pathlib.Path(tempfile.gettempdir())/('iran-relay-'+name+'-failure.log')).write_text((d/(name+'.log')).read_text())
                    raise AssertionError(str(result.returncode)+': '+result.stderr)
                assert result.stdout==fixture_text
                print('PASS 2 MiB HTTP/2+TLS1.3 body: actual client REALITY -> Iran terminating REALITY -> foreign REALITY -> HTTPS')
            with socket.socket(type=socket.SOCK_DGRAM) as c:
                c.settimeout(5);payload=b'udp-over-reality-'+os.urandom(1200);c.sendto(payload,('127.0.0.1',udp));assert c.recv(65535)==payload
                print('PASS actual UDP datagram through outer REALITY TCP (1200+ bytes)')

            import hashlib
            pin=hashlib.sha256(ssl.PEM_cert_to_DER_cert((d/'cert.pem').read_text())).hexdigest()
            hp=free();hc={'server':'127.0.0.1:'+str(hyrelay),'auth':'fixture','tls':{'sni':'test.example','insecure':True,'pinSHA256':pin},'obfs':{'type':'salamander','salamander':{'password':'fixture-obfs-password'}},'socks5':{'listen':'127.0.0.1:'+str(hp)},'lazy':False}
            (d/'hy-client.json').write_text(json.dumps(hc))
            hlog=open(d/'hy-client.log','w');hcproc=subprocess.Popen([str(hy),'client','-c',str(d/'hy-client.json')],stdout=hlog,stderr=hlog)
            try:
                time.sleep(1)
                result=subprocess.run(['curl','--http1.1','-ksS','--noproxy','','--proxy','socks5h://127.0.0.1:'+str(hp),'--connect-to','test.example:443:127.0.0.1:'+str(target),'--connect-timeout','5','--max-time','12','https://test.example/'],capture_output=True,text=True)
                if result.returncode:raise AssertionError(result.stderr+'\n'+(d/'hy-client.log').read_text())
                assert result.stdout==fixture_text
                print('PASS 2 MiB HTTPS body: actual Hysteria 2 + Salamander + certificate pin -> Iran UDP relay -> foreign REALITY TCP -> Hysteria -> HTTPS')
            finally:hcproc.terminate();hcproc.wait(timeout=3);hlog.close()

    finally:
        stop.set();thread.join(timeout=1);usock.close();srv.terminate();srv.wait(timeout=3)
