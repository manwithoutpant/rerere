import importlib.util, unittest, pathlib, tempfile, copy, json, types, urllib.parse, base64
from unittest import mock
import types
m=types.ModuleType('relay')
script=pathlib.Path(__file__).resolve().parents[1]/'iran-relay-oneclick.sh'
source=script.read_text().split("<<'IRAN_RELAY_PYTHON'\n",1)[1].rsplit('\nIRAN_RELAY_PYTHON\n',1)[0]
exec(compile(source,str(script),'exec'),m.__dict__)
REAL='vless://11111111-1111-4111-8111-111111111111@8.8.8.8:443?security=reality&type=tcp&encryption=none&flow=xtls-rprx-vision&sni=www.google.com&fp=chrome&pbk='+('a'*43)+'&sid=abcdef12#Foreign'
HY='hysteria2://secret@hy.example.com:8443/?sni=hy.example.com&insecure=0&obfs=salamander&obfs-password=p%40ss%3B%26&pinSHA256=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#HY'
ANY='anytls://secret@any.example.com:9443/?sni=any.example.com&insecure=0#ANY'
SS='ss://'+base64.urlsafe_b64encode(b'2022-blake3-aes-256-gcm:password').decode().rstrip('=')+'@ss.example.com:9444/?'+urllib.parse.urlencode({'plugin':'v2ray-plugin;tls;host=ss.example.com;path=/vpn'})+'#SS'
def state(link=HY):
 n=m.uri(link)
 return {'endpoint':'9.9.9.9','groups':[{'name':'one','transport':REAL,'transport_ip':'8.8.8.8','maps':[{'link':link,'local_port':8443,'network':n['network'],'target_ip':'8.8.8.8','remote_port':n['port'],'label':'one'}]}],'ufw_owned':[]}
class Tests(unittest.TestCase):
 def test_rewrite_all_credentials_and_tls_preserved(self):
  for source in (REAL,HY,ANY,SS):
   with self.subTest(source=m.uri(source)['scheme']):
    out=m.rewritten(source,'9.9.9.9',25000);a=urllib.parse.urlsplit(source);b=urllib.parse.urlsplit(out)
    self.assertEqual(b.hostname,'9.9.9.9');self.assertEqual(b.port,25000);self.assertEqual(a.username,b.username);self.assertEqual(m.uri(source)['query'],m.uri(out)['query'])
 def test_ipv6_export(self):self.assertEqual(urllib.parse.urlsplit(m.rewritten(HY,'2001:4860:4860::8888',443)).hostname,'2001:4860:4860::8888')
 def test_insecure_and_plain_ss_rejected(self):
  for v in (ANY.replace('insecure=0','insecure=1'),SS.split('?')[0]):
   with self.assertRaises(m.Failure):m.uri(v)
 def test_duplicate_fields_and_wrapped_links_rejected(self):
  for v in (REAL.split('#')[0]+'&sni=bad.example',REAL+'\nwrap'):
   with self.assertRaises(m.Failure):m.uri(v)
 def test_invalid_uuid_key_shortid_and_encryption(self):
  for v in (REAL.replace('11111111-1111-4111-8111-111111111111','bad'),REAL.replace('pbk='+('a'*43),'pbk=short'),REAL.replace('abcdef12','abc'),REAL.replace('encryption=none','encryption=unknown')):
   with self.assertRaises(m.Failure):m.uri(v)
 def test_private_addresses_refused(self):
  for v in ('127.0.0.1','10.1.1.1','169.254.169.254','::1','224.0.0.1','192.0.2.1'):
   with self.assertRaises(m.Failure):m.public_ip(v)
 def test_private_dns_mixture_refused(self):
  with mock.patch.object(m,'run',return_value=types.SimpleNamespace(returncode=0,stdout='["8.8.8.8","127.0.0.1"]')):
   with self.assertRaises(m.Failure):m.resolve('mixed.example')
 def test_outer_udp443_and_no_direct_fallback(self):
  cfg=m.config(state());self.assertEqual(cfg['outbounds'][0]['protocol'],'blackhole');self.assertFalse(any(x['protocol']=='freedom' for x in cfg['outbounds']))
  self.assertEqual(cfg['outbounds'][1]['settings']['vnext'][0]['users'][0]['flow'],'xtls-rprx-vision-udp443')
  self.assertEqual(cfg['outbounds'][1]['streamSettings']['realitySettings']['fingerprint'],'chrome')
 def test_each_group_has_own_transport(self):
  st=state();b=copy.deepcopy(st['groups'][0]);b['name']='two';b['maps'][0]['local_port']=8444;st['groups'].append(b);cfg=m.config(st)
  self.assertEqual({r['outboundTag'] for r in cfg['routing']['rules']},{'outer-one','outer-two'})
 def test_real_profile_has_new_identity_and_private_helper(self):
  st=state(REAL);mp=st['groups'][0]['maps'][0];mp.update(identity={'uuid':'22222222-2222-4222-8222-222222222222','public_key':'b'*43,'private_key':'c'*43,'short_id':'12345678'},helper_port=35000)
  cfg=m.config(st);self.assertEqual(cfg['inbounds'][0]['protocol'],'vless');self.assertEqual(cfg['inbounds'][1]['listen'],'127.0.0.1')
  out=m.uri(m.exported(mp,'9.9.9.9'));self.assertEqual(out['query']['pbk'],'b'*43);self.assertIn('22222222-',out['link']);self.assertEqual(out['query']['sni'],'www.google.com')
 def test_conflicting_ports_detected(self):
  import socket
  with socket.socket() as s:s.bind(('0.0.0.0',0));self.assertTrue(m.occupied(s.getsockname()[1],'tcp'))
 def test_symlink_write_refused(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);(p/'original').write_text('keep');(p/'alias').symlink_to(p/'original')
   with self.assertRaises(m.Failure):m.atomic(p/'alias','bad')
   self.assertEqual((p/'original').read_text(),'keep')
 def test_ufw_remove_only_owned_comment_numbered_reverse(self):
  calls=[]
  def fake(args,**kw):
   calls.append(args);return types.SimpleNamespace(returncode=0,stdout='[ 1] 8443/udp ALLOW IN Anywhere # administrator\n[ 2] 8443/udp ALLOW IN Anywhere # iran-relay\n[ 3] 8443/udp (v6) ALLOW IN Anywhere (v6) # iran-relay\n')
  with mock.patch.object(m.shutil,'which',return_value='/usr/sbin/ufw'),mock.patch.object(m,'run',side_effect=fake):m.remove_rules({'8443/udp'})
  self.assertEqual(calls[1:],[['ufw','--force','delete','3'],['ufw','--force','delete','2']])
 def test_activation_failure_restores_state_and_unit(self):
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d);old=root/'old';old.mkdir();(old/'state.json').write_text(json.dumps(state()));current=root/'current';current.symlink_to(old);unit=root/'service';unit.write_text('old service')
   calls=[]
   def fake(args,**kw):
    calls.append(args)
    if args[:2]==['systemctl','restart'] and kw.get('check',True):raise m.Failure('simulated restart failure')
    return types.SimpleNamespace(returncode=0,stdout='')
   with mock.patch.multiple(m,ROOT=root,CURRENT=current,UNIT=unit),mock.patch.object(m,'run',side_effect=fake),mock.patch.object(m,'config_test'),mock.patch.object(m,'add_rules',return_value=[]),mock.patch.object(m,'remove_rules'):
    with self.assertRaises(m.Failure):m.activate(state(),state())
   self.assertEqual(current.resolve(),old);self.assertEqual(unit.read_text(),'old service');self.assertFalse(list(root.glob('release-*')))
 def test_modified_cached_core_is_not_executed(self):
  with tempfile.TemporaryDirectory() as d:
   root=pathlib.Path(d);binary=root/'xray';binary.write_bytes(b'changed');(root/'core-receipt.json').write_text(json.dumps({'binary_sha256':'0'*64}))
   with mock.patch.multiple(m,ROOT=root,BIN=binary),mock.patch.object(m,'run') as run:
    with self.assertRaises(m.Failure):m.download()
    run.assert_not_called()
 def test_camouflage_requires_tls13_and_h2(self):
  for version,alpn in (('TLSv1.2','h2'),('TLSv1.3','http/1.1')):
   with self.subTest(version=version,alpn=alpn):
    sock=mock.MagicMock();ctx=mock.MagicMock();tls=ctx.wrap_socket.return_value.__enter__.return_value;tls.version.return_value=version;tls.selected_alpn_protocol.return_value=alpn
    with mock.patch.object(m.socket,'create_connection',return_value=sock),mock.patch.object(m,'socks_connect'),mock.patch.object(m.ssl,'create_default_context',return_value=ctx):
     with self.assertRaises(m.Failure):m.camouflage_checks(state(REAL)['groups'][0],30000)
 def test_partial_firewall_failure_removes_added_rules(self):
  st=state();second=copy.deepcopy(st['groups'][0]['maps'][0]);second['local_port']=8444;st['groups'][0]['maps'].append(second);old={'groups':[],'ufw_owned':[]};allowed=[]
  def fake(args,**kw):
   if args[:2]==['ufw','allow']:
    if allowed:raise m.Failure('simulated UFW failure')
    allowed.append(args[2])
   return types.SimpleNamespace(returncode=0,stdout='')
  with mock.patch.object(m,'ufw_active',return_value=True),mock.patch.object(m,'run',side_effect=fake),mock.patch.object(m,'remove_rules') as cleanup:
   with self.assertRaises(m.Failure):m.add_rules(st,old)
   cleanup.assert_called_once_with(['8443/udp'])
 def test_cancel_before_apply(self):
  with mock.patch.object(m,'load',return_value=state()),mock.patch.object(m,'ask_valid',side_effect=m.Cancelled),mock.patch.object(m,'download') as download:
   with self.assertRaises(m.Cancelled):m.setup()
   download.assert_not_called()
if __name__=='__main__':unittest.main(verbosity=2)
