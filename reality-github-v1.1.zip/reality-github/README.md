# REALITY One Click 1.1

اسکریپت نصب و مدیریت **VLESS + TCP + REALITY + Vision** روی Ubuntu 22.04+ با systemd و معماری x86_64 یا ARM64.

خروجی اتصال فقط لینک‌های مستقیم `vless://` است. هر خط یک کانفیگ مستقل برای ورود به برنامه‌های سازگار در ویندوز، اندروید و آیفون است. URL اشتراک و سرویس subscription ایجاد نمی‌شود.

## نصب

فایل را به سرور منتقل کنید و اجرا کنید:

```bash
sudo bash reality-oneclick.sh install
```

در اجرای موفق، پیشرفت و توضیحات به stderr و لینک‌های کانفیگ به stdout نوشته می‌شوند. برای کپی معمولی، لینک‌های انتهای ترمینال را بردارید. دستور زیر نیز فقط لینک‌ها را نمایش می‌دهد:

```bash
sudo reality-manager links
```

یک پروفایل مشخص:

```bash
sudo reality-manager links --profile Google
```

## منو و فرمان‌ها

```bash
sudo reality-manager
```

| کار | دستور |
| --- | --- |
| نصب | `sudo reality-manager install` |
| نصب مجدد با حفظ اطلاعات اتصال | `sudo reality-manager reinstall` |
| حذف با حفظ اطلاعات اتصال برای نصب بعدی | `sudo reality-manager uninstall` |
| حذف کامل اطلاعات این نصب | `sudo reality-manager uninstall --purge` |
| نمایش کانفیگ‌ها | `sudo reality-manager links` |
| وضعیت سرویس | `sudo reality-manager status` |
| آزمایش اتصال از داخل سرور | `sudo reality-manager check` |
| شروع، توقف و راه‌اندازی مجدد | `sudo reality-manager start` / `stop` / `restart` |
| نمایش خطاهای اخیر | `sudo reality-manager logs` |
| به‌روزرسانی هسته Xray | `sudo reality-manager update` |
| بازگشت به نسخه قبلی | `sudo reality-manager rollback` |
| آزمایش مجدد و تغییر تنظیمات | `sudo reality-manager reconfigure` |

حذف تعاملی تأیید می‌گیرد؛ در اسکریپت خودکار می‌توانید `--yes` اضافه کنید. پس از حذف کامل، برای نصب دوباره فایل عمومی را دریافت و دستور نصب اولیه را اجرا کنید. پس از حذف معمولی، `reality-manager install` اطلاعات اتصال ذخیره‌شده را بازیابی می‌کند.

## پیش‌فرض‌ها

| پروفایل | پورت TCP | دامنه آزمایشی اولیه |
| --- | ---: | --- |
| Google | 2025 | `www.google.com` |
| ChatGPT | 2026 | `chatgpt.com` |
| GSMArena | 2027 | `www.gsmarena.com` |
| Microsoft | 2028 | `www.bing.com` |

برای گوگل، `dl.google.com` و برای مایکروسافت، `www.microsoft.com` جایگزین در همان گروه هستند. پروفایل ناموفق در نصب اول ساخته نمی‌شود و نتیجه صریحاً گزارش می‌شود. اتصال خروجی به دامنه‌های هدف از پورت ۴۴۳ است.

```bash
sudo reality-manager reconfigure --ports 443,2026,2027,2028
sudo reality-manager reconfigure --server-ip YOUR_PUBLIC_IP
sudo reality-manager reconfigure --domains www.google.com,chatgpt.com,www.gsmarena.com,www.bing.com
```

`YOUR_PUBLIC_IP` را با IP واقعی ورودی سرور عوض کنید. برای نمونه، در سرور NAT، IP تشخیص‌داده‌شده خروجی ممکن است همان IP ورودی نباشد.

## انتشار در GitHub

1. یک مخزن بسازید و محتویات این پوشه را در ریشه آن قرار دهید.
2. در دستور زیر، `USERNAME` و `REPOSITORY` و در صورت نیاز شاخه `main` را با مقادیر واقعی جایگزین کنید. این یک الگوست و هنوز URL واقعی مخزن شما نیست.
3. برای مخزن عمومی، دستور نصب از سرور چنین است:

```bash
curl -fL --proto '=https' --proto-redir '=https' 'https://raw.githubusercontent.com/USERNAME/REPOSITORY/main/reality-oneclick.sh' -o reality-oneclick.sh && sudo bash reality-oneclick.sh install
```

برای بازکردن منو، در انتهای دستور به‌جای `install` از `menu` استفاده کنید. برای تثبیت کد دانلودشده می‌توانید در URL به‌جای `main` از شناسه commit یا tag منتشرشده واقعی استفاده کنید.

اسکریپت را به فایل دانلود کنید؛ روش `curl | bash` برای این بسته پشتیبانی نمی‌شود چون فرمان مدیریت باید از یک فایل محلی نصب شود. مخزن خصوصی به روش دریافت احرازهویت‌شده خودش نیاز دارد؛ دستور بالا برای مخزن عمومی نوشته شده است.

کلیدها، فایل `state.json`، خروجی `links.txt`، فایل پشتیبان اتصال و پوشه اجرای سرور را در مخزن نگذارید. بسته حاضر هیچ اطلاعات اتصال واقعی ندارد. Xray در زمان نصب از انتشار رسمی دریافت می‌شود و داخل این مخزن باینری Xray وجود ندارد.

## واردکردن در دستگاه

- **ویندوز:** [v2rayN](https://github.com/2dust/v2rayN)، ورود از Clipboard با هسته Xray؛ سپس System Proxy یا TUN را طبق نیاز فعال کنید.
- **اندروید:** [v2rayNG](https://github.com/2dust/v2rayNG)، گزینه Import config from clipboard و سپس اتصال.
- **آیفون:** [Happ](https://www.happ.su/main) یا کلاینت به‌روز سازگار با VLESS/REALITY مانند v2RayTun؛ ورود لینک از Clipboard و فعال‌کردن اتصال VPN.

نام دامنه پوشش را جای IP سرور وارد نکنید؛ لینک همه مقادیر را دارد. Flow برابر `xtls-rprx-vision` و Mux خاموش است. محدودیت سازگاری اعلام‌شده برای Husi در راهنمای کامل توضیح داده شده است.

## آزمون و محدودیت

```bash
bash -n reality-oneclick.sh
python3 -m unittest discover -s tests -v
```

تست‌های چرخه مدیریت از فایل‌سیستم موقت و systemd/UFW شبیه‌سازی‌شده استفاده می‌کنند؛ سرویس یا فایروال میزبان تست را تغییر نمی‌دهند. برای آزمون محلی تونل با یک باینری رسمی Xray که خودتان دریافت کرده‌اید:

```bash
python3 tests/integration_reality.py /absolute/path/to/xray
```

این آزمون روی loopback و با گواهی موقت انجام می‌شود و مسیر اینترنت عمومی را نمی‌سنجد. اسکریپت هنگام نصب روی سرور واقعی، دامنه‌های عمومی و تونل را آزمایش می‌کند. آزمون واقعی از اینترنت ایران و بازبودن فایروال شرکت میزبان همچنان لازم است. عملکرد همه اپراتورها یا همه سرویس‌های مقصد تضمین نشده است.

[راهنمای کامل فارسی](docs/reality-guide-fa.md) · [مقایسه امکانات اسکریپت‌ها](docs/script-comparison-fa.md)
