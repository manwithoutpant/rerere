#!/usr/bin/env bash
# REALITY One Click 1.1 — Ubuntu 22.04+; dedicated Xray service.
set -Eeuo pipefail
export LC_ALL=C
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/sbin:/usr/local/bin
if [[ ${1:-} == '--help' || ${1:-} == '-h' ]]; then
  cat <<'HELP'
REALITY One Click 1.1
Usage: sudo bash reality-oneclick.sh COMMAND [options]
Commands: menu, install, reinstall, uninstall, links, status, check,
          start, stop, restart, logs, update, reconfigure, rollback
No arguments: interactive menu on a terminal, install in noninteractive use.
Options:
  --server-ip PUBLIC_IP                 Public IPv4 or IPv6
  --ports 2025,2026,2027,2028           Four distinct TCP ports
  --domains DNS1,DNS2,DNS3,DNS4        Google, ChatGPT, GSMArena, Microsoft
  --version v26.3.27                    Pin an official stable Xray release
  --no-ufw                             Do not add UFW rules
  --profile Google                     Select one config for the links command
  --purge                              Uninstall and erase saved credentials
  --yes                                Confirm uninstall in noninteractive use
Progress is written to stderr; install/reinstall/links stdout contains only vless:// URIs.
HELP
  exit 0
fi
[[ $EUID -eq 0 ]] || { echo 'Run with sudo bash reality-oneclick.sh' >&2; exit 1; }
[[ -d /run/systemd/system ]] || { echo 'A Ubuntu host running systemd is required.' >&2; exit 1; }
. /etc/os-release
[[ ${ID:-} == ubuntu && ${VERSION_ID%%.*} -ge 22 ]] || { echo 'Requires Ubuntu 22.04 or newer.' >&2; exit 1; }
if [[ $# -eq 0 ]]; then
  if [[ -t 0 && -t 2 ]]; then set -- menu; else set -- install; fi
fi
if [[ $1 == menu ]]; then
  cat >&2 <<'MENU'
REALITY — منوی مدیریت
  1) نصب / فعال‌سازی
  2) نمایش لینک‌های کانفیگ
  3) وضعیت سرویس
  4) بررسی اتصال
  5) به‌روزرسانی Xray
  6) نصب مجدد با حفظ اطلاعات اتصال
  7) حذف با حفظ اطلاعات اتصال
  8) حذف کامل اطلاعات این نصب
  9) شروع سرویس
 10) توقف سرویس
 11) راه‌اندازی مجدد سرویس
 12) نمایش خطاها
 13) بازگشت به نسخه قبلی
 14) بررسی مجدد دامنه‌ها
  0) خروج
MENU
  read -r -p 'شماره گزینه: ' reality_choice </dev/tty
  case "$reality_choice" in
    1) set -- install;; 2) set -- links;; 3) set -- status;; 4) set -- check;;
    5) set -- update;; 6) set -- reinstall;; 7) set -- uninstall;;
    8) set -- uninstall --purge;; 9) set -- start;; 10) set -- stop;;
    11) set -- restart;; 12) set -- logs;; 13) set -- rollback;;
    14) set -- reconfigure;; 0) exit 0;; *) echo 'گزینه نامعتبر' >&2; exit 1;;
  esac
fi
case ${1:-install} in
  install|reinstall|update|reconfigure|--*)
    apt-get update -qq >&2
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq --no-install-recommends ca-certificates curl python3 openssl iproute2 util-linux >&2
    ;;
esac
export REALITY_INSTALLER_SOURCE
REALITY_INSTALLER_SOURCE=$(readlink -f -- "$0")
exec python3 - "$@" <<'PYTHON'
import argparse, contextlib, copy, fcntl, hashlib, ipaddress, json, os
import pathlib, platform, re, secrets, shlex, shutil, socket, subprocess, sys
import tempfile, time, urllib.parse, uuid, zipfile

ROOT = pathlib.Path('/opt/reality-oneclick')
CURRENT = ROOT / 'current'
PREVIOUS = ROOT / 'previous'
UNIT = pathlib.Path('/etc/systemd/system/reality-oneclick.service')
SERVICE = 'reality-oneclick.service'
USER = 'realitysvc'
MANAGER = pathlib.Path('/usr/local/sbin/reality-manager')
DATA = pathlib.Path('/var/lib/reality-oneclick')
RECEIPT = DATA / 'ownership.json'
SAVED = DATA / 'saved-state.json'
OWNER = 'reality-oneclick-v1'
MARKER = ROOT / '.managed-by'
FLOW = 'xtls-rprx-vision'
PRIVATE_NETS = ['0.0.0.0/8','10.0.0.0/8','100.64.0.0/10','127.0.0.0/8',
 '169.254.0.0/16','172.16.0.0/12','192.168.0.0/16','198.18.0.0/15',
 '224.0.0.0/4','240.0.0.0/4','::/128','::1/128','fc00::/7','fe80::/10','ff00::/8']
DEFAULTS = [('Google',['www.google.com','dl.google.com']),
 ('ChatGPT',['chatgpt.com']),('GSMArena',['www.gsmarena.com']),
 ('Microsoft',['www.bing.com','www.microsoft.com'])]

class Failure(Exception): pass

def say(s): print(s, file=sys.stderr, flush=True)

def run(args, timeout=45, check=True, **kw):
    p = subprocess.run([str(x) for x in args], capture_output=True, text=True,
                       timeout=timeout, **kw)
    if check and p.returncode:
        raise Failure(f'{pathlib.Path(str(args[0])).name} failed: {(p.stderr or p.stdout)[-1400:]}')
    return p

def write_json(path, obj, mode=0o600):
    path=pathlib.Path(path)
    if path.is_symlink(): raise Failure('Refusing to overwrite a symlink: '+str(path))
    temporary=path.with_name(path.name+'.tmp-'+secrets.token_hex(4))
    try:
        with temporary.open('x') as f:
            os.chmod(temporary,mode); f.write(json.dumps(obj,indent=2)+'\n')
            f.flush(); os.fsync(f.fileno())
        temporary.replace(path)
    finally: temporary.unlink(missing_ok=True)

def curl(url, output=None):
    args=['curl','--fail','--silent','--show-error','--location','--proto','=https',
          '--proto-redir','=https','--connect-timeout','12','--max-time','180',
          '--retry','2','--retry-delay','1',url]
    if output: args += ['--output',str(output)]
    return run(args,timeout=580).stdout

def valid_ip(value):
    try:
        address = ipaddress.ip_address(value.strip())
        if address.is_global: return str(address)
    except ValueError: pass
    raise Failure('A public IPv4 or IPv6 address is required.')

def public_ip(override):
    if override: return valid_ip(override)
    for url in ('https://api.ipify.org','https://ipv4.icanhazip.com','https://api6.ipify.org'):
        try:
            p=run(['curl','-fsS','--connect-timeout','5','--max-time','10',url],timeout=12)
            return valid_ip(p.stdout)
        except (Failure,subprocess.TimeoutExpired): pass
    raise Failure('Public IP detection failed. Retry with --server-ip YOUR_PUBLIC_IP.')

def family(ip): return socket.AF_INET6 if ':' in ip else socket.AF_INET

def loopback(ip): return '::1' if ':' in ip else '127.0.0.1'

def free_port(ip='127.0.0.1'):
    with socket.socket(family(ip)) as s:
        s.bind((ip,0)); return s.getsockname()[1]

def wait_port(proc, ip, port):
    for _ in range(70):
        if proc is not None and proc.poll() is not None: raise Failure('Xray exited during startup.')
        try:
            with socket.create_connection((ip,port),timeout=.15): return
        except OSError: time.sleep(.1)
    raise Failure(f'Listener {ip}:{port} did not start.')

@contextlib.contextmanager
def start(binary, cfg, work, name):
    path=pathlib.Path(work)/f'{name}.json'; write_json(path,cfg)
    with open(pathlib.Path(work)/f'{name}.log','w+') as log:
        proc=subprocess.Popen([str(binary),'run','-c',str(path)],stdout=log,stderr=log)
        try: yield proc
        finally:
            proc.terminate()
            try: proc.wait(timeout=5)
            except subprocess.TimeoutExpired: proc.kill(); proc.wait()

def new_credentials(binary):
    result=run([binary,'x25519']).stdout
    values={re.sub(r'\s','',k).lower():v.strip() for k,v in
            (line.split(':',1) for line in result.splitlines() if ':' in line)}
    priv=values.get('privatekey'); pub=values.get('password') or values.get('password(publickey)') or values.get('publickey')
    if not priv or not pub or not all(re.fullmatch(r'[A-Za-z0-9_-]{43}',x) for x in (priv,pub)):
        raise Failure('Unrecognized Xray x25519 output; no configuration was installed.')
    return dict(uuid=str(uuid.uuid4()),private_key=priv,public_key=pub,short_id=secrets.token_hex(8))

def inbound(node, ip, port=None):
    return {'tag':node['label'],'listen':ip,'port':port or node['port'],'protocol':'vless',
      'settings':{'clients':[{'id':node['uuid'],'flow':FLOW}],'decryption':'none'},
      'streamSettings':{'network':'tcp','security':'reality','realitySettings':{
        'show':False,'target':node['domain']+':443','xver':0,
        'serverNames':[node['domain']],'privateKey':node['private_key'],
        'shortIds':[node['short_id']]}}}

def server_config(nodes, ip):
    return {'log':{'access':'none','loglevel':'warning'},'inbounds':[inbound(n,ip) for n in nodes],
      'outbounds':[{'tag':'direct','protocol':'freedom','settings':{'domainStrategy':'UseIP'}},
                   {'tag':'block','protocol':'blackhole'}],
      'routing':{'domainStrategy':'IPOnDemand','rules':[
         {'type':'field','ip':PRIVATE_NETS,'outboundTag':'block'}]}}

def client_config(node, address, server_port, socks_port):
    return {'log':{'access':'none','loglevel':'warning'},
      'inbounds':[{'listen':'127.0.0.1','port':socks_port,'protocol':'socks',
                   'settings':{'auth':'noauth','udp':True}}],
      'outbounds':[{'protocol':'vless','settings':{'vnext':[{
        'address':address,'port':server_port,'users':[{
        'id':node['uuid'],'encryption':'none','flow':FLOW}]}]},
        'streamSettings':{'network':'tcp','security':'reality','realitySettings':{
          'fingerprint':'chrome','serverName':node['domain'],'password':node['public_key'],
          'shortId':node['short_id'],'spiderX':'/'}},'mux':{'enabled':False}}]}

def config_test(binary,path):
    run([binary,'run','-test','-c',path],timeout=25)

def probe_target(domain):
    # DNS resolution is also bounded by the subprocess deadline.
    p=run(['openssl','s_client','-connect',domain+':443','-servername',domain,
           '-tls1_3','-alpn','h2','-verify_return_error','-verify_hostname',domain],
           input='',timeout=18,check=False)
    output=p.stdout+p.stderr
    if p.returncode or 'TLSv1.3' not in output or 'ALPN protocol: h2' not in output:
        details='DNS lookup failed' if 'BIO_lookup' in output or 'Name or service' in output else 'TLS 1.3, certificate verification or ALPN h2 failed'
        raise Failure(details)
    # Redirects are diagnostic, not a hard TLS compatibility verdict.
    h=run(['curl','-sS','-I','--connect-timeout','5','--max-time','10',
           'https://'+domain+'/'],timeout=12,check=False)
    locations=re.findall(r'^location:\s*(.+)$',h.stdout,re.I|re.M)
    if locations: say('  HTTP redirect: '+locations[-1].strip()+' (review target suitability)')

def test_tunnel(binary,node,address,port,work,name):
    socks=free_port()
    cfg=client_config(node,address,port,socks)
    with start(binary,cfg,work,name) as proc:
        wait_port(proc,'127.0.0.1',socks)
        for url in ('https://www.example.com/','https://www.wikipedia.org/'):
            try:
                p=run(['curl','--silent','--show-error','--fail','--noproxy','',
                    '--proxy',f'socks5h://127.0.0.1:{socks}',
                    '--connect-timeout','8','--max-time','20','--output','/dev/null',
                    '--write-out','%{http_code}',url],timeout=24,check=False)
                if p.returncode==0 and p.stdout.startswith('2'): return
            except subprocess.TimeoutExpired: pass
    raise Failure('Authenticated REALITY tunnel could not fetch either HTTPS test page.')

def probe_reality(binary,node,work):
    port=free_port()
    cfg=server_config([node],'127.0.0.1'); cfg['inbounds'][0]['port']=port
    with start(binary,cfg,work,'probe-server') as proc:
        wait_port(proc,'127.0.0.1',port)
        test_tunnel(binary,node,'127.0.0.1',port,work,'probe-client')

def download_binary(destination,version):
    arch={'x86_64':'64','aarch64':'arm64-v8a'}.get(platform.machine())
    if not arch: raise Failure('Supported server architectures: x86_64 and aarch64.')
    if version and not re.fullmatch(r'v\d+\.\d+\.\d+',version):
        raise Failure('--version must look like v26.3.27.')
    route='tags/'+version if version else 'latest'
    release=json.loads(curl('https://api.github.com/repos/XTLS/Xray-core/releases/'+route))
    if release.get('draft') or release.get('prerelease'): raise Failure('Stable releases only.')
    tag=release['tag_name']; name=f'Xray-linux-{arch}.zip'
    asset=next((x for x in release['assets'] if x['name']==name),None)
    if not asset: raise Failure('Official Linux asset was not found.')
    expected=asset.get('digest','') or ''
    if not re.fullmatch(r'sha256:[0-9a-f]{64}',expected):
        raise Failure('Official SHA-256 asset digest is missing; refusing unverified download.')
    url=asset['browser_download_url']
    if not url.startswith('https://github.com/XTLS/Xray-core/releases/download/'):
        raise Failure('Unexpected release asset origin.')
    say('Downloading official Xray '+tag+'; checking SHA-256 ...')
    archive=pathlib.Path(destination)/'xray.zip'; curl(url,archive)
    if 'sha256:'+hashlib.sha256(archive.read_bytes()).hexdigest()!=expected:
        raise Failure('Xray download SHA-256 mismatch.')
    binary=pathlib.Path(destination)/'xray'
    with zipfile.ZipFile(archive) as z: binary.write_bytes(z.read('xray'))
    binary.chmod(0o755); archive.unlink()
    run([binary,'version'])
    return binary,tag

def make_link(node,ip):
    address='['+ip+']' if ':' in ip else ip
    params={'encryption':'none','security':'reality','sni':node['domain'],
            'fp':'chrome','pbk':node['public_key'],'sid':node['short_id'],
            'type':'tcp','flow':FLOW,'spx':'/'}
    return f"vless://{node['uuid']}@{address}:{node['port']}?"+urllib.parse.urlencode(params)+\
           '#'+urllib.parse.quote('REALITY-'+node['label']+'-'+str(node['port']))

def load_state():
    if not CURRENT.is_symlink(): raise Failure('No managed installation. Run install first.')
    guard_runtime()
    return validate_state(json.loads((CURRENT/'state.json').read_text()))

def active(): return run(['systemctl','is-active','--quiet',SERVICE],check=False).returncode==0

def swap_link(link,target):
    temp=link.with_name(link.name+'.new')
    temp.unlink(missing_ok=True); temp.symlink_to(target); temp.replace(link)

def health(path,live=True):
    state=json.loads((path/'state.json').read_text()); binary=path/'xray'
    config_test(binary,path/'config.json')
    if live and not active(): raise Failure('Managed service is not active.')
    with tempfile.TemporaryDirectory(prefix='reality-check-') as td:
        for node in state['nodes']:
            test_tunnel(binary,node,loopback(state['server_ip']),node['port'],td,'health-client')
            say(f"PASS {node['label']} :{node['port']} — authenticated server-local tunnel")
    say('This does NOT test the cloud firewall, public inbound path, or an Iranian ISP.')

def unit_text():
    return f'''[Unit]
Description=Managed VLESS REALITY server
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=60
StartLimitBurst=5

[Service]
User={USER}
Group={USER}
ExecStart={CURRENT}/xray run -c {CURRENT}/config.json
Restart=on-failure
RestartSec=3
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
AmbientCapabilities=CAP_NET_BIND_SERVICE
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
'''

def install(args):
    updating=args.command=='update'
    if ROOT.exists(): guard_runtime(allow_empty=True)
    if CURRENT.exists() and args.command=='install':
        say('Already installed; preserving version, configuration and credentials.')
        promote_manager(); health(CURRENT); show_links(); return
    if UNIT.exists() and not CURRENT.is_symlink():
        raise Failure('Service name already exists outside this managed installation.')
    old=load_state() if args.command in ('update','reconfigure') or (args.command=='reinstall' and CURRENT.exists()) else None
    if old is None and SAVED.exists():
        receipt_data(); old=validate_state(json.loads(SAVED.read_text()))
        say('Restoring saved connection credentials from the previous uninstall.')
    ip=public_ip(args.server_ip) if args.server_ip or not old else old['server_ip']
    say('Client endpoint IP: '+ip)
    preserve_profiles=bool(old and args.command!='reconfigure' and not args.ports and not args.domains)
    if preserve_profiles:
        specs=[(n['label'],[n['domain']],n['port'],n) for n in old['nodes']]
    else:
        previous_specs=old.get('requested_profiles',[]) if old else []
        default_ports=','.join(str(p['port']) for p in previous_specs) if len(previous_specs)==4 else '2025,2026,2027,2028'
        try: ports=[int(p) for p in (args.ports or default_ports).split(',')]
        except ValueError: raise Failure('--ports must contain four comma-separated integers.')
        if len(ports)!=4 or len(set(ports))!=4 or any(p<1 or p>65535 for p in ports):
            raise Failure('Exactly four distinct ports in range 1..65535 are required.')
        candidates=[(p['label'],p['domains']) for p in previous_specs] if len(previous_specs)==4 else copy.deepcopy(DEFAULTS)
        if args.domains:
            domains=args.domains.split(',')
            if len(domains)!=4 or any(not re.fullmatch(r'(?=.{1,253}$)(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\.)+[A-Za-z]{2,63}',d) for d in domains):
                raise Failure('--domains requires four plain DNS names, without URL/port/path.')
            candidates=[(label,[domain]) for (label,_),domain in zip(candidates,domains)]
        # Do not stop or replace another process occupying a requested port.
        own_ports={n['port'] for n in old['nodes']} if old and active() else set()
        for port in ports:
            if port in own_ports: continue
            try:
                with socket.socket(family(ip)) as s: s.bind(('::' if ':' in ip else '0.0.0.0',port))
            except OSError: raise Failure(f'TCP port {port} is occupied. Choose other --ports.')
        by_label={n['label']:n for n in old['nodes']} if old else {}
        specs=[(label,domains,port,by_label.get(label)) for (label,domains),port in zip(candidates,ports)]
    meta=receipt_data(create=True)
    ROOT.mkdir(mode=0o755,parents=True,exist_ok=True); ROOT.chmod(0o755)
    MARKER.write_text(OWNER+'\n'); MARKER.chmod(0o600)
    (ROOT/'releases').mkdir(mode=0o755,exist_ok=True); (ROOT/'releases').chmod(0o755)
    with tempfile.TemporaryDirectory(prefix='reality-stage-') as td:
        selected_version=args.version or (old['version'] if old and args.command!='update' else None)
        binary,version=download_binary(td,selected_version)
        nodes=[]; failures=[]
        for label,domains,port,previous_node in specs:
            creds=previous_node or new_credentials(binary)
            for domain in domains:
                say(f'Testing {label}: {domain}:443 ...')
                node={**creds,'label':label,'domain':domain,'port':port}
                try:
                    probe_target(domain); probe_reality(binary,node,td)
                    nodes.append(node); say('  PASS: TLS + authenticated REALITY + HTTPS'); break
                except (Failure,subprocess.TimeoutExpired) as e:
                    say('  FAIL: '+str(e)); failures.append(f'{label} {domain}: {e}')
            else:
                if previous_node: raise Failure('An existing profile failed testing; old installation is unchanged.')
                say(f'  SKIPPED {label}; no broken connection link will be exported.')
        if not nodes: raise Failure('No target passed. Nothing was activated. Check server DNS/outbound access.')
        cfg=server_config(nodes,'::' if ':' in ip else '0.0.0.0')
        write_json(pathlib.Path(td)/'config.json',cfg); config_test(binary,pathlib.Path(td)/'config.json')
        if run(['getent','passwd',USER],check=False).returncode:
            run(['useradd','--system','--user-group','--no-create-home','--shell','/usr/sbin/nologin',USER])
            meta['user_created']=True; write_json(RECEIPT,meta)
        import pwd,grp
        account=pwd.getpwnam(USER); gid=grp.getgrnam(USER).gr_gid
        if account.pw_uid==0 or account.pw_shell not in ('/usr/sbin/nologin','/sbin/nologin','/bin/false'):
            raise Failure('Existing realitysvc user is unsuitable for a dedicated service.')
        release=ROOT/'releases'/(time.strftime('%Y%m%dT%H%M%S')+'-'+secrets.token_hex(3))
        release.mkdir(mode=0o750); release.chmod(0o750); os.chown(release,0,gid)
        shutil.copy2(binary,release/'xray')
        write_json(release/'config.json',cfg,0o640); os.chown(release/'config.json',0,gid)
        state={'schema':1,'version':version,'server_ip':ip,'nodes':nodes,'failed_candidates':failures,
               'requested_profiles':old.get('requested_profiles',[]) if preserve_profiles else
               [dict(label=label,domains=domains,port=port) for label,domains,port,_ in specs]}
        write_json(release/'state.json',state)
        (release/'links.txt').write_text('\n'.join(make_link(n,ip) for n in nodes)+'\n')
        (release/'links.txt').chmod(0o600)
        (release/'install-report.txt').write_text('Xray '+version+'\n'+
           '\n'.join(f"PASS {n['label']} {n['domain']} TCP/{n['port']}" for n in nodes)+
           '\nFailed candidates:\n'+'\n'.join(failures)+'\n')
        (release/'install-report.txt').chmod(0o600)
        old_path=CURRENT.resolve() if CURRENT.is_symlink() else None
        old_unit=UNIT.read_bytes() if UNIT.exists() else None
        was_active=active()
        was_enabled=run(['systemctl','is-enabled','--quiet',SERVICE],check=False).returncode==0
        try:
            UNIT.write_text(unit_text()); UNIT.chmod(0o644)
            swap_link(CURRENT,release)
            run(['systemctl','daemon-reload']); run(['systemctl','restart',SERVICE])
            for n in nodes: wait_port(None,loopback(ip),n['port'])
            health(CURRENT)
            run(['systemctl','enable',SERVICE])
            if old_path: swap_link(PREVIOUS,old_path)
        except BaseException:
            say('Activation failed; restoring previous service and release ...')
            run(['systemctl','stop',SERVICE],check=False)
            if old_path: swap_link(CURRENT,old_path)
            else: CURRENT.unlink(missing_ok=True)
            if old_unit is not None: UNIT.write_bytes(old_unit)
            else: UNIT.unlink(missing_ok=True)
            run(['systemctl','daemon-reload'],check=False)
            if was_enabled: run(['systemctl','enable',SERVICE],check=False)
            else: run(['systemctl','disable',SERVICE],check=False)
            if was_active: run(['systemctl','start',SERVICE],check=False)
            raise
        promote_manager()
        add_firewall_rules(nodes,args.no_ufw)
        SAVED.unlink(missing_ok=True)
        say('READY: '+str(len(nodes))+'/4 profiles.')
        say('Cloud/provider firewall: allow inbound TCP on '+','.join(str(n['port']) for n in nodes)+'.')
        say('If NAT is used, forward the same external ports to this host. Check the public IP above.')
        say('Public connectivity must be tested from the client.')
        say('Report: sudo cat /opt/reality-oneclick/current/install-report.txt')
        say('Direct config links:')
        show_links()

def rollback():
    guard_runtime()
    if not PREVIOUS.is_symlink(): raise Failure('No previous successful release to restore.')
    prior=PREVIOUS.resolve(); current=CURRENT.resolve()
    if not prior.is_relative_to(ROOT/'releases'): raise Failure('Previous release is outside the managed directory.')
    config_test(prior/'xray',prior/'config.json')
    try:
        swap_link(CURRENT,prior); run(['systemctl','restart',SERVICE]); health(CURRENT)
    except BaseException:
        swap_link(CURRENT,current); run(['systemctl','restart',SERVICE],check=False); raise
    swap_link(PREVIOUS,current); say('Rollback completed.'); show_links()

def validate_state(state):
    if state.get('schema')!=1 or not isinstance(state.get('nodes'),list) or not state['nodes']:
        raise Failure('Invalid managed state.')
    valid_ip(state['server_ip'])
    for n in state['nodes']:
        uuid.UUID(n['uuid'])
        if not isinstance(n['port'],int) or not 1<=n['port']<=65535: raise Failure('Invalid saved port.')
        for key in ('private_key','public_key'):
            if not re.fullmatch(r'[A-Za-z0-9_-]{43}',n[key]): raise Failure('Invalid saved key.')
        if not re.fullmatch(r'[0-9a-f]{16}',n['short_id']): raise Failure('Invalid saved short ID.')
    return state

def guard_runtime(allow_empty=False):
    if ROOT.is_symlink() or UNIT.is_symlink() or (ROOT/'releases').is_symlink(): raise Failure('Managed root/unit cannot be symlinks.')
    if UNIT.exists() and f'ExecStart={CURRENT}/xray run -c {CURRENT}/config.json' not in UNIT.read_text():
        raise Failure('Service belongs to another installation; refusing to change it.')
    if not ROOT.exists():
        if UNIT.exists(): raise Failure('Service exists without its managed runtime; inspect manually.')
        return
    if not any(ROOT.iterdir()) and allow_empty: return
    if MARKER.is_symlink(): raise Failure('Invalid ownership marker.')
    has_marker=MARKER.exists() and MARKER.read_text().strip()==OWNER
    legacy=CURRENT.is_symlink() and UNIT.exists()
    if not has_marker and not legacy: raise Failure('Directory ownership is unrecognized; refusing to delete or overwrite it.')
    if CURRENT.is_symlink():
        release=CURRENT.resolve()
        if not release.is_relative_to(ROOT/'releases') or not (release/'state.json').is_file():
            raise Failure('Invalid managed release path.')
        validate_state(json.loads((release/'state.json').read_text()))
    elif CURRENT.exists(): raise Failure('Expected a managed current-release symlink.')

def receipt_data(create=False):
    if DATA.is_symlink() or RECEIPT.is_symlink() or SAVED.is_symlink():
        raise Failure('Managed state paths cannot be symlinks.')
    if RECEIPT.exists():
        meta=json.loads(RECEIPT.read_text())
        if meta.get('owner')!=OWNER: raise Failure('Unrecognized ownership receipt.')
        return meta
    if DATA.exists() and any(DATA.iterdir()): raise Failure('State directory already contains unowned data.')
    meta={'owner':OWNER,'ufw_tag':'reality-oc-'+secrets.token_hex(6),'ufw_ports':[],'user_created':False}
    if create:
        DATA.mkdir(mode=0o700,parents=True,exist_ok=True); DATA.chmod(0o700);write_json(RECEIPT,meta)
    return meta

def promote_manager():
    source=pathlib.Path(os.environ['REALITY_INSTALLER_SOURCE'])
    if MANAGER.is_symlink(): raise Failure('Manager path is a symlink.')
    if MANAGER.exists() and not MANAGER.read_text().startswith('#!/usr/bin/env bash\n# REALITY One Click'):
        raise Failure('Manager path belongs to another program.')
    if source.resolve()!=MANAGER.resolve():
        temp=MANAGER.with_name(MANAGER.name+'.new')
        if temp.exists() or temp.is_symlink(): raise Failure('Stale manager staging path; inspect '+str(temp))
        try:
            with temp.open('x') as f:
                os.chmod(temp,0o700);f.write(source.read_text());f.flush();os.fsync(f.fileno())
            temp.replace(MANAGER)
        finally: temp.unlink(missing_ok=True)

def show_links(profile=None):
    state=load_state(); nodes=state['nodes']
    if profile:
        nodes=[n for n in nodes if n['label'].casefold()==profile.casefold() or str(n['port'])==profile]
        if not nodes: raise Failure('Unknown profile. Use Google, ChatGPT, GSMArena, Microsoft, or a configured port.')
    # stdout contains only direct client configuration URIs, never a subscription URL.
    print('\n'.join(make_link(n,state['server_ip']) for n in nodes),flush=True)

def ufw_rules():
    p=run(['ufw','show','added'])
    result=[]
    for line in p.stdout.splitlines():
        if line.startswith('ufw '): result.append(shlex.split(line))
    return result

def add_firewall_rules(nodes,disabled=False):
    if disabled or not shutil.which('ufw'): return
    status=run(['ufw','status'],check=False)
    if status.returncode or 'Status: active' not in status.stdout: return
    meta=receipt_data(create=True)
    try:
        rules=ufw_rules()
        for n in nodes:
            port=str(n['port']);tag=meta['ufw_tag']
            expected=['ufw','allow',port+'/tcp','comment',tag]
            if expected in rules: continue
            # Respect any existing allow rule mentioning this port. It may be source-limited.
            if any('allow' in r and (port in r or port+'/tcp' in r) for r in rules):
                say('Existing UFW allow rule retained for '+port+'; check its source/family coverage.');continue
            if n['port'] not in meta['ufw_ports']:
                meta['ufw_ports'].append(n['port']);write_json(RECEIPT,meta)
            run(['ufw','allow',port+'/tcp','comment',tag]);rules=ufw_rules()
    except (Failure,subprocess.TimeoutExpired) as e:
        say('UFW setup incomplete: '+str(e)+'; check firewall manually.')

def remove_firewall_rules(meta):
    if not meta['ufw_ports']: return
    if not shutil.which('ufw'): raise Failure('Cannot clean recorded UFW rules while ufw is unavailable.')
    rules=ufw_rules();tag=meta['ufw_tag']
    for port in list(meta['ufw_ports']):
        expected=['ufw','allow',str(port)+'/tcp','comment',tag]
        if expected in rules:
            run(['ufw','--force','delete','allow',str(port)+'/tcp','comment',tag])
            rules=ufw_rules()
            if expected in rules: raise Failure('UFW rule was not removed; uninstall can be retried.')
        meta['ufw_ports'].remove(port);write_json(RECEIPT,meta)

def confirm_uninstall(args):
    if args.yes: return
    message=('حذف کامل، اطلاعات اتصال ذخیره‌شده را نیز پاک می‌کند.' if args.purge else
             'سرویس حذف می‌شود؛ اطلاعات اتصال برای نصب مجدد نگه داشته می‌شود.')
    try:
        with open('/dev/tty','r+') as tty:
            tty.write(message+'\nبرای ادامه عبارت DELETE را وارد کنید: ');tty.flush()
            if tty.readline().strip()=='DELETE': return
    except OSError: pass
    raise Failure('Uninstall cancelled. For noninteractive use, add --yes.')

def uninstall(args):
    guard_runtime()
    meta=receipt_data(create=False)
    manager_owned=MANAGER.exists() and not MANAGER.is_symlink() and MANAGER.read_text().startswith(
        '#!/usr/bin/env bash\n# REALITY One Click')
    if not ROOT.exists() and not SAVED.exists() and not RECEIPT.exists() and not manager_owned:
        say('Nothing managed is installed.');return
    confirm_uninstall(args)
    meta=receipt_data(create=True)
    if CURRENT.is_symlink():
        # Always checkpoint before stopping, even for purge; erase after successful removal.
        write_json(SAVED,load_state())
    if UNIT.exists():
        run(['systemctl','stop',SERVICE])
        if active(): raise Failure('Service is still active. No runtime files were deleted.')
        run(['systemctl','disable',SERVICE])
    remove_firewall_rules(meta)
    if UNIT.exists(): UNIT.unlink();run(['systemctl','daemon-reload'])
    run(['systemctl','reset-failed',SERVICE],check=False)
    if ROOT.exists(): shutil.rmtree(ROOT)
    if args.purge:
        SAVED.unlink(missing_ok=True)
        if meta.get('user_created') and run(['getent','passwd',USER],check=False).returncode==0:
            run(['userdel',USER])
            if run(['getent','group',USER],check=False).returncode==0:
                run(['groupdel',USER])
        # Remove only known receipt/state files; never recurse over unknown files in DATA.
        RECEIPT.unlink(missing_ok=True)
        if DATA.exists() and not any(DATA.iterdir()): DATA.rmdir()
        if manager_owned: MANAGER.unlink()
        say('PURGE OK: managed runtime and saved connection credentials removed.')
    else:
        promote_manager()
        say('UNINSTALL OK: connection credentials preserved; reinstall with sudo reality-manager install')
    say('Shared packages and firewall rules without this installation\'s unique tag are retained.')

def service_command(command):
    if command=='status' and not CURRENT.exists():
        say('Service is not installed. Saved credentials: '+('yes' if SAVED.exists() else 'no'));return
    state=load_state()
    if command=='status':
        say('Xray '+state['version']+'; service '+('active' if active() else 'inactive'))
        for n in state['nodes']: say(n['label']+' TCP/'+str(n['port'])+' '+n['domain'])
    elif command=='logs':
        say(run(['journalctl','-u',SERVICE,'-n','60','--no-pager']).stdout)
    elif command in ('start','stop','restart'):
        run(['systemctl',command,SERVICE])
        if command!='stop':
            for n in state['nodes']: wait_port(None,loopback(state['server_ip']),n['port'])
        say(command.upper()+' OK')

def main():
    parser=argparse.ArgumentParser(description='Managed VLESS REALITY installer 1.1')
    parser.add_argument('command',nargs='?',default='install',choices=[
        'install','reinstall','uninstall','check','links','status','start','stop','restart',
        'logs','update','reconfigure','rollback'])
    parser.add_argument('--server-ip'); parser.add_argument('--ports')
    parser.add_argument('--domains'); parser.add_argument('--version'); parser.add_argument('--no-ufw',action='store_true')
    parser.add_argument('--profile'); parser.add_argument('--purge',action='store_true');parser.add_argument('--yes',action='store_true')
    args=parser.parse_args()
    if args.command=='update' and (args.server_ip or args.domains or args.ports):
        raise Failure('Update preserves current endpoints; use reconfigure to change them.')
    if (args.purge or args.yes) and args.command!='uninstall': raise Failure('--purge/--yes are uninstall options.')
    if args.profile and args.command!='links': raise Failure('--profile is a links option.')
    if args.command not in ('install','reinstall','update','reconfigure') and any([
        args.server_ip,args.ports,args.domains,args.version,args.no_ufw]):
        raise Failure('Install options cannot be used with this command.')
    os.umask(0o077)
    with open('/run/lock/reality-oneclick.lock','w') as lock:
        try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise Failure('Another reality-manager process is running.')
        if args.command in ('install','reinstall','update','reconfigure'): install(args)
        elif args.command=='check': load_state(); health(CURRENT)
        elif args.command=='links': show_links(args.profile)
        elif args.command=='rollback': rollback()
        elif args.command=='uninstall': uninstall(args)
        else: service_command(args.command)

if __name__=='__main__':
    try: main()
    except KeyboardInterrupt: say('\nInterrupted.'); sys.exit(130)
    except Exception as e: say('ERROR: '+str(e)); sys.exit(1)
PYTHON
