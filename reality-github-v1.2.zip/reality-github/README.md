# REALITY One Click 1.2

A lightweight English terminal manager for **VLESS + TCP + REALITY + Vision** on Ubuntu 22.04 or newer, with systemd, on x86_64 or ARM64.

The manager runs only when you invoke it. Xray is the persistent service. No web panel, database, scheduled updater, or additional Python packages are required. Connections are exported as individual `vless://` links.

## Upgrade an existing 1.1 installation

Upload **reality-github-v1.2.zip** to the root of the `main` branch of [manwithoutpant/rerere](https://github.com/manwithoutpant/rerere). Keep the filename exactly as shown. The following URL works only after that upload.

Run this command on the server where 1.1 is already installed:

```bash
sudo bash -c 'set -e; reality_tmp=$(mktemp -d); trap "rm -rf -- \"$reality_tmp\"" EXIT; curl -fL --proto "=https" --proto-redir "=https" --retry 3 --connect-timeout 15 --max-time 120 "https://raw.githubusercontent.com/manwithoutpant/rerere/main/reality-github-v1.2.zip" -o "$reality_tmp/package.zip"; unzip -p "$reality_tmp/package.zip" "reality-github/reality-oneclick.sh" > "$reality_tmp/reality-oneclick.sh"; test -s "$reality_tmp/reality-oneclick.sh"; bash "$reality_tmp/reality-oneclick.sh" manager-update'
```

Then open the English menu:

```bash
sudo reality-manager
```

`manager-update` replaces only the manager script. It preserves the installed Xray version, all profile credentials and settings, and the current service state. It does not restart Xray. This command expects the `curl` and `unzip` packages already used by the 1.1 ZIP installer.

You do not need to upload files manually to the VPS. The command downloads and extracts the script into a temporary directory, installs the manager, and removes the temporary files.

## Fresh installation from GitHub

After uploading the same ZIP to the repository, run:

```bash
sudo bash -c 'set -e; export DEBIAN_FRONTEND=noninteractive; apt-get update -qq; apt-get install -y -qq ca-certificates curl unzip; reality_tmp=$(mktemp -d); trap "rm -rf -- \"$reality_tmp\"" EXIT; curl -fL --proto "=https" --proto-redir "=https" --retry 3 --connect-timeout 15 --max-time 120 "https://raw.githubusercontent.com/manwithoutpant/rerere/main/reality-github-v1.2.zip" -o "$reality_tmp/package.zip"; unzip -p "$reality_tmp/package.zip" "reality-github/reality-oneclick.sh" > "$reality_tmp/reality-oneclick.sh"; test -s "$reality_tmp/reality-oneclick.sh"; bash "$reality_tmp/reality-oneclick.sh" install'
```

The installer checks prerequisites, downloads an official stable Xray release, verifies the SHA-256 asset digest provided by GitHub, tests candidate targets, and activates only successful profiles. Missing digests, failed downloads, or invalid configurations stop installation. Existing installations retain their credentials on reinstall.

Alternatively, publish the extracted source files at the repository root. After `reality-oneclick.sh` exists there, this source-file command can be used:

```bash
curl -fL --proto '=https' --proto-redir '=https' 'https://raw.githubusercontent.com/manwithoutpant/rerere/main/reality-oneclick.sh' -o reality-oneclick.sh && sudo bash reality-oneclick.sh install
```

This alternative URL does not work merely because a ZIP was uploaded. Do not pipe the source directly to Bash: the manager must copy itself from a downloaded file. A published commit ID can replace `main` to pin the downloaded installer source.

## English menu

The menu begins with a numbered table containing the profile name, TCP port, domain/SNI, and state.

| Action | Menu option |
| --- | --- |
| Copy one direct connection link, or all enabled links | Show config link |
| Change one profile's public TCP port | Change port |
| Change its REALITY target and SNI together | Change domain |
| Change the display name in the list and exported link | Rename profile |
| Temporarily disable a profile or restore it with the same credentials | Enable / disable |
| Test an authenticated tunnel from the server | Test profile |
| Control Xray, inspect logs, update, reinstall, roll back, or remove | Service / maintenance |

`ENABLED` means the profile is configured and the service is active; it does not certify client connectivity. `STOPPED` means the enabled profile's service is stopped. `DISABLED` profiles retain credentials but have no configured inbound and are omitted from link exports. `NOT SET` means the candidate was not installed, for example because its target failed testing. Choose **Change domain** for that row to try a different target.

For the reported 1.1 installation, Google, ChatGPT, and Microsoft will keep their existing settings. GSMArena will appear as `NOT SET` until a target passes its tests. No replacement domain is silently chosen during the manager upgrade.

## Direct commands

Select profiles by table number, stable ID (`Google`, `ChatGPT`, `GSMArena`, `Microsoft`), or assigned port. When a number could be both a row number and a port, the row number takes precedence. Display names do not change the stable ID.

```bash
sudo reality-manager list
sudo reality-manager edit --profile Google --port 443
sudo reality-manager edit --profile Google --domain dl.google.com
sudo reality-manager edit --profile Google --name 'Personal Google'
sudo reality-manager disable --profile Google
sudo reality-manager enable --profile Google
sudo reality-manager check --profile Google
sudo reality-manager links --profile Google
sudo reality-manager links
```

A single `edit` may combine `--port`, `--domain`, and `--name`. English display names may use letters, digits, spaces, dots, dashes, and underscores, up to 40 characters. Domains must be plain DNS names without a URL scheme, port, or path. The outgoing target port remains **443**; the editable public incoming port is separate.

Port/domain changes and enabling a profile are staged and tested with the already installed Xray binary. Other profiles' credentials and settings are preserved. Invalid, conflicting, or occupied ports are rejected. A new domain must pass TLS 1.3, certificate/hostname, ALPN h2, and authenticated REALITY/HTTPS tests before activation.

Active configuration changes restart the single Xray service, briefly interrupting all profiles. A failed activation restores the previous configuration. Changes made while the service is stopped leave it stopped. Renaming alone does not restart the service. Editing reuses the core binary through a hard link; it does not download another copy.

**After changing a port or domain, replace that profile's link in every client.** A direct link is static and does not update itself. Renaming also produces a link with the new display name.

## Default profile slots

| ID | Public TCP port | First candidate domain |
| --- | ---: | --- |
| Google | 2025 | `www.google.com` |
| ChatGPT | 2026 | `chatgpt.com` |
| GSMArena | 2027 | `www.gsmarena.com` |
| Microsoft | 2028 | `www.bing.com` |

Initial fallback candidates are `dl.google.com` for Google and `www.microsoft.com` for Microsoft. A slot reserves its assigned port even while disabled or not installed. These are four connection profiles on one server, with the same exit IP; they are not four exit locations.

## Maintenance

```bash
sudo reality-manager status
sudo reality-manager start
sudo reality-manager stop
sudo reality-manager restart
sudo reality-manager logs
sudo reality-manager check
sudo reality-manager update
sudo reality-manager rollback
sudo reality-manager reinstall
sudo reality-manager uninstall
sudo reality-manager uninstall --purge
```

- `update` explicitly downloads the latest official stable Xray release and tests it; it is never scheduled automatically. `--version v26.3.27` can pin a particular official stable release.
- `rollback` restores the immediately previous successful configuration/core release and restarts Xray. A rename also creates a saved release, so rollback means the previous operation, not necessarily the previous Xray version.
- `reinstall` preserves saved credentials and, unless explicitly changed, the core version and endpoints.
- `uninstall` removes the managed service/runtime and keeps credentials for `sudo reality-manager install`.
- `uninstall --purge` also erases this installation's saved credentials and manager. Both removal modes request `DELETE`; add `--yes` for an intentional noninteractive removal.
- After purge, use the fresh installation command again. Shared packages and unrelated files/firewall rules are preserved.

Bulk settings remain available for advanced use:

```bash
sudo reality-manager reconfigure --ports 443,2026,2027,2028
sudo reality-manager reconfigure --domains www.google.com,chatgpt.com,www.gsmarena.com,www.bing.com
sudo reality-manager reconfigure --server-ip YOUR_PUBLIC_IP
```

Replace `YOUR_PUBLIC_IP` with the server's actual public inbound IP. `reconfigure` without options retries the configured target candidates; it may fill a previously unsuccessful slot after a target starts passing.

## Firewall and client use

The script adds TCP allow rules only when UFW is already active, unless `--no-ufw` is used. It records ownership with unique comments. Existing rules are retained without relabeling. Old port rules remain available for rollback. Removal deletes only rules owned by this installation; it does not remove preexisting rules. Changing a profile's port does not change SSH.

Allow the new TCP port in the hosting provider's firewall, and forward that same port if NAT is used. A local test cannot verify those settings or an Iranian ISP's path.

Import each exported `vless://` link into a client with VLESS/REALITY/Vision support and an appropriate current core. Use the original complete link rather than replacing the server address with the target domain. Mux should be disabled. See the [English guide](docs/reality-guide.md) for client details and troubleshooting.

## Verification and source layout

```bash
bash -n reality-oneclick.sh
python3 -m unittest discover -s tests -p 'test_*.py' -v
python3 tests/integration_reality.py /absolute/path/to/official/xray
```

The unit/lifecycle tests use temporary filesystems and fake systemd/UFW. The terminal test exercises the real controlling-terminal input path. The integration test uses local temporary TLS fixtures and an official Xray binary; it checks authenticated HTTPS, invalid UUID rejection, private-address egress blocking, IPv4/IPv6 links, and disabling all profiles.

Version 1.2 was checked with 23 automated tests and the integration test using Xray **26.3.27**. This does not test a real VPS deployment, public targets, provider firewall, or connectivity from Iran. The installer performs public target and server-local tunnel checks when you run it on the VPS.

The archive contains source, English documentation, a license, and tests. It contains no Xray binary or live connection credentials. Never publish server `state.json`, `links.txt`, saved credentials, or runtime folders.

[Design choices and comparison](docs/script-comparison.md) · [Xray REALITY documentation](https://xtls.github.io/en/config/transports/reality.html)
