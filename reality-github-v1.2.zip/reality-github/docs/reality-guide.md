# REALITY One Click 1.2 — Usage guide

All manager menus, prompts, errors, and included documentation are in English. The installer uses Bash and Python's standard library. It creates a dedicated systemd Xray service and an on-demand terminal manager.

## Upgrade without changing active connections

Upload `reality-github-v1.2.zip` to the root of `manwithoutpant/rerere` on the `main` branch. Follow the manager-upgrade command in [README.md](../README.md), then run `sudo reality-manager`. The manager upgrade preserves the 1.1 service state, Xray version, credentials, IP, domains, and ports.

Use `manager-update` for upgrading this management interface; use `update` only when you intend to update Xray itself.

## Change a port

1. Open `sudo reality-manager`.
2. Choose **Change port**.
3. Select the profile number shown in the table.
4. Enter a TCP port from 1 through 65535, such as 443 if it is free.
5. Wait for staging, validation, and activation to finish.
6. Allow the new TCP port in your provider firewall/NAT and import the newly printed link into your client.

An existing HTTPS server may occupy 443. The manager rejects an occupied or already assigned port instead of stopping another program. Ports held by disabled or unset slots are also reserved. To free one, first change that other slot's assigned port. If an unset slot's target fails, set a working domain first, or combine `--port` and `--domain` in one command.

If UFW is active, an allow rule is added where needed. A previous user-created or source-limited rule is retained and reported. Old rules remain for rollback, including rules on ports no longer used. A disabled profile has no Xray inbound, even if its firewall rule remains present.

## Change a domain

Choose **Change domain**, select a row, and enter only a DNS name, for example `dl.google.com`.

This updates both the server's REALITY target (`domain:443`) and the client's SNI. It is not a change to the public VPS address. A target domain is not a domain you need to own, and the installer does not issue or renew a certificate for your VPS. The remote target still needs suitable TLS behavior; see [official REALITY configuration documentation](https://xtls.github.io/en/config/transports/reality.html).

The manager checks TLS 1.3, hostname/certificate verification, ALPN h2, and an authenticated test tunnel that retrieves an HTTPS page. A failed target is rejected before the live configuration is replaced. A working target today may change later. Matching a popular domain does not guarantee connectivity from a particular ISP or access to that domain's service.

For an existing profile, the UUID, X25519 keys, and short ID are retained. Only the selected profile's settings change. A new `NOT SET` profile receives new credentials only when it is successfully saved. A changed target or port requires reimporting that profile's new direct link into every client.

## Other small controls

- **Rename profile:** changes its displayed name and URI label. It retains the stable ID and connection credentials and does not restart Xray.
- **Enable / disable:** temporarily removes or restores a single inbound. Credentials remain saved. Disabled profiles do not appear in link exports. Re-enabling tests the target and port before activation.
- **Test profile:** sends an authenticated request through the running server-local tunnel. This is independent of provider firewall or client-path testing.
- **Show config link:** displays one enabled profile; enter `all` to display all enabled links. No subscription server or URL is created.
- **Service / maintenance:** status, start, stop, restart, recent logs, explicit core update, reinstall, rollback, uninstall, purge, and retrying target candidates.

Changes to enabled inbounds restart the one Xray process, so other connections may briefly reconnect even though their settings are retained. A metadata-only rename does not require a restart. If the service was stopped before an edit, it remains stopped. Disabling every profile is supported; Xray then has no configured inbounds.

## Client import

Choose a client whose installed core supports VLESS, REALITY, and `xtls-rprx-vision`. The generated links use `security=reality`, a Chrome fingerprint, a public key in the `pbk` URI parameter, a short ID, and TCP transport. Keep Mux disabled for this setup.

| Platform | Client references | Import |
| --- | --- | --- |
| Windows | [v2rayN](https://github.com/2dust/v2rayN) | Import the complete link from clipboard; use a compatible Xray core and configure system proxy or TUN as needed. |
| Android | [v2rayNG](https://github.com/2dust/v2rayNG) | Import from clipboard, select the profile, and connect. |
| iPhone/iPad | [Happ](https://www.happ.su/main), or a compatible current v2RayTun build | Import the complete link and enable the app's VPN connection. |

Client import labels vary by app version. These clients were not all installed and tested as part of this package. A successful server-local test is not evidence that every third-party client build accepts every parameter.

For **Husi**, consult its [official protocol compatibility notes](https://github.com/xchacha20-poly1305/husi/wiki/Proxy-Protocol), which describe limited REALITY compatibility. Do not assume that accepting a `vless://` link proves compatibility with this Xray setup. Hysteria 2 is a different protocol and is not enabled by this installer.

## Troubleshooting

| Symptom | Next check |
| --- | --- |
| `NOT SET` | Choose a different domain for that slot and let the target tests run. The previous failed attempt did not install that slot. |
| `STOPPED` | Use Service / maintenance → Start, then inspect Logs if startup fails. |
| `DISABLED` | Enable the selected profile to restore its listener and direct link. |
| TLS/certificate/h2 failure | Try another suitable target; do not bypass certificate verification to force a pass. |
| Port occupied | Choose a free TCP port, or inspect the other listener yourself. |
| Local test passes but client times out | Check public IP, provider firewall, NAT forwarding, client version/settings, and the client's network path. |
| Only an old link fails after editing | Remove or replace that profile with the newly exported link. |
| Edit failed during activation | The previous configuration is restored; inspect the reported error and `sudo reality-manager logs`. |
| Need the previous successful settings | Run `sudo reality-manager rollback`. This restores the immediately preceding saved operation. |

```bash
sudo reality-manager list
sudo reality-manager check
sudo reality-manager logs
sudo cat /opt/reality-oneclick/current/install-report.txt
```

Diagnostic logs can contain addresses or connection details. Review what you share. Configuration links are connection credentials.

## Files and removal

- `/usr/local/sbin/reality-manager`: installed management command.
- `/opt/reality-oneclick/current`: active managed release, including Xray, configuration, root-only saved state, direct links, and report.
- `/opt/reality-oneclick/previous`: previous successful release for rollback.
- `/var/lib/reality-oneclick`: ownership records and credentials preserved after ordinary uninstall.
- `/etc/systemd/system/reality-oneclick.service`: dedicated service unit.

The dedicated service account can read its configuration; state and connection links are root-only. Configuration edits share the immutable Xray binary with a hard link. Saved release metadata and older core releases remain available until removal; no web panel or background manager is added.

`uninstall` retains the saved credentials and manager. `uninstall --purge` erases this installation's saved credentials and manager after the service and owned firewall rules are removed successfully. Preexisting firewall rules, shared packages, and unrelated services are retained. A purge does not erase system journal history or copies you saved elsewhere.

## Scope of verification

The automated suite checks credentials and other profiles are preserved, failed changes roll back, disabled links/listeners are omitted, manager-only upgrades do not modify the service, real terminal input works, and uninstall respects ownership. Local integration with official Xray 26.3.27 checks authenticated REALITY/Vision HTTPS, authentication rejection, private-address blocking, zero enabled profiles, and URI encoding.

No changes have been applied to a VPS by preparing this package. Public connectivity must still be tested from the actual Windows, Android, or iPhone client after you run it on your server.
