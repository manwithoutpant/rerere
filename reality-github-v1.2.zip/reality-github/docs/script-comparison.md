# Design choices and comparison

This comparison uses the projects' own documentation. It is not a full source audit or a deployment test of those projects. Their installer code was not copied or executed to build this package.

| Project | Relevant documented features | Choice for this manager |
| --- | --- | --- |
| [XTLS/Xray-install](https://github.com/XTLS/Xray-install) | Core install/update, version selection, systemd, remove/purge | Retain explicit install/update, owned-service removal, and a dedicated service account. |
| [233boy/Xray](https://github.com/233boy/Xray) | Config management, URL/QR export, port/SNI/UUID changes, service commands, multiple protocols | Include an English profile list, independent port/domain edits, direct URI output, and service controls. |
| [MHSanaei/3x-ui](https://github.com/MHSanaei/3x-ui) | Web administration, users, traffic limits, expiration, statistics, QR, subscriptions | Keep this small single-server workflow in the terminal, with direct config links as requested. |

Version 1.2 adds profile editing, names, enable/disable, per-profile checks, and an upgrade command for the manager itself. Existing safeguards include official Xray digest verification, target and authenticated-tunnel checks, retaining credentials, rollback, and [UFW](https://manpages.ubuntu.com/manpages/bionic/man8/ufw.8.html) ownership tracking.

No web panel, database, Python dependency packages, scheduled service, subscription endpoint, extra proxy protocol, bandwidth quota, user billing, or kernel tuning is added. Those features require a different management scope. UUID/key rotation and arbitrary new profile slots are also outside this version; the four existing slots remain independently editable.

Port/domain changes use the installed core and share its binary between saved configurations. The only persistent process is the existing Xray systemd service. A menu action can briefly launch test clients/servers during validation; those processes are cleaned up after the test.
