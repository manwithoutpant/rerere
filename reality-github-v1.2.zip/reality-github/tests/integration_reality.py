import sys,pathlib,tempfile,subprocess,ssl,http.server,threading,copy,urllib.parse
import types
script=pathlib.Path(__file__).resolve().parents[1]/'reality-oneclick.sh'
source=script.read_text().split("<<'PYTHON'\n",1)[1].rsplit('\nPYTHON',1)[0]
m=types.ModuleType('installer');exec(compile(source,str(script),'exec'),m.__dict__)
if len(sys.argv)!=2: raise SystemExit('Usage: python3 tests/integration_reality.py /path/to/official/xray')
binary=pathlib.Path(sys.argv[1]).resolve()
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  body=b'reality-integration-ok'; self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def log_message(self,*a): pass
with tempfile.TemporaryDirectory(prefix='reality-integration-') as td:
 td=pathlib.Path(td);cert=td/'cert.pem';key=td/'key.pem'
 m.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',key,'-out',cert,'-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1'])
 target_port=m.free_port(); server_port=m.free_port()
 target=subprocess.Popen(['openssl','s_server','-accept','127.0.0.1:'+str(target_port),'-cert',str(cert),'-key',str(key),'-tls1_3','-alpn','h2','-www'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 web=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
 ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(cert,key)
 web.socket=ctx.wrap_socket(web.socket,server_side=True);threading.Thread(target=web.serve_forever,daemon=True).start()
 try:
  m.wait_port(target,'127.0.0.1',target_port)
  node=dict(label='Fixture',domain='localhost',port=server_port,**m.new_credentials(binary))
  disabled=m.server_config([{**node,'enabled':False}],'127.0.0.1')
  m.write_json(td/'disabled.json',disabled);m.config_test(binary,td/'disabled.json')
  with m.start(binary,disabled,td,'disabled-server') as proc:
   try:
    proc.wait(timeout=.4)
    raise AssertionError('Core exited with all profiles disabled: '+(td/'disabled-server.log').read_text())
   except subprocess.TimeoutExpired:pass
  print('PASS: all profiles disabled is a valid, running Xray configuration',flush=True)
  cfg=m.server_config([node],'127.0.0.1')
  cfg['inbounds'][0]['streamSettings']['realitySettings']['target']='127.0.0.1:'+str(target_port)
  # Isolated fixture needs loopback HTTPS egress. Production keeps its private-IP rule.
  cfg['routing']['rules']=[]
  with m.start(binary,cfg,td,'server') as proc:
   m.wait_port(proc,'127.0.0.1',server_port)
   for good in (True,False):
    n=copy.deepcopy(node)
    if not good: n['uuid']=str(m.uuid.uuid4())
    socks=m.free_port(); client=m.client_config(n,'127.0.0.1',server_port,socks)
    with m.start(binary,client,td,'client') as cp:
     m.wait_port(cp,'127.0.0.1',socks)
     r=m.run(['curl','-sS','--noproxy','','--proxy',f'socks5h://127.0.0.1:{socks}','--max-time','18','--cacert',cert,f'https://127.0.0.1:{web.server_port}/'],timeout=22,check=False)
     if good:
      if r.returncode or r.stdout!='reality-integration-ok':
       print((td/'server.log').read_text());print((td/'client.log').read_text()); raise AssertionError(r.stderr)
      print('PASS: authenticated REALITY + Vision + verified HTTPS payload',flush=True)
     else:
      assert r.returncode!=0 and 'reality-integration-ok' not in r.stdout
      print('PASS: invalid VLESS UUID cannot retrieve HTTPS payload',flush=True)
  # Production private-address rule rejects the same local destination.
  cfg['routing']=m.server_config([node],'127.0.0.1')['routing']
  with m.start(binary,cfg,td,'restricted-server') as proc:
   m.wait_port(proc,'127.0.0.1',server_port)
   socks=m.free_port()
   with m.start(binary,m.client_config(node,'127.0.0.1',server_port,socks),td,'restricted-client') as cp:
    m.wait_port(cp,'127.0.0.1',socks)
    r=m.run(['curl','-sS','--noproxy','','--proxy',f'socks5h://127.0.0.1:{socks}','--max-time','6','--cacert',cert,f'https://127.0.0.1:{web.server_port}/'],timeout=10,check=False)
    assert r.returncode!=0
    print('PASS: production routing blocks private-address egress',flush=True)
  for ip in ('8.8.8.8','2606:4700:4700::1111'):
   uri=m.make_link(node,ip);parsed=urllib.parse.urlsplit(uri); q=urllib.parse.parse_qs(parsed.query)
   assert parsed.hostname==ip and parsed.port==server_port and q['pbk']==[node['public_key']]
  print('PASS: IPv4/IPv6 URI encoding',flush=True)
 finally:
  target.terminate();target.wait(timeout=5);web.shutdown();web.server_close()
