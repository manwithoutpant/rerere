"""Lifecycle tests use a temporary filesystem and fake systemd/UFW, never the host service."""
import contextlib, copy, io, json, pathlib, shlex, subprocess, tempfile, types, unittest
from unittest.mock import patch

SCRIPT=pathlib.Path(__file__).resolve().parents[1]/'reality-oneclick.sh'
source=SCRIPT.read_text().split("<<'PYTHON'\n",1)[1].rsplit('\nPYTHON',1)[0]
m=types.ModuleType('reality_installer');exec(compile(source,str(SCRIPT),'exec'),m.__dict__)

class LifecycleTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.base=pathlib.Path(self.temp.name)
        self.patches=contextlib.ExitStack();self.addCleanup(self.patches.close);self.addCleanup(self.temp.cleanup)
        root=self.base/'runtime';data=self.base/'data'
        for name,value in dict(ROOT=root,CURRENT=root/'current',PREVIOUS=root/'previous',MARKER=root/'.managed-by',
            DATA=data,RECEIPT=data/'ownership.json',SAVED=data/'saved-state.json',
            UNIT=self.base/'test.service',MANAGER=self.base/'reality-manager').items():
            self.patches.enter_context(patch.object(m,name,value))
        self.patches.enter_context(patch.dict(m.os.environ,{'REALITY_INSTALLER_SOURCE':str(SCRIPT)}))
        self.running=True;self.rules=[];self.calls=[];self.fail_stop=False;self.fail_ufw=False
        self.patches.enter_context(patch.object(m,'run',self.fake_run))
        self.patches.enter_context(patch.object(m.shutil,'which',return_value='/usr/sbin/ufw'))
        self.node=dict(label='Google',domain='dl.google.com',port=m.free_port(),
            uuid='c3d7c4d7-9662-471e-9e1e-d627668e1bf2',private_key='A'*43,public_key='B'*43,short_id='0123456789abcdef')
        self.state=dict(schema=1,version='v26.3.27',server_ip='8.8.8.8',nodes=[self.node],failed_candidates=[],
            requested_profiles=[dict(label=label,domains=domains,port=port) for (label,domains),port in zip(m.DEFAULTS,[self.node['port'],2026,2027,2028])])
        self.release=root/'releases'/'old';self.release.mkdir(parents=True)
        m.MARKER.write_text(m.OWNER);m.write_json(self.release/'state.json',self.state)
        m.write_json(self.release/'config.json',m.server_config(self.state['nodes'],'0.0.0.0'))
        (self.release/'xray').write_text('fixture')
        m.CURRENT.symlink_to(self.release);m.UNIT.write_text(m.unit_text());m.MANAGER.write_text(SCRIPT.read_text())
        self.meta=m.receipt_data(create=True)
        self.unrelated=self.base/'unrelated.conf';self.unrelated.write_text('keep')

    def fake_run(self,args,check=True,**kwargs):
        a=[str(x) for x in args];self.calls.append(a);out='';code=0
        if a[0]=='systemctl':
            action=a[1]
            if action=='is-active': code=0 if self.running else 3
            elif action=='stop':
                if self.fail_stop: code=1
                else: self.running=False
            elif action in ('start','restart'): self.running=True
        elif a[:3]==['ufw','show','added']:
            out='Added user rules:\n'+'\n'.join(shlex.join(r) for r in self.rules)
        elif a[:2]==['ufw','status']: out='Status: active\n'
        elif a[:3]==['ufw','--force','delete']:
            if self.fail_ufw: code=1
            else: self.rules.remove(['ufw']+a[3:])
        elif a[:2]==['ufw','allow']: self.rules.append(a)
        elif a[0]=='getent': code=0
        result=subprocess.CompletedProcess(a,code,out,'injected failure' if code else '')
        if check and code: raise m.Failure('injected failure')
        return result

    def args(self,command='uninstall',**kwargs):
        return types.SimpleNamespace(**dict(command=command,purge=kwargs.get('purge',False),yes=True,
            server_ip=None,ports=None,domains=None,version=None,no_ufw=False,profile=None))

    def mock_install_environment(self):
        def download(folder,version):
            path=pathlib.Path(folder)/'xray';path.write_text('new binary');return path,version or 'v26.4.1'
        self.patches.enter_context(patch.object(m,'download_binary',side_effect=download))
        self.patches.enter_context(patch.object(m,'probe_target'))
        self.patches.enter_context(patch.object(m,'probe_reality'))
        self.patches.enter_context(patch.object(m,'config_test'))
        self.patches.enter_context(patch.object(m,'wait_port'))
        self.patches.enter_context(patch.object(m.os,'chown'))
        import pwd,grp
        self.patches.enter_context(patch.object(pwd,'getpwnam',return_value=types.SimpleNamespace(pw_uid=999,pw_shell='/usr/sbin/nologin')))
        self.patches.enter_context(patch.object(grp,'getgrnam',return_value=types.SimpleNamespace(gr_gid=999)))

    def test_uninstall_saves_credentials_and_retains_unrelated_rule(self):
        tag=self.meta['ufw_tag'];owned=['ufw','allow',str(self.node['port'])+'/tcp','comment',tag]
        unrelated=['ufw','allow','22/tcp','comment','SSH']
        self.rules=[owned,unrelated];self.meta['ufw_ports']=[self.node['port']];m.write_json(m.RECEIPT,self.meta)
        m.uninstall(self.args())
        self.assertFalse(m.ROOT.exists());self.assertFalse(m.UNIT.exists())
        self.assertEqual(json.loads(m.SAVED.read_text()),self.state)
        self.assertEqual(m.SAVED.stat().st_mode & 0o777,0o600)
        self.assertTrue(m.MANAGER.exists());self.assertEqual(self.rules,[unrelated])
        self.assertEqual(self.unrelated.read_text(),'keep')

    def test_uninstall_then_reinstall_preserves_exact_link(self):
        original=m.make_link(self.node,self.state['server_ip'])
        m.uninstall(self.args());self.mock_install_environment()
        with patch.object(m,'health'),contextlib.redirect_stdout(io.StringIO()) as out:
            m.install(self.args('install'))
        self.assertEqual(out.getvalue().strip(),original)
        self.assertEqual(m.load_state()['version'],self.state['version'])
        self.assertFalse(m.SAVED.exists());self.assertTrue(m.UNIT.exists())

    def test_failed_activation_restores_previous_release(self):
        self.mock_install_environment();before=m.UNIT.read_text()
        with patch.object(m,'health',side_effect=m.Failure('health failed')):
            with self.assertRaises(m.Failure):m.install(self.args('update'))
        self.assertEqual(m.CURRENT.resolve(),self.release)
        self.assertEqual(m.UNIT.read_text(),before);self.assertTrue(self.running)

    def test_purge_removes_managed_data_only(self):
        m.uninstall(self.args(purge=True))
        self.assertFalse(m.ROOT.exists());self.assertFalse(m.SAVED.exists())
        self.assertFalse(m.RECEIPT.exists());self.assertFalse(m.MANAGER.exists())
        self.assertTrue(self.unrelated.exists())

    def test_stop_failure_preserves_runtime(self):
        self.fail_stop=True
        with self.assertRaises(m.Failure):m.uninstall(self.args())
        self.assertTrue(m.CURRENT.exists());self.assertTrue(m.UNIT.exists())

    def test_firewall_delete_failure_preserves_runtime_and_receipt(self):
        self.meta['ufw_ports']=[self.node['port']];m.write_json(m.RECEIPT,self.meta)
        self.rules=[['ufw','allow',str(self.node['port'])+'/tcp','comment',self.meta['ufw_tag']]];self.fail_ufw=True
        with self.assertRaises(m.Failure):m.uninstall(self.args())
        self.assertTrue(m.CURRENT.exists());self.assertTrue(m.RECEIPT.exists());self.assertTrue(m.SAVED.exists())

    def test_other_service_is_rejected_before_stop(self):
        m.UNIT.write_text('ExecStart=/usr/bin/something-else')
        with self.assertRaises(m.Failure):m.uninstall(self.args())
        self.assertFalse(any(c[:2]==['systemctl','stop'] for c in self.calls))
        self.assertTrue(m.ROOT.exists())

    def test_symlink_escape_is_rejected(self):
        m.CURRENT.unlink();m.CURRENT.symlink_to(self.base)
        with self.assertRaises(m.Failure):m.uninstall(self.args())
        self.assertTrue(self.unrelated.exists())

    def test_direct_link_output_and_single_profile(self):
        for ip in ('8.8.8.8','2606:4700:4700::1111'):
            self.state['server_ip']=ip;m.write_json(self.release/'state.json',self.state)
            with contextlib.redirect_stdout(io.StringIO()) as out:m.show_links('Google')
            lines=out.getvalue().splitlines();self.assertEqual(len(lines),1)
            url=m.urllib.parse.urlsplit(lines[0]);self.assertEqual(url.scheme,'vless');self.assertEqual(url.hostname,ip)
            self.assertEqual(m.urllib.parse.parse_qs(url.query)['pbk'],[self.node['public_key']])

    def test_existing_ufw_rule_is_not_relabelled(self):
        old=['ufw','allow',str(self.node['port'])+'/tcp','comment','user-owned'];self.rules=[old.copy()]
        m.add_firewall_rules([self.node])
        self.assertEqual(self.rules,[old]);self.assertEqual(m.receipt_data()['ufw_ports'],[])

    def mock_edit_environment(self):
        for name in ('probe_target','probe_reality','config_test','wait_port','test_tunnel'):
            self.patches.enter_context(patch.object(m,name))
        self.patches.enter_context(patch.object(m.os,'chown'))
        self.patches.enter_context(patch.object(m,'download_binary',side_effect=AssertionError('Edits must not download Xray')))

    def edit(self,*options):
        with contextlib.redirect_stdout(io.StringIO()) as output:
            m.edit_profile(m.parse_cli(list(options)))
        return output.getvalue()

    def test_edit_one_profile_preserves_other_profile_and_credentials(self):
        other={**self.node,'label':'ChatGPT','domain':'chatgpt.com','port':2026,
               'uuid':'498b877d-2168-435e-9d91-3dcd9044d529'}
        self.state['nodes'].append(other);m.write_json(self.release/'state.json',self.state)
        self.mock_edit_environment();port=m.free_port()
        output=self.edit('edit','--profile','1','--port',str(port),'--domain','www.google.com')
        state=m.load_state();new=state['nodes'][0]
        self.assertEqual(state['nodes'][1],other)
        for key in ('uuid','private_key','public_key','short_id'):self.assertEqual(new[key],self.node[key])
        self.assertEqual(new['port'],port);self.assertEqual(new['domain'],'www.google.com')
        self.assertEqual(state['version'],self.state['version'])
        self.assertEqual(m.CURRENT.joinpath('xray').stat().st_ino,self.release.joinpath('xray').stat().st_ino)
        self.assertEqual(m.PREVIOUS.resolve(),self.release)
        self.assertEqual(output.strip(),m.make_link(new,state['server_ip']))
        self.assertEqual(m.CURRENT.joinpath('state.json').stat().st_mode & 0o777,0o600)
        self.assertEqual(m.CURRENT.joinpath('config.json').stat().st_mode & 0o777,0o640)

    def test_invalid_and_reserved_ports_leave_installation_unchanged(self):
        self.mock_edit_environment()
        for port in ('0','65536','2026'):
            with self.assertRaises(m.Failure):self.edit('edit','--profile','Google','--port',port)
        self.assertEqual(m.CURRENT.resolve(),self.release)
        self.assertEqual(m.load_state(),self.state)
        m.probe_target.assert_not_called()

    def test_occupied_port_is_rejected_without_stopping_listener(self):
        self.mock_edit_environment()
        with m.socket.socket() as listener:
            listener.bind(('0.0.0.0',0));listener.listen();port=listener.getsockname()[1]
            with self.assertRaises(m.Failure):self.edit('edit','--profile','Google','--port',str(port))
            self.assertEqual(listener.getsockname()[1],port)
        self.assertEqual(m.load_state(),self.state)
        self.assertFalse(any(c[:2]==['systemctl','restart'] for c in self.calls))

    def test_failed_domain_probe_preserves_live_installation(self):
        self.mock_edit_environment();m.probe_target.side_effect=m.Failure('target rejected')
        with self.assertRaises(m.Failure):self.edit('edit','--profile','Google','--domain','www.example.com')
        self.assertEqual(m.load_state(),self.state);self.assertEqual(m.CURRENT.resolve(),self.release)
        self.assertEqual(list((m.ROOT/'releases').iterdir()),[self.release])
        self.assertFalse(any(c[:2]==['systemctl','restart'] for c in self.calls))

    def test_failed_live_check_restores_previous_settings(self):
        self.mock_edit_environment();m.test_tunnel.side_effect=m.Failure('live tunnel rejected')
        with self.assertRaises(m.Failure):self.edit('edit','--profile','Google','--port',str(m.free_port()))
        self.assertEqual(m.CURRENT.resolve(),self.release);self.assertTrue(self.running)
        self.assertEqual(m.load_state(),self.state)
        self.assertEqual(list((m.ROOT/'releases').iterdir()),[self.release])
        self.assertEqual(sum(c[:2]==['systemctl','restart'] for c in self.calls),2)

    def test_disable_last_profile_and_enable_reuse_credentials(self):
        self.mock_edit_environment();original=m.make_link(self.node,self.state['server_ip'])
        self.assertEqual(self.edit('disable','--profile','Google'),'')
        self.assertEqual(json.loads((m.CURRENT/'config.json').read_text())['inbounds'],[])
        with contextlib.redirect_stdout(io.StringIO()) as output:m.show_links()
        self.assertEqual(output.getvalue(),'')
        with self.assertRaises(m.Failure):m.show_links('Google')
        self.assertFalse(m.load_state()['nodes'][0]['enabled'])
        self.assertEqual(self.edit('enable','--profile','Google').strip(),original)
        self.assertTrue(m.load_state()['nodes'][0]['enabled'])

    def test_rename_does_not_restart_or_probe_network(self):
        self.mock_edit_environment()
        output=self.edit('edit','--profile','Google','--name','Personal Google')
        self.assertIn('#REALITY-Personal%20Google-',output)
        self.assertFalse(any(c[:2]==['systemctl','restart'] for c in self.calls))
        m.probe_target.assert_not_called();m.test_tunnel.assert_not_called()
        self.assertEqual(m.load_state()['nodes'][0]['uuid'],self.node['uuid'])

    def test_edit_stopped_service_leaves_it_stopped(self):
        self.mock_edit_environment();self.running=False
        self.edit('edit','--profile','Google','--port',str(m.free_port()))
        self.assertFalse(self.running)
        self.assertFalse(any(c[:2] in (['systemctl','restart'],['systemctl','start']) for c in self.calls))
        m.test_tunnel.assert_not_called();m.probe_reality.assert_called_once()

    def test_pending_profile_only_created_after_successful_probe(self):
        self.mock_edit_environment()
        creds={k:self.node[k] for k in ('uuid','private_key','public_key','short_id')}
        with patch.object(m,'new_credentials',return_value=creds):
            m.probe_target.side_effect=m.Failure('target rejected')
            with self.assertRaises(m.Failure):self.edit('edit','--profile','3','--domain','www.example.com')
            self.assertEqual(m.load_state(),self.state)
            m.probe_target.side_effect=None
            self.edit('edit','--profile','3','--domain','www.example.com')
        state=m.load_state()
        self.assertEqual(len(state['nodes']),2);self.assertEqual(state['nodes'][0],self.node)
        self.assertEqual(state['nodes'][1]['label'],'GSMArena')
        self.assertEqual(state['nodes'][1]['domain'],'www.example.com')

    def test_rollback_restores_the_old_direct_link(self):
        self.mock_edit_environment();original=m.make_link(self.node,self.state['server_ip'])
        self.edit('edit','--profile','Google','--port',str(m.free_port()))
        with patch.object(m,'health'),contextlib.redirect_stdout(io.StringIO()) as output:m.rollback()
        self.assertEqual(m.CURRENT.resolve(),self.release)
        self.assertEqual(output.getvalue().strip(),original)

    def test_manager_update_does_not_modify_core_config_or_service(self):
        import builtins
        m.MANAGER.write_text('#!/usr/bin/env bash\n# REALITY One Click 1.1\nexit 0\n')
        original_open=builtins.open
        def local_lock(path,*args,**kwargs):
            if path=='/run/lock/reality-oneclick.lock':path=self.base/'lock'
            return original_open(path,*args,**kwargs)
        before={p.name:p.read_bytes() for p in self.release.iterdir()}
        with patch.object(m,'open',side_effect=local_lock,create=True):m.dispatch(m.parse_cli(['manager-update']))
        self.assertEqual(before,{p.name:p.read_bytes() for p in self.release.iterdir()})
        self.assertEqual(m.CURRENT.resolve(),self.release)
        self.assertEqual(m.MANAGER.read_text(),SCRIPT.read_text())
        self.assertEqual(self.calls,[])

    def test_menu_recovers_from_invalid_port_and_applies_the_next_edit(self):
        self.mock_edit_environment();port=m.free_port()
        answers=iter(['2','1','invalid','2','1',str(port),'','0'])
        # Keep dispatch's filesystem lock in the test workspace by dispatching the already-parsed edit.
        with patch.object(m,'ask',side_effect=lambda prompt:next(answers)), \
             patch.object(m,'dispatch',side_effect=m.edit_profile), \
             contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()) as log:
            m.interactive_menu()
        self.assertEqual(m.load_state()['nodes'][0]['port'],port)
        self.assertIn('Invalid input; no change was made.',log.getvalue())
        self.assertIn('Change port',log.getvalue())

if __name__=='__main__':unittest.main()
