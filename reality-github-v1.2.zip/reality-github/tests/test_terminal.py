"""Exercise the real controlling-terminal prompt while standard input is exhausted."""
import os, pathlib, pty, select, signal, time, types, unittest

SCRIPT=pathlib.Path(__file__).resolve().parents[1]/'reality-oneclick.sh'
source=SCRIPT.read_text().split("<<'PYTHON'\n",1)[1].rsplit('\nPYTHON',1)[0]
m=types.ModuleType('terminal_installer');exec(compile(source,str(SCRIPT),'exec'),m.__dict__)

class TerminalTests(unittest.TestCase):
    def test_menu_uses_controlling_terminal_with_closed_stdin(self):
        pid,fd=pty.fork()
        if pid==0:
            try:
                with open('/dev/null') as empty:os.dup2(empty.fileno(),0)
                m.list_profiles=lambda stream:None
                m.interactive_menu()
                os.write(2,b'MENU_EXIT_OK\n');os._exit(0)
            except BaseException:os._exit(1)
        output=b'';sent=False;finished=False;deadline=time.monotonic()+5
        try:
            while time.monotonic()<deadline:
                ready,_,_=select.select([fd],[],[],.2)
                if ready:
                    try:chunk=os.read(fd,4096)
                    except OSError:break
                    if not chunk:break
                    output+=chunk
                    if b'Select action: ' in output and not sent:
                        os.write(fd,b'0\n');sent=True
                    if b'MENU_EXIT_OK' in output:break
            self.assertIn(b'Change port',output)
            self.assertIn(b'MENU_EXIT_OK',output,output.decode(errors='replace'))
            waited,status=os.waitpid(pid,0);finished=True
            self.assertEqual(os.waitstatus_to_exitcode(status),0)
        finally:
            os.close(fd)
            if not finished:
                try:os.kill(pid,signal.SIGKILL)
                except ProcessLookupError:pass
                os.waitpid(pid,0)

if __name__=='__main__':unittest.main()
