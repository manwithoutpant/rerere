# Hysteria 2 — manager 1.4

Hysteria 2 is an optional second service alongside VLESS/REALITY/Vision. It uses
QUIC over UDP and transports both TCP and UDP payloads. Install it with the
English **10) Hysteria 2** menu or `sudo reality-manager hy2`. One Hysteria profile
is managed per server. The existing REALITY profiles keep their own service,
credentials and TCP ports.

## Certificate choices

| Method | Endpoint | Public inbound ports | Server identity verification |
| --- | --- | --- | --- |
| `http` | Your DNS-only domain | Selected UDP port and TCP/80 | Publicly trusted Let's Encrypt certificate |
| `cloudflare` | Your DNS-only domain | Selected UDP port | Publicly trusted Let's Encrypt certificate; Cloudflare DNS challenge |
| `self-signed` | Your server's public IP | Selected UDP port | Fixed SHA-256 certificate fingerprint in the link |

Prefer a domain and a publicly trusted certificate for consistent import across
Windows, Android and iOS clients. Enable Hysteria **2**, not legacy Hysteria 1.
Client support for `pinSHA256` differs by app/core/version; never assume a parser
has enforced the fingerprint merely because it accepted a link. If it drops the
pin or lacks that setting, use an ACME domain instead.

Cloudflare is used for DNS management/validation, not to carry the tunnel.
Ordinary orange-cloud proxying is incompatible with this direct UDP setup.
Cloudflare Universal SSL secures its edge; a Cloudflare Origin CA certificate is
not a substitute for a publicly trusted certificate on a direct client connection.

Google/ChatGPT domains or IPs cannot substitute for your server. The endpoint must
reach the Hysteria service that you control. Changing SNI does not make this REALITY
or move your traffic to Google. REALITY's certificate-free server setup and
Hysteria's TLS certificate setup are different authentication designs; neither
is universally more secure or more reliable across all networks.

## Domain without an API token

In your DNS dashboard create one record:

| Field | Example |
| --- | --- |
| Type | A for IPv4; AAAA for IPv6 |
| Name | `vpn` |
| Address | Your VPS public inbound IP |
| Proxy | **DNS only** / gray cloud |

The manager intentionally requires the hostname to resolve only to the selected
server IP. Remove stale AAAA records or other A records for this hostname. It does
not edit A/AAAA records or account settings. DNS changes may need time to propagate.

Allow TCP/80 and the chosen UDP port in your provider firewall and NAT. TCP/80
must be free; the manager does not stop a website to take its port. Then:

```bash
sudo reality-manager hy2-install --hy2-mode http --hy2-domain vpn.example.com --hy2-email you@example.com --hy2-port 443
```

Hysteria obtains and renews the Let's Encrypt certificate automatically while the
service runs. Keep TCP/80 allowed for future HTTP challenges. Do not toggle
Cloudflare SSL settings or issue an Origin CA certificate for this method.
If TCP/80 is already used by a website, use the Cloudflare DNS method.

## Domain with Cloudflare DNS validation

Keep the same DNS-only A/AAAA record pointing to the VPS. Create an **API token**
in Cloudflare with Zone / DNS / Edit and Zone / Zone / Read permissions; start with
only the relevant zone. Do not supply an account password or Global API Key.
The bundled provider must be able to find the zone and manage its challenge TXT
records. If a restricted token cannot discover the zone, inspect the provider's
permission requirements; use HTTP validation if you do not want broader access.
Do not automatically widen token permissions.

```bash
sudo reality-manager hy2-install --hy2-mode cloudflare --hy2-domain vpn.example.com --hy2-email you@example.com --hy2-port 443
```

The token is requested through a hidden prompt on the VPS. Do not paste it into
chat, GitHub, a connection link or the command line. The noninteractive alternative
is `--hy2-token-file /root/cf-token`; it must be a regular root-owned file with
permissions 600 or 400. To create such a file without putting the token in shell
history, run an editor on that server after `sudo install -m 600 /dev/null /root/cf-token`.
Delete the input file afterward if you no longer need it; the protected runtime
configuration retains the token for certificate renewal.

No TCP challenge port is needed for DNS validation. The token is in root-only
state and a root/service-group-readable configuration, never in exported links.
The unprivileged Hysteria service necessarily reads it for automatic renewal.
Uninstall without purge preserves it for reinstall; purge removes the managed
copies and cache. A previous rollback release can retain a previous token.

To replace a token later:

```bash
sudo reality-manager hy2-edit --hy2-token-file /root/new-cf-token
```

## Own IP without a domain

```bash
sudo reality-manager hy2-install --hy2-mode self-signed --hy2-port 443
```

The manager generates an ECDSA P-256 certificate and a random password. The
exported link includes `insecure=1` **and** `pinSHA256`. The normal CA/hostname check
is replaced by an exact certificate fingerprint check. This is authenticated only
when the client enforces that pin. Get the original link through a trusted channel.
The certificate and fingerprint survive updates, port changes and uninstall/reinstall.
Purging or switching certificate modes can change them; import the new link.

For an explicit compatibility experiment, this command exports a separate link
without server identity verification:

```bash
sudo reality-manager hy2-links --hy2-insecure
```

It does not change the server or the saved default link. Bare insecure TLS permits
server impersonation and some current client cores reject it. Prefer ACME or a
verified pin. No third-party domain/IP is required for the self-signed mode.

## Management

```bash
sudo reality-manager hy2-status
sudo reality-manager hy2-links
sudo reality-manager hy2-check
sudo reality-manager hy2-edit --hy2-port 8443
sudo reality-manager hy2-edit --hy2-mode cloudflare --hy2-domain vpn2.example.com --hy2-email you@example.com
sudo reality-manager hy2-edit --hy2-obfs salamander
sudo reality-manager hy2-edit --hy2-obfs none
sudo reality-manager hy2-start
sudo reality-manager hy2-stop
sudo reality-manager hy2-restart
sudo reality-manager hy2-logs
sudo reality-manager hy2-update
sudo reality-manager hy2-update --hy2-version v2.12.3
sudo reality-manager hy2-rollback
sudo reality-manager hy2-uninstall
sudo reality-manager hy2-uninstall --purge
```

Replace sample domains/emails with your own. If public IP autodetection is wrong,
use `--server-ip YOUR_PUBLIC_IP` with `hy2-install` or `hy2-edit`.
Reimport the direct `hysteria2://` link after endpoint, certificate or obfuscation
changes. No subscription URL is created. Salamander requires matching settings on
every client; the link contains the generated obfuscation password. It cannot
restore connectivity on a network that blocks all UDP.

Updates accept official stable release assets with a matching GitHub SHA-256
digest. There is no automatic core updater. Editing does not download a core.
Installation tests a temporary QUIC server before activation; active changes test
the deployed service and automatically restore the previous release on failure.
Stopped services remain stopped after edit/update, so live ACME issuance and
certificate checks occur on their next start. Each operation keeps at most the
current and immediately previous runtime release.

Uninstall affects only Hysteria. `--purge` also removes its saved credentials,
managed certificate/token copies, ACME cache and service account. Both removal
modes request `DELETE`; add `--yes` for intentional noninteractive removal.
REALITY, SSH protection, confirmed base firewall policy and unrelated rules remain.

## Firewall and resource use

The default Hysteria port is **443/UDP**. It can coexist with **443/TCP** for a
website or REALITY. Existing active UFW rules are preserved; only missing managed
rules are added, unless `--no-ufw` is specified. Old owned ports remain available
for rollback and are removed at Hysteria uninstall. Existing administrator rules
are never claimed or removed; source/family coverage still needs review.

For a new host, `hy2-install ... --secure` uses the same guarded UFW activation
and SSH protection workflow as REALITY. Alternatively, after installation use
the main menu's Security / network section. UFW recognizes installed Hysteria
UDP and HTTP-challenge ports. Confirm new firewall activation from a new SSH
connection within three minutes. Provider firewall/NAT is outside this manager.

Only the Hysteria core is a new persistent process; certificate renewal is built
in. There is no panel, database, Certbot daemon, kernel patch or port-hopping rule
set. Memory use grows with traffic and concurrent clients; it is not a fixed
small allocation. QUIC receive windows and path MTU discovery keep upstream
defaults. `ignoreClientBandwidth=true` uses the core's normal congestion control
instead of client-supplied Brutal bandwidth hints. No inflated speed value is set.
TCP BBR/sysctl tuning applies to TCP, not Hysteria's QUIC congestion controller.

The service runs as `hysteriasvc`, with a read-only runtime, writable ACME cache,
systemd restrictions and only the bind-low-port capability. A strong password
authenticates clients. The ACL denies private/link-local/loopback/metadata
destinations for both TCP and UDP payloads; it does not replace provider DDoS
protection. Fail2ban protects SSH, not Hysteria clients behind shared carrier NAT.

Paths:

- Runtime/configuration: `/opt/hysteria-oneclick/current/`
- Saved uninstall state: `/var/lib/reality-oneclick/hysteria-saved.json`
- ACME cache: `/var/lib/hysteria-oneclick/`
- Service: `hysteria-oneclick.service`

Never publish these paths, API tokens, passwords, private keys or generated links.

## Validation and limits

Version 1.4 was tested with the official Hysteria **2.12.3** Linux amd64 binary and
Xray **26.3.27**. Local integration verifies HTTPS/TCP and UDP payloads with both
normal QUIC and Salamander, certificate fingerprint/CA verification, rejection of
bad passwords/pins/untrusted certificates, and denial of private destinations.
Unit tests simulate service/firewall operations, rollback and file ownership.
REALITY/Vision integration continues to pass. ARM64 download selection is
implemented but the ARM64 binary was not executed in this amd64 environment.

A live ACME issuance/renewal, a real Ubuntu systemd deployment, public inbound
reachability, mobile/desktop client import and Iranian ISP connectivity were not
tested here. They require your VPS, DNS, provider settings and (for DNS validation)
your token. The installer performs real DNS, authentication, certificate and
HTTPS egress checks on the VPS. A success message is still a server-local check.

## Official references

- [Hysteria server configuration](https://v2.hysteria.network/docs/advanced/Full-Server-Config/)
- [Cloudflare DNS challenge configuration](https://v2.hysteria.network/docs/advanced/ACME-DNS-Config/)
- [Hysteria client TLS and QUIC settings](https://v2.hysteria.network/docs/advanced/Full-Client-Config/)
- [Connection URI specification](https://v2.hysteria.network/docs/developers/URI-Scheme/)
- [ACL matching](https://v2.hysteria.network/docs/advanced/ACL/)
- [CDN limitations](https://v2.hysteria.network/docs/misc/CDN/)
- [Cloudflare DNS provider token permissions](https://github.com/libdns/cloudflare)
- [Cloudflare Origin CA scope](https://developers.cloudflare.com/ssl/origin-configuration/origin-ca/)
- [Official Hysteria releases](https://github.com/HyNetworks/hysteria/releases)
