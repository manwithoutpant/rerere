# Security and network management — 1.4

This is a lightweight host setup for Ubuntu 22.04+ and VLESS/TCP/REALITY/Vision.
The English manager runs only on demand. Optional Fail2ban provides SSH protection.
Optional Hysteria 2 adds its own independent persistent protocol service. UFW rules and sysctl settings are handled by Ubuntu/Linux;
there is no web panel, monitoring agent or custom database.

## Fresh server: one-click with a guarded firewall

Run the downloaded script with `install --secure`. Add `--no-ufw` if UFW must remain unmanaged (SSH protection and TCP tuning still apply). It installs/tests Xray,
applies conservative TCP settings, then prepares UFW. On a clean inactive UFW
firewall it:

1. Identifies SSH ports from `sshd -T`, active listeners, `ssh.socket` and the
   current SSH connection. The SSH port is not assumed to be 22.
2. Refuses automatic takeover when Docker, native nftables/firewalld, other
   firewall rules or undeclared public listeners are present.
3. Saves the UFW configuration and starts a systemd rollback timer before
   changing any policy. The timer is enabled on boot while confirmation is pending.
4. Allows detected SSH ports, enabled REALITY **TCP** ports and installed
   Hysteria **UDP** / HTTP certificate-challenge ports for IPv4/IPv6,
   denies other incoming traffic and allows outgoing traffic. Existing standard
   UFW connection tracking, DHCP and ICMP/ICMPv6 handling is retained.
5. Prints a confirmation command containing a random token. Open a **new SSH
   TCP connection** and run that command within three minutes. A multiplexed
   shell reusing the same SSH TCP connection does not qualify; use a separate
   client connection (OpenSSH: `-o ControlMaster=no -o ControlPath=none`).
6. After confirmation, installs the managed SSH protection jail. On a timeout
   it restores the original UFW files and inactive state. TCP tuning and the
   installed Xray remain available; rerun `install --secure` to retry.

Keep the first SSH session open during setup and do not edit UFW through other
tools until confirmation or rollback completes. The pending rollback can also
be run immediately from the original session or provider console:

```bash
sudo reality-manager firewall-rollback
```

If reconnecting through SSH is not applicable, the provider console can confirm
the printed token using `firewall-confirm --token TOKEN --console`. `--console`
is an explicit assertion that you have working console access.

A preexisting active UFW firewall keeps its policies and SSH rules; the manager
only performs the existing profile rule synchronization. It does not claim to
secure every service behind that firewall. Source-limited existing profile
rules are preserved and should be checked for client coverage.

For additional services that must remain publicly accessible:

```bash
sudo bash reality-oneclick.sh install --secure --allow-ports 80/tcp,443/tcp
# Or, after installation:
sudo reality-manager firewall-setup --allow-ports 80/tcp,443/tcp
```

Only list ports for intended public services. Undeclared non-loopback listeners
cause first activation to stop. `--allow-ports` applies to the initial inactive
UFW setup; manage unrelated services on an already active firewall with UFW.
This manager never resets an existing firewall. UFW protection of container
published ports is outside its scope.

## SSH brute-force protection

The managed Fail2ban jail is `reality-sshd`, stored in
`/etc/fail2ban/jail.d/90-reality-oneclick.local`.

- Journal backend: works without `/var/log/auth.log`.
- Five failed logins within ten minutes result in a 30-minute ban.
- The ban action is limited to the detected **SSH TCP ports**. It does not
  limit REALITY connection counts or ban a carrier NAT IP from VPN ports.
- Loopback and the current administration IP, when available from
  `SSH_CONNECTION`, are allowlisted. A shared source IP therefore shares that
  exception; it is shown after setup and in the configuration file.
- SSH passwords, keys, root-login policy and port configuration are preserved.
  Switching to key-only SSH requires a separately verified working key login.
- On a new Fail2ban installation the stock Ubuntu `sshd` jail is replaced by
  this managed journal-backed jail, avoiding duplicate protection.
- An existing active `sshd` jail is retained. Its port coverage still needs
  review. Other existing jails and files are not overwritten.
- Native nftables/firewalld services are not combined with this iptables-based
  preset; use their existing firewall integration instead.

```bash
sudo reality-manager ssh-protect
sudo fail2ban-client status reality-sshd
sudo fail2ban-client set reality-sshd unbanip YOUR_IP
sudo reality-manager ssh-unprotect
```

If the SSH listening port changes later, rerun `ssh-protect` and review the UFW
and provider rules. On a clean server, set up/confirm UFW **before** enabling
Fail2ban; otherwise its rules may correctly prevent automatic firewall takeover.
`install --secure` orders these operations for you.

## Conservative TCP settings

```bash
sudo reality-manager network-tune
sudo reality-manager network-tune --bbr
sudo reality-manager network-restore
```

The standard preset enables SYN cookies as an overflow fallback and sets
`net.ipv4.tcp_mtu_probing=1`, which activates packetization-layer MTU probing
when a black hole is detected. Values already set to 2 are preserved. It does
not resize global socket buffers, change the interface MTU, enable forwarding,
disable IPv6, alter routes/DNS or add aggressive TCP timeouts. These controls
are host-wide, not confined to Xray.

BBR is a separate opt-in. The manager checks kernel availability, can load the
existing `tcp_bbr` module, then selects BBR and sets `fq` as the default qdisc
for newly created queueing disciplines. It does not replace the current
interface qdisc or install a kernel. Existing TCP connections may retain their
previous congestion control. BBR is not a promise of higher throughput on a
particular Iranian ISP route; compare client performance before and after.

Previous values are saved before changes. Failures trigger restoration;
`network-restore` removes the managed persistence file and restores values
that still match what the manager applied. Externally changed values are
retained. Conflicting administrator sysctl files stop automatic tuning.

## TCP, UDP and REALITY

The REALITY listeners in this package are **TCP**. UDP payloads can travel
inside VLESS through that TCP transport when supported/configured by the
client; no matching public UDP listener is added by opening a firewall port.
The server's outgoing traffic and established return traffic remain allowed.

The exported standard `xtls-rprx-vision` client flow intercepts UDP/443 to favor
TCP HTTPS. Project X also documents the client-side
`xtls-rprx-vision-udp443` flow for applications that require QUIC; this package
keeps its existing links and flow for compatibility. Hysteria2 is a different
transport with its own UDP listener and setup. Version 1.4 adds it as an optional
installation through the Hysteria 2 menu. Its UDP rule and optional TCP/80
certificate-challenge rule are tracked separately. See [Hysteria 2](hysteria2.md).
TCP sysctl/BBR settings do not change QUIC congestion control; upstream QUIC
window/MTU defaults are retained.

## Audit and removal

```bash
sudo reality-manager security
sudo reality-manager security-check
sudo reality-manager security-remove
```

The report shows listeners, TCP settings, SSH base policy, UFW, Fail2ban, time
synchronization and unattended-upgrades service status. It does not enable
automatic OS updates or reboot the server. Base SSH policy can be overridden
by Match blocks, and the update-service status is not proof that every pending
security update is installed.

`security-remove` rolls back a pending firewall, removes the managed Fail2ban
jail and restores TCP settings. A **confirmed UFW firewall and its SSH/extra
service allow rules remain** to preserve host access/protection. They can be
managed directly with UFW. Packages are retained. External edits to managed
configuration files stop automatic removal rather than being erased.

Normal Xray uninstall keeps host protection. Purging Xray credentials also
keeps the manager and its receipt when security settings still exist. To remove
all managed runtime/state, purge Hysteria separately if installed, then run
`security-remove`, followed by
`uninstall --purge`. UFW's confirmed SSH/extra rules and shared packages remain.

## Limits and validation

The rollback protects against common firewall mistakes; it cannot guarantee
access after unrelated server, provider or network failures. Provider firewall
rules and NAT forwarding must be configured in the hosting panel separately.
This is not volumetric DDoS protection and cannot stop an attack that saturates
the upstream connection. Domain choice does not guarantee bypassing every ISP
or destination service restriction.

Version 1.3 verification includes isolated lifecycle/fault-injection tests,
controlling-terminal tests, generated systemd unit/timer syntax validation,
Fail2ban configuration parsing using upstream 1.1.0 and Ubuntu-packaged 1.0.2,
and an authenticated local REALITY/Vision tunnel using official Xray 26.3.27.
Firewall and service changes were simulated; they were not applied to your VPS.
An external SSH/VPN test is still required on the destination server.

## Official references reviewed

- [Ubuntu UFW manual](https://manpages.ubuntu.com/manpages/resolute/man8/ufw.8.html)
- [Ubuntu OpenSSH setup](https://documentation.ubuntu.com/server/how-to/security/openssh-server/)
- [Ubuntu 24.04 SSH socket activation](https://documentation.ubuntu.com/release-notes/24.04/)
- [Ubuntu nftables interoperability](https://documentation.ubuntu.com/security/security-features/network/firewall/nftables/)
- [Fail2ban configuration](https://github.com/fail2ban/fail2ban/blob/master/config/jail.conf)
- [Linux TCP sysctl documentation](https://docs.kernel.org/networking/ip-sysctl.html)
- [Docker and UFW](https://docs.docker.com/engine/network/packet-filtering-firewalls/)
- [Project X VLESS and Vision flows](https://xtls.github.io/en/config/outbounds/vless.html)
- [REALITY reference implementation](https://github.com/XTLS/REALITY)
