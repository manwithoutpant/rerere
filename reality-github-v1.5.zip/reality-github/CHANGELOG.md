# Changes

## 1.5 — 2026-09-29

- Unified English setup: both protocols by default, or one; step-by-step validation, back/cancel, review before apply.
- Terminal prompts handle CR Enter and redirected stdin without text read-ahead; restore tty settings and hide tokens.
- One to four REALITY profiles, custom targets, automatic TLS/ALPN checks, free/random TCP and UDP port suggestions.
- Domain-only Hysteria HTTP certificate setup, optional contact email, Cloudflare DNS alternative and pinned-IP mode.
- New read-only doctor; classified remedies and private, redacted failure reports surviving first-install rollback.
- Existing credentials/core/service state preserved; successful protocols retained on partial failure.
- Guarded firewall confirmation still required before enabling new SSH protection where applicable.
- Regression coverage includes real PTYs, menu-to-wizard navigation, invalid inputs, DNS retries, partial failure and rollback.
- Live VPS/ACME and client/ISP verification remain deployment checks.

## 1.4 — 2026-09-29

- Added optional Hysteria 2 with an independent unprivileged service and English submenu.
- Added Let's Encrypt HTTP and Cloudflare DNS challenge modes, automatic renewal,
  and self-signed direct-IP mode with a SHA-256 certificate pin.
- Added hidden Cloudflare token entry / root-only token-file input; secrets never
  enter exported links. Bare insecure link export requires an explicit CLI flag.
- Added UDP port, domain and Salamander configuration, links, checks, update,
  rollback, removal and credential-preserving reinstall.
- Integrated owned UDP/ACME rules with guarded UFW setup and firewall rollback.
- Retained REALITY settings and independent protocol lifecycles; Xray purge keeps
  the manager when Hysteria still needs it.
- Validation: 81 isolated automated tests; real official Hysteria 2.12.3 TCP/UDP,
  authentication, TLS/pin and ACL integration; Xray 26.3.27 REALITY/Vision integration.
- Live ACME issuance/renewal and real VPS/client deployment remain target-environment
  checks; no Cloudflare account or server was accessed during development.

## 1.3 — 2026-09-29

- Added an English Security / network submenu and `install --secure`.
- Added guarded UFW first activation, nonstandard SSH/socket detection,
  undeclared-listener/firewall conflict checks, a three-minute confirmation
  token and boot-enabled rollback timer.
- Added journal-backed SSH-only Fail2ban protection. A new Ubuntu installation's
  stock SSH jail is handled without duplicate jails; existing active SSH jails
  are preserved. Current administration IP allowlisting is reported.
- Added reversible SYN-cookie/MTU-probing settings and optional kernel BBR.
- Added security/network reports and independent removal of security additions.
- Retained existing credentials, core version and profile management on a
  manager-only upgrade. Xray removal preserves host protection unless its
  separate removal action is used.
- Validation: 57 lifecycle/security/terminal tests, official Xray 26.3.27 local
  REALITY/Vision integration, generated Fail2ban configuration checks with
  upstream 1.1.0 and Ubuntu 1.0.2, and systemd rollback-unit syntax verification.

No live VPS firewall, SSH configuration or provider firewall was changed during
development. The installer performs server checks when run on the target VPS.
