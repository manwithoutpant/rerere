# REALITY + Hysteria One Click 1.7

Lightweight, English terminal setup for Ubuntu 22.04+ with systemd (x86_64 / ARM64).
Install **both protocols** by default, or choose just REALITY or Hysteria 2.
No panel, database, subscription server, scheduled updater, or Python packages.
The manager runs only when called. Hysteria multi-port mode uses a small Python supervisor and one unprivileged Hysteria process per domain (up to 10).

## Upload and run

Upload `reality-github-v1.7.zip` to the root of your GitHub repository, keeping its
name unchanged. Run the ZIP bootstrap supplied with the download; its SHA-256
must match this exact archive. Do not reuse a v1.4 checksum or put Markdown link
syntax inside a shell command. You do not need to upload anything manually to the VPS.

Alternatively, upload the included **reality-oneclick.sh** to the repository root
and use this verified standalone bootstrap (replace the URL only if you use a
different repository). This command updates the manager; launch guided setup separately afterward.
Existing protocol settings and running/stopped states are preserved by default.

```bash
sudo --preserve-env=SSH_CONNECTION bash <<'BASH'
set -Eeuo pipefail
if ! command -v curl >/dev/null; then
  apt-get update -qq
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq ca-certificates curl
fi
reality_tmp=$(mktemp -d)
trap 'rm -rf -- "$reality_tmp"' EXIT
curl -fL --proto '=https' --proto-redir '=https' --retry 3 --connect-timeout 15 --max-time 120 \
  'https://raw.githubusercontent.com/manwithoutpant/rerere/main/reality-oneclick.sh' \
  -o "$reality_tmp/reality-oneclick.sh"
printf '%s  %s\n' 'c8b9f25ca9a66f77b691b46e60fb26f18dd110591ec54fa6f3370b40b4426d61' "$reality_tmp/reality-oneclick.sh" | sha256sum -c -
bash "$reality_tmp/reality-oneclick.sh" manager-update
BASH
```

Then launch the menu **directly from the foreground SSH shell**, outside the
heredoc above:

```bash
sudo reality-manager setup
```

For SSH disconnect protection, install tmux once, then start the manager inside it:

```bash
sudo apt-get update -qq && sudo apt-get install -y tmux
sudo --preserve-env=SSH_CONNECTION tmux new-session -A -s reality16 '/usr/local/sbin/reality-manager setup'
```

Reconnect after an SSH disconnect using `sudo tmux attach -t reality16`.
Exit any old wizard with q before starting the updated manager. Updating the script
does not replace Python code already loaded by an older running process.

Stop an old stuck menu with Ctrl+C before running the new command. A controlling
SSH terminal is required (`ssh -t` if necessary). The embedded Python program
reads interactive answers from `/dev/tty`, not from the shell heredoc. Prompts reject background terminal access before it can suspend the process,
normalize Enter handling, preserve queued input, and restore the previous terminal
settings. Cloudflare tokens use a hidden prompt. Unattended use requires explicit
CLI commands; a no-argument invocation no longer silently installs a protocol.

## Guided flow

1. Choose **Both (default)**, REALITY only, or Hysteria only.
2. Confirm the detected public IP against your provider dashboard.
3. For a new REALITY installation, choose 1–4 profiles (default 1). For each,
   accept/change its suggested free TCP port and target hostname. DNS, verified
   TLS 1.3, ALPN h2 and redirects are checked before proceeding. The actual
   authenticated REALITY/Vision tunnel is checked during installation.
4. For a new Hysteria installation, choose a certificate method (default: own
   domain with automatic Let's Encrypt HTTP validation), enter your own domain or domain list,
   and accept/change a separate suggested UDP port for each domain (8443 onward). DNS must resolve only to this server's
   selected public IP. Stale A/AAAA records and proxy addresses are rejected.
5. Keep current host protection settings, or opt into guarded UFW, SSH Fail2ban
   protection, and conservative TCP settings. Protocol allow rules are added to
   active UFW in either case. Inactive UFW is enabled only when explicitly chosen.
6. Review the settings and apply. Downloads, checks and certificate startup show
   progress. Direct `vless://` and `hysteria2://` config links are printed.

**Enter** accepts a default; **b** returns one step; **q** cancels. These controls
apply throughout the configuration wizard. At port prompts, **r** chooses a random
available port. Invalid answers remain on the same step. A preliminary failure
makes no protocol changes. After Apply, a successfully installed protocol remains
available if another one fails; the result clearly says `NEEDS ATTENTION`.

TCP/443 and UDP/443 can coexist because they are different transports. Two REALITY
profiles cannot share one TCP port. TCP/80 cannot also be a REALITY listener when
Hysteria uses HTTP certificate validation. Random local port availability does not
mean the provider firewall or NAT allows that port.

Existing installations are preserved by `setup`, including custom endpoints and
stopped service state. Edit existing settings in the corresponding protocol menu.
Retrying setup installs missing protocols; it does not rotate existing passwords or
silently update cores. For a failed edit, retry the edit from its protocol menu.

## Own-domain certificate setup

Create a **DNS-only** record for each hostname in your DNS provider:

- IPv4 VPS: `A vpn.example.com -> YOUR_SERVER_IPV4`.
- IPv6 VPS: `AAAA vpn.example.com -> YOUR_SERVER_IPV6`.

Use the matching address family; remove conflicting/stale records for this hostname.
Cloudflare's orange proxy must be disabled. HTTP mode needs public TCP/80 free on
the VPS and allowed at the provider, plus the selected Hysteria UDP port. The service
obtains and renews the certificate itself; Cloudflare SSL dashboard settings or an
Origin CA certificate do not replace this process. Keep TCP/80 open for renewal.

If TCP/80 is occupied, choose Cloudflare DNS validation. Supply a scoped API token
with Zone:DNS:Edit and Zone:Zone:Read for the correct zone **only in the hidden VPS
prompt**. No Cloudflare account password is needed. A contact email is optional
for the Let's Encrypt mode; advanced CLI users can set `--hy2-email`. Applying a
domain setup authorizes issuance/renewal under the linked Let's Encrypt agreement.
The certificate mode using your own server IP needs no domain, but clients must
support the exported SHA-256 certificate pin. Bare insecure TLS is not the default.

See [Hysteria certificate/client details](docs/hysteria2.md).

## Bulk Hysteria domains

The Hysteria domain question accepts a single name or a comma/space-separated list:

```text
vpn1.example.com,vpn2.example.com,vpn3.example.com
```

For multiline input, type `list` first, then paste:

```text
vpn1.example.com
vpn2.example.com
vpn3.example.com
.
```

The final dot ends the list. b goes back; q cancels. Up to 10 unique hostnames
are supported. Uppercase, trailing dots, duplicate names and HTTP(S) URLs are
normalized; URL paths are ignored. Bare hostnames are the recommended format.
Wildcards, IP literals, embedded credentials and custom ports are rejected.

Each hostname is checked against the selected server IP. The wizard reports PASS
or REJECT per entry. If only some pass, explicitly accept the reduced list or
re-enter it; the default is to re-enter. DNS success is only a prerequisite:
automatic certificate issuance and authentication for **every SNI** are checked
when the service starts. A failed activation rolls back the configuration.

All accepted hostnames use the **same Hysteria service, UDP port and password**.
The ACME configuration includes all names; each direct link has its own endpoint
hostname and SNI. They are alternative names for one server, not independent users
or independent IP addresses. In pinned-IP mode, only the IP link is exported.
Certificates/renewal for public domains remain deployment-time checks.

For an already installed Hysteria service, choose main menu 3, then
**4) Certificate / domain**, and enter the replacement list. That list replaces
the previous domain list after successful activation; credentials are preserved.
`setup` alone intentionally preserves existing installations.

Explicit CLI examples (use install for new installations, edit for existing ones):

```bash
sudo reality-manager hy2-install --hy2-mode http --hy2-domain 'vpn1.example.com,vpn2.example.com' --hy2-port 443
sudo reality-manager hy2-edit --hy2-mode http --hy2-domain 'vpn1.example.com,vpn2.example.com'
sudo reality-manager hy2-links
```

CLI commands require every supplied domain to pass DNS and syntax checks; partial
acceptance is offered only in the interactive wizard. Old single-domain state is
read without a migration command.

## Management

```bash
sudo reality-manager             # guided setup if empty; otherwise management menu
sudo reality-manager setup       # install both / one, preserving existing protocols
sudo reality-manager doctor      # read-only diagnostics
sudo reality-manager links       # direct REALITY links
sudo reality-manager hy2-links   # direct Hysteria link
sudo reality-manager hy2         # Hysteria management / certificate changes
sudo reality-manager security    # firewall, SSH protection, conservative TCP options
```

Main menu: 1 Setup, 2 REALITY profiles/service, 3 Hysteria/certificates,
4 All direct links, 5 Troubleshoot, 6 Security/network, 0 Exit.
Changing a port, target or domain produces an updated config link; reimport it.
The REALITY submenu retains per-profile edits, enable/disable, status, start/stop,
logs, update, rollback, uninstall and purge. The Hysteria submenu retains equivalent
lifecycle controls, UDP port, certificate/domain and Salamander obfuscation.

For explicit CLI operation:

```bash
sudo reality-manager install --ports 443 --domains www.google.com
sudo reality-manager hy2-install --hy2-mode http --hy2-domain vpn.example.com --hy2-port 443
sudo reality-manager hy2-edit --hy2-port 8443
sudo reality-manager edit --profile 1 --domain www.bing.com
sudo reality-manager uninstall              # keep REALITY credentials
sudo reality-manager hy2-uninstall          # keep Hysteria credentials/certificates
sudo reality-manager uninstall --purge      # erase managed REALITY credentials
sudo reality-manager hy2-uninstall --purge  # erase managed Hysteria credentials/cache
```

No-argument legacy `install` explicitly installs REALITY with the four historical
profiles/ports (2025–2028). Guided setup defaults to one profile to keep questions
and resources minimal. Both protocol options mean these two supported protocols,
not every protocol supported by Xray. `--ports` accepts 1–4 distinct values;
`--domains`, when supplied, must have the same number of plain hostnames.
Use `bash reality-oneclick.sh --help` for the full command list.

## Troubleshooting and safety boundaries

`doctor` checks managed state, service status, Hysteria DNS, local authenticated
protocol tests when active, listening sockets, UFW/SSH protection and clock status.
It prints a historical, timestamped failure report when available. Reports are
root-only and redact known connection credentials and API tokens. First-install
certificate/startup failures retain this report even after automatic rollback.

Common failures identify the remedy: wrong/proxied/stale DNS, occupied port, failed
TLS/ALPN target, outbound HTTPS failure, authentication failure, certificate/ACME
trouble, missing API permission or checksum mismatch. Suggestions do not claim to
prove a specific root cause when several causes remain possible. The manager does
not change your DNS records, bypass checksums, stop unrelated websites, or reset an
unknown firewall. It does not replace external connectivity testing.

UFW's first activation uses a timed rollback. If asked, open a **new SSH session**
and execute the displayed confirmation command within three minutes. Otherwise it
rolls back. Keep the original session open. SSH protection requested by setup is
installed after confirmation. [Security and network details](docs/security-network.md).

## Validation and limits

The release includes automated terminal, guided-flow, lifecycle, credential,
firewall and rollback tests. Isolated integration tests use official Xray 26.3.27
and Hysteria 2.12.3 binaries for authenticated traffic, invalid-credential rejection,
TLS/CA/pin enforcement, UDP traffic and private-destination blocking. No host
firewall was changed during these tests.

Live public-domain ACME issuance/renewal, Ubuntu VPS deployment, client import and
Iranian ISP reachability still require testing on the target server/network.
A local test cannot certify the public inbound path. No speed or reachability
guarantee is made for a target hostname or transport.

```bash
python3 -m unittest discover -s tests -p 'test_*.py'
python3 tests/integration_reality.py /path/to/official/xray
python3 tests/integration_hysteria.py /path/to/official/hysteria
```

Sources: [Xray REALITY](https://github.com/XTLS/REALITY),
[Hysteria server configuration](https://v2.hysteria.network/docs/advanced/Full-Server-Config/),
[DNS challenge configuration](https://v2.hysteria.network/docs/advanced/ACME-DNS-Config/),
[CertMagic v0.25.4 account handling](https://github.com/caddyserver/certmagic/blob/v0.25.4/account.go).


## Network startup ordering (1.7)

Both managed units now use `After=network.target` and do not pull in
`network-online.target`. A failed wait-online helper in an LXC/VPS must not block
their listener startup. Network availability, protocol traffic and certificates
remain subject to the existing health checks; automatic restart remains enabled.
No host networking, SSH, or global wait-online unit is disabled or modified.
The observed wait-online failure supports this diagnosis, but full VPS service
journals are still needed if activation fails after this correction.

## Version 1.7: separate domain ports and tested target replacement

New Hysteria domain setups assign distinct UDP listeners. Use `--hy2-ports 8443,8444,8445` with three domains in that order; the wizard asks one port per domain with back/cancel support. Existing shared-port states are preserved until explicitly edited. Manager update alone never changes running protocol settings.

One primary Hysteria process owns ACME issuance/renewal for all domains. Secondary processes read each domain's certificate from the managed CertMagic cache on TLS handshakes. They do not bind TCP/80. A small supervisor stops the whole group if any listener exits; systemd restarts it. No Nginx, UDP redirection, NET_ADMIN or new Python dependencies are needed. Certificates and credentials stay in protected directories. Automatic issuance must still succeed on your VPS; ambiguous certificate cache paths fail closed.

For an existing four-domain installation, after manager update:

```bash
sudo reality-manager hy2-edit --hy2-ports 8443,8444,8445,8446
sudo reality-manager reconfigure
```

The first command preserves domains/passwords and changes their UDP ports in stored domain order. For a different domain count, provide exactly that many ports. Use `sudo reality-manager hy2-status` to see the order, or menu `hy2` > 4 to edit interactively. Open those UDP ports in your provider firewall; retain TCP/80 for HTTP ACME renewal. Reimport new direct links. Existing active UFW receives owned rules automatically. Old owned ports remain available for rollback.

REALITY new profiles and explicit `reconfigure` try the requested target first, followed by Google, ChatGPT, Bing, Microsoft, DeepSeek and Cloudflare candidates. Every accepted candidate must pass TLS/certificate/ALPN and authenticated REALITY HTTPS tests. No candidate is assumed suitable or unfiltered. If the pool is exhausted, the operation fails before activation; it does not export a broken link or silently drop that requested profile. Normal core updates preserve existing targets.

Verification: 128 isolated unit/terminal/lifecycle tests; real Hysteria authentication on three separate UDP listeners; wrong TLS identity rejection; replacement certificate loaded without listener restart; child failure terminates the group; clean stop releases all ports. Public ACME/network reachability is not covered by fixture certificates.

```bash
python3 tests/integration_multiport.py /path/to/official/hysteria
```
