#!/usr/bin/env bash
# REALITY One Click 1.7 — Ubuntu 22.04+; dedicated Xray service.
set -Eeuo pipefail
export LC_ALL=C
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/sbin:/usr/local/bin
if [[ ${1:-} == '--help' || ${1:-} == '-h' ]]; then
  cat <<'HELP'
REALITY One Click 1.7
Usage: sudo bash reality-oneclick.sh COMMAND [options]
Commands: setup, menu, doctor, list, links, edit, enable, disable, check, manager-update,
          install, reinstall, uninstall, status, start, stop, restart, logs,
          update, reconfigure, rollback, security, security-check, protect,
          firewall-setup, firewall-confirm, firewall-rollback,
          ssh-protect, ssh-unprotect, network-tune, network-restore, security-remove,
          hy2, hy2-install, hy2-edit, hy2-update, hy2-uninstall, hy2-rollback,
          hy2-links, hy2-status, hy2-check, hy2-start, hy2-stop, hy2-restart, hy2-logs
No arguments: guided setup on a new server; management menu when installed.
Use an explicit command for unattended operation.
Options:
  --server-ip PUBLIC_IP                 Public IPv4 or IPv6
  --ports 2025,2026,2027,2028           One to four distinct TCP ports
  --domains DNS1,DNS2,DNS3,DNS4        One to four matching target domains
  --version v26.3.27                    Pin an official stable Xray release
  --no-ufw                             Do not add UFW rules
  --profile Google                     Select a profile by list number, ID, or port
  --port 443                           Change one TCP port (edit)
  --domain www.google.com               Change one domain/SNI (edit)
  --name Personal                       Change a display name (edit)
  --purge                              Uninstall and erase saved credentials
  --yes                                Confirm uninstall in noninteractive use
  --secure                             Set up TCP, guarded UFW and SSH protection after install/hy2-install
  --allow-ports 80/tcp,443/tcp          Additional services to keep open during firewall-setup
  --token TOKEN                        Confirm firewall from a NEW SSH connection within 3 minutes
  --console                            Confirm firewall from the provider console
  --bbr                                Opt in to BBR (network-tune only)
Hysteria 2 options:
  --hy2-mode http|cloudflare|self-signed  Certificate method (default: pinned self-signed)
  --hy2-domain vpn.example.com          DNS-only domain or comma-separated list (up to 10)
  --hy2-email you@example.com           Optional Let's Encrypt contact email
  --hy2-ports 8443,8444,8445             One distinct UDP port per domain, in list order
  --hy2-port 443                        UDP listener port; independent of REALITY TCP
  --hy2-obfs none|salamander             Optional matching client/server obfuscation
  --hy2-token-file /root/cf-token       Root-only Cloudflare token file; otherwise hidden prompt
  --hy2-version v2.12.3                 Pin an official stable Hysteria 2 release
  --hy2-insecure                       hy2-links only: explicitly export an unverified TLS link
No web panel. Both protocols export direct config links; no subscription server.
Progress goes to stderr; link commands print only connection URIs to stdout.
HELP
  exit 0
fi
[[ $EUID -eq 0 ]] || { echo 'Run with sudo bash reality-oneclick.sh' >&2; exit 1; }
[[ -d /run/systemd/system ]] || { echo 'A Ubuntu host running systemd is required.' >&2; exit 1; }
. /etc/os-release
[[ ${ID:-} == ubuntu && ${VERSION_ID%%.*} -ge 22 ]] || { echo 'Requires Ubuntu 22.04 or newer.' >&2; exit 1; }
if [[ $# -eq 0 ]]; then
  set -- menu
fi
reality_missing=0
reality_dependencies='curl python3 openssl ip ss'
if [[ ${1:-} == firewall-rollback ]]; then reality_dependencies='python3'; fi
for reality_dependency in $reality_dependencies; do
  command -v "$reality_dependency" >/dev/null 2>&1 || reality_missing=1
done
if [[ $reality_missing -eq 1 ]]; then
  if [[ ${1:-} == firewall-rollback || ${1:-} == security-check ]]; then
    echo 'Required local tools are missing; this recovery/audit command will not install packages.' >&2
    exit 1
  fi
  apt-get update -qq >&2
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq --no-install-recommends ca-certificates curl python3 openssl iproute2 util-linux >&2
fi
export REALITY_INSTALLER_SOURCE
REALITY_INSTALLER_SOURCE=$(readlink -f -- "$0")
exec python3 - "$@" <<'PYTHON'
import argparse, base64, contextlib, copy, fcntl, hashlib, ipaddress, json, os
import pathlib, platform, re, secrets, shlex, shutil, socket, subprocess, sys
import tempfile, time, urllib.parse, uuid, zipfile

ROOT = pathlib.Path('/opt/reality-oneclick')
CURRENT = ROOT / 'current'
PREVIOUS = ROOT / 'previous'
UNIT = pathlib.Path('/etc/systemd/system/reality-oneclick.service')
SERVICE = 'reality-oneclick.service'
USER = 'realitysvc'
MANAGER = pathlib.Path('/usr/local/sbin/reality-manager')
DATA = pathlib.Path('/var/lib/reality-oneclick')
RECEIPT = DATA / 'ownership.json'
SAVED = DATA / 'saved-state.json'
OWNER = 'reality-oneclick-v1'
MARKER = ROOT / '.managed-by'
SECURITY = DATA / 'security.json'
FW_PENDING = DATA / 'firewall-pending.json'
FW_TIMER = pathlib.Path('/etc/systemd/system/reality-firewall-rollback.timer')
FW_SERVICE = pathlib.Path('/etc/systemd/system/reality-firewall-rollback.service')
FW_FILES = [pathlib.Path(p) for p in ('/etc/default/ufw','/etc/ufw/ufw.conf',
    '/etc/ufw/user.rules','/etc/ufw/user6.rules')]
F2B_JAIL = pathlib.Path('/etc/fail2ban/jail.d/90-reality-oneclick.local')
SYSCTL_FILE = pathlib.Path('/etc/sysctl.d/90-reality-oneclick.conf')
LOCK = pathlib.Path('/run/lock/reality-oneclick.lock')
FLOW = 'xtls-rprx-vision'
PRIVATE_NETS = ['0.0.0.0/8','10.0.0.0/8','100.64.0.0/10','127.0.0.0/8',
 '169.254.0.0/16','172.16.0.0/12','192.168.0.0/16','198.18.0.0/15',
 '224.0.0.0/4','240.0.0.0/4','::/128','::1/128','fc00::/7','fe80::/10','ff00::/8']
DEFAULTS = [('Google',['www.google.com','dl.google.com']),
 ('ChatGPT',['chatgpt.com']),('GSMArena',['www.gsmarena.com']),
 ('Microsoft',['www.bing.com','www.microsoft.com'])]

class Failure(Exception): pass

def say(s): print(s, file=sys.stderr, flush=True)

def run(args, timeout=45, check=True, **kw):
    p = subprocess.run([str(x) for x in args], capture_output=True, text=True,
                       timeout=timeout, **kw)
    if check and p.returncode:
        raise Failure(f'{pathlib.Path(str(args[0])).name} failed: {(p.stderr or p.stdout)[-1400:]}')
    return p

def write_json(path, obj, mode=0o600):
    path=pathlib.Path(path)
    if path.is_symlink(): raise Failure('Refusing to overwrite a symlink: '+str(path))
    temporary=path.with_name(path.name+'.tmp-'+secrets.token_hex(4))
    try:
        with temporary.open('x') as f:
            os.chmod(temporary,mode); f.write(json.dumps(obj,indent=2)+'\n')
            f.flush(); os.fsync(f.fileno())
        temporary.replace(path)
    finally: temporary.unlink(missing_ok=True)

def curl(url, output=None):
    args=['curl','--fail','--silent','--show-error','--location','--proto','=https',
          '--proto-redir','=https','--connect-timeout','12','--max-time','180',
          '--retry','2','--retry-delay','1',url]
    if output: args += ['--output',str(output)]
    return run(args,timeout=580).stdout

def valid_ip(value):
    try:
        address = ipaddress.ip_address(value.strip())
        if address.is_global: return str(address)
    except ValueError: pass
    raise Failure('A public IPv4 or IPv6 address is required.')

def public_ip(override):
    if override: return valid_ip(override)
    for url in ('https://api.ipify.org','https://ipv4.icanhazip.com','https://api6.ipify.org'):
        try:
            p=run(['curl','-fsS','--connect-timeout','5','--max-time','10',url],timeout=12)
            return valid_ip(p.stdout)
        except (Failure,subprocess.TimeoutExpired): pass
    raise Failure('Public IP detection failed. Retry with --server-ip YOUR_PUBLIC_IP.')

def family(ip): return socket.AF_INET6 if ':' in ip else socket.AF_INET

def loopback(ip): return '::1' if ':' in ip else '127.0.0.1'

def free_port(ip='127.0.0.1'):
    with socket.socket(family(ip)) as s:
        s.bind((ip,0)); return s.getsockname()[1]

def wait_port(proc, ip, port):
    for _ in range(70):
        if proc is not None and proc.poll() is not None: raise Failure('Xray exited during startup.')
        try:
            with socket.create_connection((ip,port),timeout=.15): return
        except OSError: time.sleep(.1)
    raise Failure(f'Listener {ip}:{port} did not start.')

@contextlib.contextmanager
def start(binary, cfg, work, name):
    path=pathlib.Path(work)/f'{name}.json'; write_json(path,cfg)
    with open(pathlib.Path(work)/f'{name}.log','w+') as log:
        proc=subprocess.Popen([str(binary),'run','-c',str(path)],stdout=log,stderr=log)
        try: yield proc
        finally:
            proc.terminate()
            try: proc.wait(timeout=5)
            except subprocess.TimeoutExpired: proc.kill(); proc.wait()

def new_credentials(binary):
    result=run([binary,'x25519']).stdout
    values={re.sub(r'\s','',k).lower():v.strip() for k,v in
            (line.split(':',1) for line in result.splitlines() if ':' in line)}
    priv=values.get('privatekey'); pub=values.get('password') or values.get('password(publickey)') or values.get('publickey')
    if not priv or not pub or not all(re.fullmatch(r'[A-Za-z0-9_-]{43}',x) for x in (priv,pub)):
        raise Failure('Unrecognized Xray x25519 output; no configuration was installed.')
    return dict(uuid=str(uuid.uuid4()),private_key=priv,public_key=pub,short_id=secrets.token_hex(8))

def inbound(node, ip, port=None):
    return {'tag':node['label'],'listen':ip,'port':port or node['port'],'protocol':'vless',
      'settings':{'clients':[{'id':node['uuid'],'flow':FLOW}],'decryption':'none'},
      'streamSettings':{'network':'tcp','security':'reality','realitySettings':{
        'show':False,'target':node['domain']+':443','xver':0,
        'serverNames':[node['domain']],'privateKey':node['private_key'],
        'shortIds':[node['short_id']]}}}

def server_config(nodes, ip):
    return {'log':{'access':'none','loglevel':'warning'},'inbounds':[inbound(n,ip) for n in nodes if is_enabled(n)],
      'outbounds':[{'tag':'direct','protocol':'freedom','settings':{'domainStrategy':'UseIP'}},
                   {'tag':'block','protocol':'blackhole'}],
      'routing':{'domainStrategy':'IPOnDemand','rules':[
         {'type':'field','ip':PRIVATE_NETS,'outboundTag':'block'}]}}

def client_config(node, address, server_port, socks_port):
    return {'log':{'access':'none','loglevel':'warning'},
      'inbounds':[{'listen':'127.0.0.1','port':socks_port,'protocol':'socks',
                   'settings':{'auth':'noauth','udp':True}}],
      'outbounds':[{'protocol':'vless','settings':{'vnext':[{
        'address':address,'port':server_port,'users':[{
        'id':node['uuid'],'encryption':'none','flow':FLOW}]}]},
        'streamSettings':{'network':'tcp','security':'reality','realitySettings':{
          'fingerprint':'chrome','serverName':node['domain'],'password':node['public_key'],
          'shortId':node['short_id'],'spiderX':'/'}},'mux':{'enabled':False}}]}

def config_test(binary,path):
    run([binary,'run','-test','-c',path],timeout=25)

def probe_target(domain):
    # DNS resolution is also bounded by the subprocess deadline.
    p=run(['openssl','s_client','-connect',domain+':443','-servername',domain,
           '-tls1_3','-alpn','h2','-verify_return_error','-verify_hostname',domain],
           input='',timeout=18,check=False)
    output=p.stdout+p.stderr
    if p.returncode or 'TLSv1.3' not in output or 'ALPN protocol: h2' not in output:
        details='DNS lookup failed' if 'BIO_lookup' in output or 'Name or service' in output else 'TLS 1.3, certificate verification or ALPN h2 failed'
        raise Failure(details)
    # Redirects are diagnostic, not a hard TLS compatibility verdict.
    h=run(['curl','-sS','-I','--connect-timeout','5','--max-time','10',
           'https://'+domain+'/'],timeout=12,check=False)
    locations=re.findall(r'^location:\s*(.+)$',h.stdout,re.I|re.M)
    if locations: say('  HTTP redirect: '+locations[-1].strip()+' (review target suitability)')

def test_tunnel(binary,node,address,port,work,name):
    socks=free_port()
    cfg=client_config(node,address,port,socks)
    with start(binary,cfg,work,name) as proc:
        wait_port(proc,'127.0.0.1',socks)
        for url in ('https://www.example.com/','https://www.wikipedia.org/'):
            try:
                p=run(['curl','--silent','--show-error','--fail','--noproxy','',
                    '--proxy',f'socks5h://127.0.0.1:{socks}',
                    '--connect-timeout','8','--max-time','20','--output','/dev/null',
                    '--write-out','%{http_code}',url],timeout=24,check=False)
                if p.returncode==0 and p.stdout.startswith('2'): return
            except subprocess.TimeoutExpired: pass
    raise Failure('Authenticated REALITY tunnel could not fetch either HTTPS test page.')

def probe_reality(binary,node,work):
    port=free_port()
    cfg=server_config([{**node,'enabled':True}],'127.0.0.1'); cfg['inbounds'][0]['port']=port
    with start(binary,cfg,work,'probe-server') as proc:
        wait_port(proc,'127.0.0.1',port)
        test_tunnel(binary,node,'127.0.0.1',port,work,'probe-client')

def download_binary(destination,version):
    arch={'x86_64':'64','aarch64':'arm64-v8a'}.get(platform.machine())
    if not arch: raise Failure('Supported server architectures: x86_64 and aarch64.')
    if version and not re.fullmatch(r'v\d+\.\d+\.\d+',version):
        raise Failure('--version must look like v26.3.27.')
    route='tags/'+version if version else 'latest'
    release=json.loads(curl('https://api.github.com/repos/XTLS/Xray-core/releases/'+route))
    if release.get('draft') or release.get('prerelease'): raise Failure('Stable releases only.')
    tag=release['tag_name']; name=f'Xray-linux-{arch}.zip'
    asset=next((x for x in release['assets'] if x['name']==name),None)
    if not asset: raise Failure('Official Linux asset was not found.')
    expected=asset.get('digest','') or ''
    if not re.fullmatch(r'sha256:[0-9a-f]{64}',expected):
        raise Failure('Official SHA-256 asset digest is missing; refusing unverified download.')
    url=asset['browser_download_url']
    if not url.startswith('https://github.com/XTLS/Xray-core/releases/download/'):
        raise Failure('Unexpected release asset origin.')
    say('Downloading official Xray '+tag+'; checking SHA-256 ...')
    archive=pathlib.Path(destination)/'xray.zip'; curl(url,archive)
    if 'sha256:'+hashlib.sha256(archive.read_bytes()).hexdigest()!=expected:
        raise Failure('Xray download SHA-256 mismatch.')
    binary=pathlib.Path(destination)/'xray'
    with zipfile.ZipFile(archive) as z: binary.write_bytes(z.read('xray'))
    binary.chmod(0o755); archive.unlink()
    run([binary,'version'])
    return binary,tag

def make_link(node,ip):
    address='['+ip+']' if ':' in ip else ip
    params={'encryption':'none','security':'reality','sni':node['domain'],
            'fp':'chrome','pbk':node['public_key'],'sid':node['short_id'],
            'type':'tcp','flow':FLOW,'spx':'/'}
    return f"vless://{node['uuid']}@{address}:{node['port']}?"+urllib.parse.urlencode(params)+\
           '#'+urllib.parse.quote('REALITY-'+node.get('display_name',node['label'])+'-'+str(node['port']))

def load_state():
    if not CURRENT.is_symlink(): raise Failure('No managed installation. Run install first.')
    guard_runtime()
    return validate_state(json.loads((CURRENT/'state.json').read_text()))

def active(): return run(['systemctl','is-active','--quiet',SERVICE],check=False).returncode==0

def swap_link(link,target):
    temp=link.with_name(link.name+'.new')
    temp.unlink(missing_ok=True); temp.symlink_to(target); temp.replace(link)

def health(path,live=True):
    state=json.loads((path/'state.json').read_text()); binary=path/'xray'
    config_test(binary,path/'config.json')
    if live and not active(): raise Failure('Managed service is not active.')
    if not any(is_enabled(n) for n in state['nodes']):
        say('No enabled profiles. Configuration is valid; no live tunnel was tested.');return
    with tempfile.TemporaryDirectory(prefix='reality-check-') as td:
        for node in state['nodes']:
            if not is_enabled(node):continue
            test_tunnel(binary,node,loopback(state['server_ip']),node['port'],td,'health-client')
            say(f"PASS {node['label']} :{node['port']} — authenticated server-local tunnel")
    say('This does NOT test the cloud firewall, public inbound path, or an Iranian ISP.')

def unit_text():
    return f'''[Unit]
Description=Managed VLESS REALITY server
After=network.target
StartLimitIntervalSec=60
StartLimitBurst=5

[Service]
User={USER}
Group={USER}
ExecStart={CURRENT}/xray run -c {CURRENT}/config.json
Restart=on-failure
RestartSec=3
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
AmbientCapabilities=CAP_NET_BIND_SERVICE
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
'''

REALITY_FALLBACKS = ['www.google.com','chatgpt.com','www.bing.com','www.microsoft.com','www.deepseek.com','deepseek.com','www.cloudflare.com']

def install(args):
    updating=args.command=='update'
    if ROOT.exists(): guard_runtime(allow_empty=True)
    if CURRENT.exists() and args.command=='install':
        say('Already installed; preserving version, configuration and credentials.')
        promote_manager(); health(CURRENT); show_links(); return
    if UNIT.exists() and not CURRENT.is_symlink():
        raise Failure('Service name already exists outside this managed installation.')
    old=load_state() if args.command in ('update','reconfigure') or (args.command=='reinstall' and CURRENT.exists()) else None
    if old is None and SAVED.exists():
        receipt_data(); old=validate_state(json.loads(SAVED.read_text()))
        say('Restoring saved connection credentials from the previous uninstall.')
    ip=public_ip(args.server_ip) if args.server_ip or not old else old['server_ip']
    say('Client endpoint IP: '+ip)
    preserve_profiles=bool(old and args.command!='reconfigure' and not args.ports and not args.domains)
    if preserve_profiles:
        specs=[(n['label'],[n['domain']],n['port'],n) for n in old['nodes']]
    else:
        previous_specs=old.get('requested_profiles',[]) if old else []
        default_ports=','.join(str(p['port']) for p in previous_specs) if previous_specs else '2025,2026,2027,2028'
        try: ports=[int(p) for p in (args.ports or default_ports).split(',')]
        except ValueError: raise Failure('--ports must contain one to four comma-separated integers.')
        if not 1<=len(ports)<=4 or len(set(ports))!=len(ports) or any(p<1 or p>65535 for p in ports):
            raise Failure('One to four distinct ports in range 1..65535 are required.')
        candidates=[(p['label'],p['domains']) for p in previous_specs] if len(previous_specs)==len(ports) else copy.deepcopy(DEFAULTS[:len(ports)])
        if args.domains:
            domains=args.domains.split(',')
            if len(domains)!=len(ports) or any(not re.fullmatch(r'(?=.{1,253}$)(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\.)+[A-Za-z]{2,63}',d) for d in domains):
                raise Failure('--domains requires one plain DNS name per port, without URL/port/path.')
            candidates=[(label,[domain]) for (label,_),domain in zip(candidates,domains)]
        # Do not stop or replace another process occupying a requested port.
        own_ports={n['port'] for n in old['nodes'] if is_enabled(n)} if old and active() else set()
        for port in ports:
            if port in own_ports: continue
            try:
                with socket.socket(family(ip)) as s: s.bind(('::' if ':' in ip else '0.0.0.0',port))
            except OSError: raise Failure(f'TCP port {port} is occupied. Choose other --ports.')
        by_label={n['label']:n for n in old['nodes']} if old else {}
        specs=[(label,domains,port,by_label.get(label)) for (label,domains),port in zip(candidates,ports)]
    meta=receipt_data(create=True)
    ROOT.mkdir(mode=0o755,parents=True,exist_ok=True); ROOT.chmod(0o755)
    MARKER.write_text(OWNER+'\n'); MARKER.chmod(0o600)
    (ROOT/'releases').mkdir(mode=0o755,exist_ok=True); (ROOT/'releases').chmod(0o755)
    with tempfile.TemporaryDirectory(prefix='reality-stage-') as td:
        selected_version=args.version or (old['version'] if old and args.command!='update' else None)
        if args.command=='reconfigure' and CURRENT.exists() and selected_version==old['version']:
            binary,version=CURRENT/'xray',old['version']
        else:binary,version=download_binary(td,selected_version)
        nodes=[]; failures=[]
        for label,domains,port,previous_node in specs:
            creds=previous_node or new_credentials(binary)
            if previous_node and not is_enabled(previous_node):
                node={**previous_node,'port':port,'domain':domains[0] if args.domains else previous_node['domain']}
                if node['port']!=previous_node['port'] or node['domain']!=previous_node['domain']:
                    probe_target(node['domain']);probe_reality(binary,node,td)
                nodes.append(node);continue
            # Preserve existing profiles on updates; automatic fallback applies to new profiles.
            tested_domains=list(dict.fromkeys(domains + (REALITY_FALLBACKS if not previous_node or args.command=='reconfigure' else [])))
            for domain in tested_domains:
                say(f'Testing {label}: {domain}:443 ...')
                node={**creds,'label':label,'domain':domain,'port':port}
                try:
                    probe_target(domain); probe_reality(binary,node,td)
                    if not previous_node or domain!=domains[0]:node['display_name']=domain[:40]
                    nodes.append(node); say('  PASS: TLS + authenticated REALITY + HTTPS');
                    if domain!=domains[0]:say('  REPLACED '+domains[0]+' -> '+domain+' on TCP/'+str(port))
                    break
                except (Failure,subprocess.TimeoutExpired) as e:
                    say('  FAIL: '+str(e)); failures.append(f'{label} {domain}: {e}')
            else:
                if previous_node: raise Failure('An existing profile failed testing; old installation is unchanged.')
                raise Failure(f'No working target for {label} on TCP/{port}; all replacements failed. Nothing was activated.')
        if not nodes: raise Failure('No target passed. Nothing was activated. Check server DNS/outbound access.')
        cfg=server_config(nodes,'::' if ':' in ip else '0.0.0.0')
        write_json(pathlib.Path(td)/'config.json',cfg); config_test(binary,pathlib.Path(td)/'config.json')
        if run(['getent','passwd',USER],check=False).returncode:
            run(['useradd','--system','--user-group','--no-create-home','--shell','/usr/sbin/nologin',USER])
            meta['user_created']=True; write_json(RECEIPT,meta)
        import pwd,grp
        account=pwd.getpwnam(USER); gid=grp.getgrnam(USER).gr_gid
        if account.pw_uid==0 or account.pw_shell not in ('/usr/sbin/nologin','/sbin/nologin','/bin/false'):
            raise Failure('Existing realitysvc user is unsuitable for a dedicated service.')
        release=ROOT/'releases'/(time.strftime('%Y%m%dT%H%M%S')+'-'+secrets.token_hex(3))
        release.mkdir(mode=0o750); release.chmod(0o750); os.chown(release,0,gid)
        shutil.copy2(binary,release/'xray')
        write_json(release/'config.json',cfg,0o640); os.chown(release/'config.json',0,gid)
        state={'schema':1,'version':version,'server_ip':ip,'nodes':nodes,'failed_candidates':failures,
               'requested_profiles':old.get('requested_profiles',[]) if preserve_profiles else
               [dict(label=label,domains=domains,port=port) for label,domains,port,_ in specs]}
        write_json(release/'state.json',state)
        (release/'links.txt').write_text('\n'.join(make_link(n,ip) for n in nodes if is_enabled(n))+'\n')
        (release/'links.txt').chmod(0o600)
        (release/'install-report.txt').write_text('Xray '+version+'\n'+
           '\n'.join(f"{'ENABLED' if is_enabled(n) else 'DISABLED'} {n['label']} {n['domain']} TCP/{n['port']}" for n in nodes)+
           '\nFailed candidates:\n'+'\n'.join(failures)+'\n')
        (release/'install-report.txt').chmod(0o600)
        old_path=CURRENT.resolve() if CURRENT.is_symlink() else None
        old_unit=UNIT.read_bytes() if UNIT.exists() else None
        was_active=active()
        was_enabled=run(['systemctl','is-enabled','--quiet',SERVICE],check=False).returncode==0
        try:
            UNIT.write_text(unit_text()); UNIT.chmod(0o644)
            swap_link(CURRENT,release)
            run(['systemctl','daemon-reload']); run(['systemctl','restart',SERVICE])
            for n in nodes:
                if is_enabled(n):wait_port(None,loopback(ip),n['port'])
            health(CURRENT)
            run(['systemctl','enable',SERVICE])
            if old_path: swap_link(PREVIOUS,old_path)
        except BaseException:
            say('Activation failed; restoring previous service and release ...')
            run(['systemctl','stop',SERVICE],check=False)
            if old_path: swap_link(CURRENT,old_path)
            else: CURRENT.unlink(missing_ok=True)
            if old_unit is not None: UNIT.write_bytes(old_unit)
            else: UNIT.unlink(missing_ok=True)
            run(['systemctl','daemon-reload'],check=False)
            if was_enabled: run(['systemctl','enable',SERVICE],check=False)
            else: run(['systemctl','disable',SERVICE],check=False)
            if was_active: run(['systemctl','start',SERVICE],check=False)
            raise
        promote_manager()
        add_firewall_rules([n for n in nodes if is_enabled(n)],args.no_ufw)
        SAVED.unlink(missing_ok=True)
        say('READY: '+str(sum(is_enabled(n) for n in nodes))+' enabled profiles.')
        say('Cloud/provider firewall: allow inbound TCP on '+','.join(str(n['port']) for n in nodes if is_enabled(n))+'.')
        say('If NAT is used, forward the same external ports to this host. Check the public IP above.')
        say('Public connectivity must be tested from the client.')
        say('Report: sudo cat /opt/reality-oneclick/current/install-report.txt')
        say('Direct config links:')
        show_links()

def rollback():
    guard_runtime()
    if not PREVIOUS.is_symlink(): raise Failure('No previous successful release to restore.')
    prior=PREVIOUS.resolve(); current=CURRENT.resolve()
    if not prior.is_relative_to(ROOT/'releases'): raise Failure('Previous release is outside the managed directory.')
    config_test(prior/'xray',prior/'config.json')
    try:
        swap_link(CURRENT,prior); run(['systemctl','restart',SERVICE]); health(CURRENT)
    except BaseException:
        swap_link(CURRENT,current); run(['systemctl','restart',SERVICE],check=False); raise
    swap_link(PREVIOUS,current); say('Rollback completed.'); show_links()

def validate_state(state):
    if state.get('schema')!=1 or not isinstance(state.get('nodes'),list) or not state['nodes']:
        raise Failure('Invalid managed state.')
    valid_ip(state['server_ip'])
    labels=set();ports=set()
    for n in state['nodes']:
        uuid.UUID(n['uuid'])
        if type(n['port']) is not int or not 1<=n['port']<=65535: raise Failure('Invalid saved port.')
        if n['port'] in ports or n['label'] in labels:raise Failure('Duplicate saved profile or port.')
        ports.add(n['port']);labels.add(n['label'])
        validate_domain(n['domain'])
        if 'enabled' in n and type(n['enabled']) is not bool:raise Failure('Invalid saved profile state.')
        if 'display_name' in n and not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 ._-]{0,39}',n['display_name']):
            raise Failure('Invalid saved display name.')
        for key in ('private_key','public_key'):
            if not re.fullmatch(r'[A-Za-z0-9_-]{43}',n[key]): raise Failure('Invalid saved key.')
        if not re.fullmatch(r'[0-9a-f]{16}',n['short_id']): raise Failure('Invalid saved short ID.')
    return state

def guard_runtime(allow_empty=False):
    if ROOT.is_symlink() or UNIT.is_symlink() or (ROOT/'releases').is_symlink(): raise Failure('Managed root/unit cannot be symlinks.')
    if UNIT.exists() and f'ExecStart={CURRENT}/xray run -c {CURRENT}/config.json' not in UNIT.read_text():
        raise Failure('Service belongs to another installation; refusing to change it.')
    if not ROOT.exists():
        if UNIT.exists(): raise Failure('Service exists without its managed runtime; inspect manually.')
        return
    if not any(ROOT.iterdir()) and allow_empty: return
    if MARKER.is_symlink(): raise Failure('Invalid ownership marker.')
    has_marker=MARKER.exists() and MARKER.read_text().strip()==OWNER
    legacy=CURRENT.is_symlink() and UNIT.exists()
    if not has_marker and not legacy: raise Failure('Directory ownership is unrecognized; refusing to delete or overwrite it.')
    if CURRENT.is_symlink():
        release=CURRENT.resolve()
        if not release.is_relative_to(ROOT/'releases') or not (release/'state.json').is_file():
            raise Failure('Invalid managed release path.')
        validate_state(json.loads((release/'state.json').read_text()))
    elif CURRENT.exists(): raise Failure('Expected a managed current-release symlink.')

def receipt_data(create=False):
    if DATA.is_symlink() or RECEIPT.is_symlink() or SAVED.is_symlink():
        raise Failure('Managed state paths cannot be symlinks.')
    if RECEIPT.exists():
        meta=json.loads(RECEIPT.read_text())
        if meta.get('owner')!=OWNER: raise Failure('Unrecognized ownership receipt.')
        return meta
    if DATA.exists() and any(DATA.iterdir()): raise Failure('State directory already contains unowned data.')
    meta={'owner':OWNER,'ufw_tag':'reality-oc-'+secrets.token_hex(6),'ufw_ports':[],'user_created':False}
    if create:
        DATA.mkdir(mode=0o700,parents=True,exist_ok=True); DATA.chmod(0o700);write_json(RECEIPT,meta)
    return meta

def promote_manager():
    source=pathlib.Path(os.environ['REALITY_INSTALLER_SOURCE'])
    if MANAGER.is_symlink(): raise Failure('Manager path is a symlink.')
    if MANAGER.exists() and not MANAGER.read_text().startswith('#!/usr/bin/env bash\n# REALITY One Click'):
        raise Failure('Manager path belongs to another program.')
    if source.resolve()!=MANAGER.resolve():
        temp=MANAGER.with_name(MANAGER.name+'.new')
        if temp.exists() or temp.is_symlink(): raise Failure('Stale manager staging path; inspect '+str(temp))
        try:
            with temp.open('x') as f:
                os.chmod(temp,0o700);f.write(source.read_text());f.flush();os.fsync(f.fileno())
            temp.replace(MANAGER)
        finally: temp.unlink(missing_ok=True)

def show_links(profile=None):
    state=load_state()
    if profile:
        node=select_profile(state,profile)['node']
        if node is None:raise Failure('This profile is not installed.')
        if not is_enabled(node):raise Failure('This profile is disabled. Enable it before exporting a connection link.')
        nodes=[node]
    else:nodes=[n for n in state['nodes'] if is_enabled(n)]
    if not nodes:say('No enabled profiles.');return
    print('\n'.join(make_link(n,state['server_ip']) for n in nodes),flush=True)

def ufw_rules():
    p=run(['ufw','show','added'])
    result=[]
    for line in p.stdout.splitlines():
        if line.startswith('ufw '): result.append(shlex.split(line))
    return result

def add_firewall_rules(nodes,disabled=False):
    if disabled or not shutil.which('ufw'): return
    status=run(['ufw','status'],check=False)
    if status.returncode or 'Status: active' not in status.stdout: return
    meta=receipt_data(create=True)
    try:
        rules=ufw_rules()
        for n in nodes:
            port=str(n['port']);tag=meta['ufw_tag']
            expected=['ufw','allow',port+'/tcp','comment',tag]
            if expected in rules: continue
            # Respect any existing allow rule mentioning this port. It may be source-limited.
            if any('allow' in r and (port in r or port+'/tcp' in r) for r in rules):
                say('Existing UFW allow rule retained for '+port+'; check its source/family coverage.');continue
            if n['port'] not in meta['ufw_ports']:
                meta['ufw_ports'].append(n['port']);write_json(RECEIPT,meta)
            run(['ufw','allow',port+'/tcp','comment',tag]);rules=ufw_rules()
    except (Failure,subprocess.TimeoutExpired) as e:
        say('UFW setup incomplete: '+str(e)+'; check firewall manually.')

def remove_firewall_rules(meta):
    if not meta['ufw_ports']: return
    if not shutil.which('ufw'): raise Failure('Cannot clean recorded UFW rules while ufw is unavailable.')
    rules=ufw_rules();tag=meta['ufw_tag']
    for port in list(meta['ufw_ports']):
        expected=['ufw','allow',str(port)+'/tcp','comment',tag]
        if expected in rules:
            run(['ufw','--force','delete','allow',str(port)+'/tcp','comment',tag])
            rules=ufw_rules()
            if expected in rules: raise Failure('UFW rule was not removed; uninstall can be retried.')
        meta['ufw_ports'].remove(port);write_json(RECEIPT,meta)

def confirm_uninstall(args):
    if args.yes: return
    message=('Purge also erases saved connection credentials.' if args.purge else
             'Remove the service and keep credentials for reinstall.')
    try:
        if ask(message+'\nType DELETE to continue: ')=='DELETE':return
    except (Failure,Cancelled):pass
    raise Failure('Uninstall cancelled. For noninteractive use, add --yes.')

def uninstall(args):
    guard_runtime()
    if FW_PENDING.exists(): raise Failure('Confirm or roll back the pending firewall first.')
    meta=receipt_data(create=False)
    manager_owned=MANAGER.exists() and not MANAGER.is_symlink() and MANAGER.read_text().startswith(
        '#!/usr/bin/env bash\n# REALITY One Click')
    if not ROOT.exists() and not SAVED.exists() and not RECEIPT.exists() and not manager_owned:
        say('Nothing managed is installed.');return
    confirm_uninstall(args)
    meta=receipt_data(create=True)
    if CURRENT.is_symlink():
        # Always checkpoint before stopping, even for purge; erase after successful removal.
        write_json(SAVED,load_state())
    if UNIT.exists():
        run(['systemctl','stop',SERVICE])
        if active(): raise Failure('Service is still active. No runtime files were deleted.')
        run(['systemctl','disable',SERVICE])
    remove_firewall_rules(meta)
    if UNIT.exists(): UNIT.unlink();run(['systemctl','daemon-reload'])
    run(['systemctl','reset-failed',SERVICE],check=False)
    if ROOT.exists(): shutil.rmtree(ROOT)
    if args.purge:
        SAVED.unlink(missing_ok=True)
        if meta.get('user_created') and run(['getent','passwd',USER],check=False).returncode==0:
            run(['userdel',USER])
            if run(['getent','group',USER],check=False).returncode==0:
                run(['groupdel',USER])
        # Remove only known receipt/state files; never recurse over unknown files in DATA.
        keep_security=SECURITY.exists() or HY_ROOT.exists() or HY_SAVED.exists() or HY_CACHE.exists()
        if not keep_security:
            (DATA/'last-failure.json').unlink(missing_ok=True)
            RECEIPT.unlink(missing_ok=True)
        if DATA.exists() and not any(DATA.iterdir()): DATA.rmdir()
        if manager_owned and not keep_security: MANAGER.unlink()
        say('PURGE OK: managed runtime and saved connection credentials removed.')
        if keep_security:say('Manager retained for host protection or Hysteria. Remove those separately before purging the manager.')
    else:
        promote_manager()
        say('UNINSTALL OK: connection credentials preserved; reinstall with sudo reality-manager install')
    say('Shared packages and firewall rules without this installation\'s unique tag are retained.')

def service_command(command):
    if command=='status' and not CURRENT.exists():
        say('Service is not installed. Saved credentials: '+('yes' if SAVED.exists() else 'no'));return
    state=load_state()
    if command=='status':
        say('Xray '+state['version']+'; service '+('active' if active() else 'inactive'))
        list_profiles(sys.stderr)
    elif command=='logs':
        say(run(['journalctl','-u',SERVICE,'-n','60','--no-pager']).stdout)
    elif command in ('start','stop','restart'):
        run(['systemctl',command,SERVICE])
        if command!='stop':
            for n in state['nodes']:
                if is_enabled(n):wait_port(None,loopback(state['server_ip']),n['port'])
        say(command.upper()+' OK')

def is_enabled(node): return node.get('enabled',True)

def profile_rows(state):
    specs=copy.deepcopy(state.get('requested_profiles') or [
        dict(label=label,domains=domains,port=port) for (label,domains),port in zip(DEFAULTS,range(2025,2029))])
    known={p['label'] for p in specs}
    specs.extend(dict(label=n['label'],domains=[n['domain']],port=n['port'])
                 for n in state['nodes'] if n['label'] not in known)
    by_label={n['label']:n for n in state['nodes']}
    return [dict(index=i,label=p['label'],name=by_label.get(p['label'],{}).get('display_name',p['label']),
        port=by_label.get(p['label'],{}).get('port',p['port']),
        domain=by_label.get(p['label'],{}).get('domain',p['domains'][0]),
        domains=p['domains'],node=by_label.get(p['label'])) for i,p in enumerate(specs,1)]

def select_profile(state,selector):
    if not selector: raise Failure('Choose --profile by list number, ID, or port.')
    selector=str(selector)
    rows=profile_rows(state)
    exact=[r for r in rows if r['label'].casefold()==selector.casefold()]
    if exact:return exact[0]
    numbered=[r for r in rows if str(r['index'])==selector]
    if numbered:return numbered[0]
    ports=[r for r in rows if str(r['port'])==selector]
    if len(ports)==1:return ports[0]
    raise Failure('Unknown or ambiguous profile. Run: sudo reality-manager list')

def list_profiles(stream=None):
    if stream is None:stream=sys.stdout
    if not CURRENT.exists():
        print('No active installation. Choose Install to continue.',file=stream);return
    state=load_state();running=active()
    print('REALITY Manager 1.7 | Xray '+state['version']+' | '+state['server_ip'],file=stream)
    print(f"{'#':<3} {'NAME':<20} {'PORT':<6} {'DOMAIN / SNI':<34} STATE",file=stream)
    for r in profile_rows(state):
        status='NOT SET' if r['node'] is None else 'DISABLED' if not is_enabled(r['node']) else 'ENABLED' if running else 'STOPPED'
        print(f"{r['index']:<3} {r['name'][:19]:<20} {r['port']:<6} {r['domain'][:33]:<34} {status}",file=stream)
    print('STATE shows configuration/service status, not reachability from your client.',file=stream)

def validate_domain(domain):
    domain=domain.strip().lower().rstrip('.')
    if not re.fullmatch(r'(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}',domain):
        raise Failure('Enter a DNS name only, for example www.google.com (no https://, port, or path).')
    return domain

def check_free_port(state,row,port):
    if not 1<=port<=65535:raise Failure('TCP port must be in 1..65535.')
    if any(r['label']!=row['label'] and r['port']==port for r in profile_rows(state)):
        raise Failure('That port is assigned to another profile, including disabled or unset profiles.')
    old=row['node']
    if old and is_enabled(old) and old['port']==port and active():return
    ip=state['server_ip']
    try:
        with socket.socket(family(ip)) as s:s.bind(('::' if ':' in ip else '0.0.0.0',port))
    except OSError:raise Failure('TCP port is occupied by another listener; nothing was changed.')

def save_profile_change(state,label,test_changed,allow_ufw=True):
    validate_state(state)
    old_path=CURRENT.resolve();old_config=json.loads((old_path/'config.json').read_text())
    cfg=server_config(state['nodes'],'::' if ':' in state['server_ip'] else '0.0.0.0')
    release=ROOT/'releases'/(time.strftime('%Y%m%dT%H%M%S')+'-'+secrets.token_hex(3))
    gid=(old_path/'config.json').stat().st_gid
    release.mkdir(mode=0o750);release.chmod(0o750);os.chown(release,0,gid)
    try:
        # The immutable core binary is shared with the previous release: no download or extra full copy.
        os.link(old_path/'xray',release/'xray')
        write_json(release/'config.json',cfg,0o640);os.chown(release/'config.json',0,gid)
        config_test(release/'xray',release/'config.json')
        write_json(release/'state.json',state)
        (release/'links.txt').write_text('\n'.join(make_link(n,state['server_ip']) for n in state['nodes'] if is_enabled(n))+'\n')
        (release/'links.txt').chmod(0o600)
        (release/'install-report.txt').write_text('Profile change: '+label+'\nCore: '+state['version']+'\n')
        (release/'install-report.txt').chmod(0o600)
    except BaseException:
        shutil.rmtree(release);raise
    was_active=active();restart_needed=cfg!=old_config
    try:
        swap_link(CURRENT,release)
        if was_active and restart_needed:
            run(['systemctl','restart',SERVICE])
            for n in state['nodes']:
                if is_enabled(n):wait_port(None,loopback(state['server_ip']),n['port'])
            if not active():raise Failure('Service did not remain active after the change.')
            node=next(n for n in state['nodes'] if n['label']==label)
            if test_changed and is_enabled(node):
                with tempfile.TemporaryDirectory(prefix='reality-edit-check-') as td:
                    test_tunnel(release/'xray',node,loopback(state['server_ip']),node['port'],td,'client')
    except BaseException:
        say('Change failed. Restoring the previous configuration ...')
        swap_link(CURRENT,old_path)
        if was_active and restart_needed:
            restored=run(['systemctl','restart',SERVICE],check=False)
            if restored.returncode or not active():say('Previous files restored, but the service needs attention. Run reality-manager logs.')
        shutil.rmtree(release);raise
    swap_link(PREVIOUS,old_path)
    if restart_needed:add_firewall_rules([n for n in state['nodes'] if is_enabled(n)],not allow_ufw)
    say('SAVED. Xray core and existing credentials were retained.')
    if not was_active:say('The service remains stopped. Start it before connecting.')
    if was_active and restart_needed:say('Service restarted. Other profiles may have briefly disconnected.')
    if restart_needed:
        say('Previous port rules remain for rollback. Check cloud firewall/NAT for the new port.')

def edit_profile(args):
    state=load_state();row=select_profile(state,args.profile);old=row['node']
    if args.command=='disable' and old is None:raise Failure('This profile is not installed.')
    if args.command=='edit' and all(getattr(args,k,None) is None for k in ('port','domain','name')):
        raise Failure('Provide --port, --domain, or --name.')
    port=args.port if getattr(args,'port',None) is not None else row['port']
    domain=validate_domain(args.domain if getattr(args,'domain',None) is not None else row['domain'])
    name=getattr(args,'name',None)
    if name is not None:
        name=name.strip()
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 ._-]{0,39}',name):
            raise Failure('Use a 1..40 character English display name: letters, digits, spaces, dot, dash, underscore.')
    enabled=False if args.command=='disable' else True if args.command=='enable' else is_enabled(old or {})
    network_changed=old is None or port!=old['port'] or domain!=old['domain'] or (enabled and not is_enabled(old))
    if enabled and network_changed:check_free_port(state,row,port)
    elif getattr(args,'port',None) is not None:
        if not 1<=port<=65535:raise Failure('TCP port must be in 1..65535.')
        if any(r['label']!=row['label'] and r['port']==port for r in profile_rows(state)):
            raise Failure('That port is assigned to another profile.')
    node=copy.deepcopy(old) if old else dict(label=row['label'],**new_credentials(CURRENT/'xray'))
    node.update(port=port,domain=domain,enabled=enabled)
    if name is not None:node['display_name']=name
    if old==node:
        say('No changes needed.')
        if enabled:show_links(row['label'])
        return
    if network_changed:
        say('Testing '+domain+':443 with the installed Xray core ...')
        with tempfile.TemporaryDirectory(prefix='reality-edit-probe-') as td:
            probe_target(domain);probe_reality(CURRENT/'xray',node,td)
    next_state=copy.deepcopy(state)
    next_state['nodes']=[node if n['label']==row['label'] else n for n in next_state['nodes']]
    if old is None:next_state['nodes'].append(node)
    specs=[]
    for r in profile_rows(state):
        specs.append(dict(label=r['label'],port=port if r['label']==row['label'] else r['port'],
            domains=[domain] if r['label']==row['label'] and getattr(args,'domain',None) is not None else r['domains']))
    next_state['requested_profiles']=specs
    save_profile_change(next_state,row['label'],network_changed,not getattr(args,'no_ufw',False))
    if enabled:
        say('Import this updated config link into your client:');show_links(row['label'])
    else:say('Profile disabled. Its credentials remain saved; enable it to reuse them.')

def check_profile(selector):
    state=load_state();row=select_profile(state,selector);node=row['node']
    if node is None:raise Failure('This profile is not installed. Set a working domain first.')
    if not is_enabled(node):raise Failure('Profile is disabled. Enable it before testing the live listener.')
    if not active():raise Failure('Service is stopped. Start it before testing.')
    with tempfile.TemporaryDirectory(prefix='reality-profile-check-') as td:
        test_tunnel(CURRENT/'xray',node,loopback(state['server_ip']),node['port'],td,'client')
    say('PASS '+row['label']+' — authenticated server-local tunnel. Test your client network separately.')

# Hysteria has independent runtime/service/cache paths. REALITY uninstall never removes these.
HY_ROOT = pathlib.Path('/opt/hysteria-oneclick')
HY_CURRENT = HY_ROOT/'current'
HY_PREVIOUS = HY_ROOT/'previous'
HY_MARKER = HY_ROOT/'.managed-by'
HY_SAVED = DATA/'hysteria-saved.json'
HY_CACHE = pathlib.Path('/var/lib/hysteria-oneclick')
HY_UNIT = pathlib.Path('/etc/systemd/system/hysteria-oneclick.service')
HY_SERVICE = 'hysteria-oneclick.service'
HY_USER = 'hysteriasvc'
HY_COMMANDS = ['hy2','hy2-install','hy2-edit','hy2-update','hy2-uninstall','hy2-rollback',
    'hy2-links','hy2-status','hy2-check','hy2-start','hy2-stop','hy2-restart','hy2-logs']

def hy_active():
    return run(['systemctl','is-active','--quiet',HY_SERVICE],check=False).returncode==0

def hy_guard():
    for p in (HY_ROOT,HY_MARKER,HY_UNIT,HY_SAVED,HY_CACHE):
        if p.is_symlink():raise Failure('Unexpected Hysteria symlink: '+str(p))
    meta=receipt_data()
    if HY_ROOT.exists() and (not HY_MARKER.is_file() or HY_MARKER.read_text()!=OWNER):
        raise Failure('Hysteria runtime is not owned by this manager.')
    if HY_CACHE.exists() and not meta.get('hy_cache_owned'):
        raise Failure('Hysteria cache belongs to another installation.')
    if HY_UNIT.exists() and not HY_UNIT.read_text().startswith('# '+OWNER+' Hysteria\n'):
        raise Failure('Hysteria unit belongs to another installation.')
    for link in (HY_CURRENT,HY_PREVIOUS):
        if link.is_symlink():
            if not link.resolve().is_relative_to((HY_ROOT/'releases').resolve()) or not (link/'state.json').is_file():
                raise Failure('Invalid Hysteria release link.')
        elif link.exists():raise Failure('Expected a Hysteria release symlink.')

def parse_domain_list(text,limit=10):
    if not isinstance(text,str) or len(text)>16384:raise Failure('Domain list is too large.')
    values=[];rejected=[];seen=set()
    for token in re.split(r'[\s,;\u060c]+',text.strip()):
        if not token:continue
        try:
            raw=token.strip()
            if '://' in raw:
                url=urllib.parse.urlsplit(raw)
                if url.scheme.lower() not in ('http','https') or url.username is not None or url.password is not None:
                    raise Failure('Use a plain hostname or HTTP(S) URL without credentials.')
                if url.port not in (None,80,443):raise Failure('Do not attach a custom port to a domain.')
                raw=url.hostname or ''
            raw=raw.rstrip('.').lower().encode('idna').decode('ascii')
            domain=validate_domain(raw)
            if domain not in seen:values.append(domain);seen.add(domain)
        except (Failure,ValueError,UnicodeError) as e:rejected.append((token,str(e)))
    if len(values)>limit:raise Failure('At most '+str(limit)+' unique domains per Hysteria service; split or shorten the list.')
    return values,rejected

def hy_domains(s):
    return [] if s['mode']=='self-signed' else s.get('domains',[s['domain']])

def hy_variants(s):
    return [s] if s['mode']=='self-signed' else [{**s,'domain':domain,'port':s.get('domain_ports',{}).get(domain,s['port'])} for domain in hy_domains(s)]

def hy_links_text(s,insecure=False):
    return '\n'.join(hy_link(variant,insecure) for variant in hy_variants(s))+'\n'

def hy_validate(s):
    if s.get('schema')!=1 or s.get('protocol')!='hysteria2':raise Failure('Invalid Hysteria state.')
    valid_ip(s['server_ip'])
    if type(s['port']) is not int or not 1<=s['port']<=65535:raise Failure('UDP port must be in 1..65535.')
    if s['mode'] not in ('http','cloudflare','self-signed'):raise Failure('Unknown certificate mode.')
    for key in ('password','obfs_password'):
        if not re.fullmatch(r'[A-Za-z0-9_-]{32,128}',s[key]):raise Failure('Invalid saved Hysteria credential.')
    if s['obfs'] not in ('none','salamander'):raise Failure('Unsupported obfuscation.')
    if s['mode']=='self-signed':
        if not re.fullmatch(r'[0-9a-f]{64}',s.get('pin','')):raise Failure('Missing certificate fingerprint.')
        if not s.get('certificate') or not s.get('private_key'):raise Failure('Missing saved certificate/key.')
    else:
        validate_domain(s['domain'])
        domains=hy_domains(s)
        if not isinstance(domains,list) or not 1<=len(domains)<=10 or any(not isinstance(d,str) for d in domains):raise Failure('Invalid saved domain list.')
        if len(set(domains))!=len(domains) or s['domain']!=domains[0]:raise Failure('Invalid primary domain or duplicate saved domains.')
        for domain in domains:
            if validate_domain(domain)!=domain:raise Failure('Saved domains must be normalized.')
        if s.get('email') and not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',s['email']):raise Failure('Invalid ACME contact email.')
        if s['mode']=='cloudflare' and not re.fullmatch(r'[A-Za-z0-9_-]{20,256}',s.get('cf_token','')):
            raise Failure('A Cloudflare API token is required. Do not use a Global API Key.')
    if 'domain_ports' in s:
        ports=s['domain_ports']
        if s['mode']=='self-signed' or not isinstance(ports,dict) or set(ports)!=set(hy_domains(s)):
            raise Failure('Domain port mapping must cover every Hysteria domain.')
        if any(type(p) is not int or not 1<=p<=65535 for p in ports.values()) or len(set(ports.values()))!=len(ports):
            raise Failure('Each domain requires a distinct UDP port in 1..65535.')
        if ports[s['domain']]!=s['port']:raise Failure('Primary UDP port does not match mapping.')
    return s

def hy_state():
    hy_guard()
    if not HY_CURRENT.is_symlink():raise Failure('Hysteria 2 is not installed. Choose Hysteria 2 > Install.')
    return hy_validate(json.loads((HY_CURRENT/'state.json').read_text()))

def hy_endpoint(host,port):return ('['+host+']' if ':' in host else host)+':'+str(port)

def hy_link(s,insecure=False):
    host=s['server_ip'] if s['mode']=='self-signed' else s['domain']
    params={'insecure':'1' if insecure or s['mode']=='self-signed' else '0'}
    if s['mode']!='self-signed':params['sni']=s['domain']
    if s['mode']=='self-signed' and not insecure:params['pinSHA256']=s['pin']
    if s['obfs']=='salamander':params.update(obfs='salamander',**{'obfs-password':s['obfs_password']})
    return 'hysteria2://'+urllib.parse.quote(s['password'],safe='')+'@'+hy_endpoint(host,s['port'])+'/?'+urllib.parse.urlencode(params)+'#Hysteria2-'+(host+'-' if len(hy_domains(s))>1 else '')+str(s['port'])

def hy_show_links(insecure=False):
    s=hy_state()
    if insecure:say('WARNING: this link skips server identity verification. Some clients reject it. Prefer the default pinned link or ACME.')
    elif s['mode']=='self-signed':say('Pinned certificate: your client MUST enforce pinSHA256. Use an ACME domain if it cannot.')
    if not hy_active():say('The service is stopped. Start it before connecting.')
    print(hy_links_text(s,insecure),end='',flush=True)

def hy_config(s,release):
    cfg={'listen':hy_endpoint('::' if ':' in s['server_ip'] else '0.0.0.0',s['port']),
        'auth':{'type':'password','password':s['password']},'ignoreClientBandwidth':True,
        'disableUDP':False,'acl':{'inline':['reject('+n+')' for n in PRIVATE_NETS]+['direct(all)']},
        'masquerade':{'type':'string','string':{'content':'Not found','statusCode':404,'headers':{'Content-Type':'text/plain'}}}}
    if s['obfs']=='salamander':cfg['obfs']={'type':'salamander','salamander':{'password':s['obfs_password']}}
    if s['mode']=='self-signed':cfg['tls']={'cert':str(release/'server.crt'),'key':str(release/'server.key'),'sniGuard':'dns-san'}
    else:
        cfg['acme']={'domains':hy_domains(s),'email':s.get('email',''),'ca':'letsencrypt',
            'dir':str(HY_CACHE),'listenHost':'::' if ':' in s['server_ip'] else '0.0.0.0',
            'type':'dns' if s['mode']=='cloudflare' else 'http'}
        if s['mode']=='cloudflare':cfg['acme']['dns']={'name':'cloudflare','config':{'cloudflare_api_token':s['cf_token']}}
    return cfg

def hy_client(s,address,socks_port):
    tls={'insecure':s['mode']=='self-signed'}
    if s['mode']=='self-signed':tls['pinSHA256']=s['pin']
    else:tls['sni']=s['domain']
    cfg={'server':hy_endpoint(address,s['port']),'auth':s['password'],'tls':tls,
        'socks5':{'listen':'127.0.0.1:'+str(socks_port)},'lazy':False}
    if s['obfs']=='salamander':cfg['obfs']={'type':'salamander','salamander':{'password':s['obfs_password']}}
    return cfg

@contextlib.contextmanager
def hy_process(binary,mode,cfg,work,name):
    path=pathlib.Path(work)/(name+'.json');write_json(path,cfg)
    logpath=pathlib.Path(work)/(name+'.log')
    with logpath.open('w+') as log:
        logpath.chmod(0o600)
        proc=subprocess.Popen([str(binary),mode,'--disable-update-check','--log-level','warn','-c',str(path)],stdout=log,stderr=log)
        try:yield proc
        finally:
            proc.terminate()
            try:proc.wait(timeout=4)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()

def hy_probe(binary,s,address,work,egress=True):
    socks=free_port();cfg=hy_client(s,address,socks)
    with hy_process(binary,'client',cfg,work,'hy-client') as proc:
        # With lazy=false the official client authenticates BEFORE opening SOCKS5.
        for _ in range(60):
            if proc.poll() is not None:raise Failure('Hysteria authentication/TLS failed. Check hy2-logs, DNS and certificate settings.')
            try:
                with socket.create_connection(('127.0.0.1',socks),timeout=.1):break
            except OSError:time.sleep(.1)
        else:raise Failure('Hysteria QUIC handshake timed out.')
        if not egress:return
        for url in ('https://www.example.com/','https://www.wikipedia.org/'):
            p=run(['curl','-fsS','--noproxy','','--proxy','socks5h://127.0.0.1:'+str(socks),
                '--connect-timeout','5','--max-time','12','--output','/dev/null',url],timeout=15,check=False)
            if p.returncode==0:return
    raise Failure('Hysteria authenticated, but neither HTTPS egress test succeeded.')

def hy_health(path,wait=10):
    s=hy_validate(json.loads((path/'state.json').read_text()));deadline=time.monotonic()+wait;progress=time.monotonic()+15
    with tempfile.TemporaryDirectory(prefix='hy2-check-') as td:
        for variant in hy_variants(s):
            while True:
                try:
                    if not hy_active():raise Failure('Hysteria service is not active.')
                    hy_probe(path/'hysteria',variant,loopback(s['server_ip']),td,egress=False);break
                except Failure:
                    if time.monotonic()>=deadline:raise
                    if time.monotonic()>=progress:
                        say('Still waiting for Hysteria TLS/authentication; '+str(max(0,int(deadline-time.monotonic())))+' seconds remain ...');progress=time.monotonic()+15
                    time.sleep(1)
            say('PASS TLS/authentication: '+variant.get('domain',s['server_ip']))
        hy_probe(path/'hysteria',s,loopback(s['server_ip']),td)
    say('PASS Hysteria 2: authenticated QUIC + verified certificate/pin + HTTPS egress, tested locally.')
    say('Public UDP reachability and your ISP must still be tested from a client.')

def hy_certificate(ip,work):
    cert=pathlib.Path(work)/'new.crt';key=pathlib.Path(work)/'new.key'
    run(['openssl','req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:prime256v1',
        '-sha256','-nodes','-days','825','-subj','/CN=Hysteria2',
        '-addext','subjectAltName=IP:'+ip,'-keyout',key,'-out',cert])
    fp=run(['openssl','x509','-in',cert,'-noout','-fingerprint','-sha256']).stdout.strip().split('=',1)[1].replace(':','').lower()
    return {'certificate':cert.read_text(),'private_key':key.read_text(),'pin':fp}

def hy_download(work,version=None):
    arch={'x86_64':'amd64','aarch64':'arm64'}.get(platform.machine())
    if not arch:raise Failure('Hysteria supports x86_64 and aarch64 in this installer.')
    if version and not re.fullmatch(r'(?:app/)?v2\.\d+\.\d+',version):raise Failure('Use --hy2-version v2.x.y (stable only).')
    route='tags/'+urllib.parse.quote(version if version.startswith('app/') else 'app/'+version,safe='') if version else 'latest'
    release=json.loads(curl('https://api.github.com/repos/HyNetworks/hysteria/releases/'+route))
    tag=release.get('tag_name','')
    if release.get('draft') or release.get('prerelease') or not re.fullmatch(r'app/v2\.\d+\.\d+',tag):
        raise Failure('Only official stable Hysteria 2 releases are accepted.')
    asset=next((a for a in release.get('assets',[]) if a['name']=='hysteria-linux-'+arch),None)
    if not asset or not re.fullmatch(r'sha256:[0-9a-f]{64}',asset.get('digest') or ''):
        raise Failure('Official Hysteria asset SHA-256 digest is unavailable; download refused.')
    url=asset['browser_download_url']
    if not any(url.startswith('https://github.com/'+repo+'/releases/download/') for repo in ('HyNetworks/hysteria','apernet/hysteria')):
        raise Failure('Unexpected Hysteria download origin.')
    binary=pathlib.Path(work)/'hysteria';say('Downloading official Hysteria '+tag+'; verifying SHA-256 ...')
    curl(url,binary)
    if 'sha256:'+hashlib.sha256(binary.read_bytes()).hexdigest()!=asset['digest']:raise Failure('Hysteria SHA-256 mismatch.')
    binary.chmod(0o700);run([binary,'version'],timeout=10)
    return binary,tag

def hy_dns_check(domain,ip):
    # Run DNS in a bounded subprocess; a broken resolver must not hang the manager.
    code='import socket,json,sys; print(json.dumps(sorted({x[4][0] for x in socket.getaddrinfo(sys.argv[1],443,type=socket.SOCK_DGRAM)})))'
    p=run([sys.executable,'-c',code,domain],timeout=15,check=False)
    if p.returncode:raise Failure('DNS lookup failed. Create a DNS-only A/AAAA record for '+domain+' pointing to '+ip+'.')
    resolved=set(json.loads(p.stdout))
    # A single endpoint is intentional: stale AAAA records otherwise create intermittent failures.
    if resolved!={ip}:raise Failure('DNS must resolve only to '+ip+' for this one-server profile. Found '+', '.join(sorted(resolved))+'. Disable Cloudflare proxy and remove stale A/AAAA records.')

def hy_token(path=None):
    if path:
        p=pathlib.Path(path)
        if p.is_symlink() or not p.is_file() or p.stat().st_uid!=0 or p.stat().st_mode&0o077:
            raise Failure('Token file must be a regular root-owned file with mode 600 or 400.')
        if p.stat().st_size>1024:raise Failure('Token file is too large.')
        token=p.read_text().strip()
    else:
        token=ask('Cloudflare API token (hidden; enter on this server only; q=cancel): ',secret=True)
        if token.lower() in ('q','cancel'):raise Cancelled()
    if not re.fullmatch(r'[A-Za-z0-9_-]{20,256}',token):raise Failure('Invalid Cloudflare API token format.')
    return token

def hy_needed_rules(s):
    return {str(v['port'])+'/udp' for v in hy_variants(s)}|({'80/tcp'} if s['mode']=='http' else set())

def hy_firewall(s,disabled=False,allow_inactive=False):
    if disabled or not shutil.which('ufw'):return
    if not allow_inactive and 'Status: active' not in run(['ufw','status']).stdout:return
    meta=receipt_data(create=True);tag=meta['ufw_tag']+'-hy2';rules=ufw_rules()
    for spec in sorted(hy_needed_rules(s)):
        expected=['ufw','allow',spec,'comment',tag]
        if expected in rules:continue
        if any('allow' in r and (spec in r or spec.split('/')[0] in r) for r in rules):
            say('Existing UFW rule retained for '+spec+'; verify source/family coverage.');continue
        owned=meta.setdefault('hy_ufw_rules',[])
        if spec not in owned:owned.append(spec);write_json(RECEIPT,meta)
        run(['ufw','allow',spec,'comment',tag]);rules=ufw_rules()

def hy_remove_rules(keep=()):
    meta=receipt_data();owned=meta.get('hy_ufw_rules',[])
    if not owned:return
    if not shutil.which('ufw'):raise Failure('Cannot clean owned Hysteria rules without ufw.')
    for spec in owned[:]:
        if spec in keep:continue
        tag=meta['ufw_tag']+'-hy2';expected=['ufw','allow',spec,'comment',tag]
        if expected in ufw_rules():run(['ufw','--force','delete','allow',spec,'comment',tag])
        if expected in ufw_rules():raise Failure('Could not remove an owned Hysteria UFW rule.')
        owned.remove(spec);write_json(RECEIPT,meta)

# One ACME owner obtains/renews every domain; additional listeners read its
# certificates at each TLS handshake. No competing HTTP/80 challenge servers.
HY_LISTENER_RUNNER = r'''import json, pathlib, signal, subprocess, sys, time
base=pathlib.Path(__file__).resolve().parent
manifest=json.loads((base/'listeners.json').read_text())
children=[]
def stop(*args):
    raise SystemExit(0)
signal.signal(signal.SIGTERM,stop)
signal.signal(signal.SIGINT,stop)
def start(config):
    child=subprocess.Popen([str(base/'hysteria'),'server','--disable-update-check','--log-level','warn','-c',str(config)])
    children.append(child)
def check():
    if any(p.poll() is not None for p in children):
        raise RuntimeError('A Hysteria listener exited; restarting the managed group.')
try:
    start(base/'config.json')
    deadline=time.monotonic()+180
    cache=pathlib.Path(manifest['cache'])
    runtime=cache/'listeners'
    runtime.mkdir(mode=0o700,exist_ok=True)
    for item in manifest['listeners']:
        domain=item['domain']
        while True:
            check()
            matches=list((cache/'certificates').glob('*/'+domain+'/'+domain+'.crt'))
            pairs=[(c,c.with_suffix('.key')) for c in matches if c.is_file() and c.with_suffix('.key').is_file()]
            if len(pairs)==1:break
            if len(pairs)>1:raise RuntimeError('Ambiguous certificate cache for '+domain)
            if time.monotonic()>deadline:raise RuntimeError('Timed out waiting for certificate: '+domain)
            time.sleep(.25)
        cert,key=pairs[0]
        cfg=item['config'];cfg['tls']={'cert':str(cert),'key':str(key),'sniGuard':'strict'}
        path=runtime/(domain+'.json')
        path.write_text(json.dumps(cfg));path.chmod(0o600)
        start(path)
    while True:
        check();time.sleep(.5)
finally:
    for p in children:
        if p.poll() is None:p.terminate()
    for p in children:
        try:p.wait(timeout=4)
        except subprocess.TimeoutExpired:p.kill();p.wait()
'''

def hy_write_listeners(s,release,gid):
    if not s.get('domain_ports') or len(hy_domains(s))<2:return
    listeners=[]
    for variant in hy_variants(s)[1:]:
        cfg=hy_config(variant,release);cfg.pop('acme',None)
        listeners.append({'domain':variant['domain'],'config':cfg})
    write_json(release/'listeners.json',{'cache':str(HY_CACHE),'listeners':listeners},0o640)
    atomic_text(release/'listeners.py',HY_LISTENER_RUNNER,0o640)
    for name in ('listeners.json','listeners.py'):os.chown(release/name,0,gid)

def hy_unit_text():
    launcher=(f'/usr/bin/python3 {HY_CURRENT}/listeners.py' if (HY_CURRENT/'listeners.py').exists() else f'{HY_CURRENT}/hysteria server --disable-update-check --log-level warn -c {HY_CURRENT}/config.json')
    return f'''# {OWNER} Hysteria
[Unit]
Description=Managed Hysteria 2 server
After=network.target
StartLimitIntervalSec=120
StartLimitBurst=5
[Service]
User={HY_USER}
Group={HY_USER}
ExecStart={launcher}
WorkingDirectory={HY_CACHE}
StandardInput=null
Restart=on-failure
RestartSec=5
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths={HY_CACHE}
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
AmbientCapabilities=CAP_NET_BIND_SERVICE
LimitNOFILE=65536
[Install]
WantedBy=multi-user.target
'''

def hy_prepare():
    import pwd,grp
    meta=receipt_data(create=True)
    if run(['getent','passwd',HY_USER],check=False).returncode==0:
        if not meta.get('hy_user_created'):raise Failure('Dedicated Hysteria user already exists outside this manager.')
    else:
        if run(['getent','group',HY_USER],check=False).returncode==0:raise Failure('Hysteria group already exists outside this manager.')
        run(['useradd','--system','--user-group','--home-dir',HY_CACHE,'--no-create-home','--shell','/usr/sbin/nologin',HY_USER])
        meta['hy_user_created']=True;write_json(RECEIPT,meta)
    account=pwd.getpwnam(HY_USER);gid=grp.getgrnam(HY_USER).gr_gid
    if account.pw_uid==0 or account.pw_shell not in ('/usr/sbin/nologin','/sbin/nologin','/bin/false'):
        raise Failure('Dedicated Hysteria account has unsafe privileges.')
    HY_ROOT.mkdir(mode=0o750,parents=True,exist_ok=True)
    atomic_text(HY_MARKER,OWNER)
    (HY_ROOT/'releases').mkdir(mode=0o750,exist_ok=True)
    for p in (HY_ROOT,HY_ROOT/'releases'):p.chmod(0o750);os.chown(p,0,gid)
    if not HY_CACHE.exists():
        # Receipt is written before directory creation so interrupted setup is recoverable.
        meta['hy_cache_owned']=True;write_json(RECEIPT,meta);HY_CACHE.mkdir(mode=0o700)
    os.chown(HY_CACHE,account.pw_uid,gid);HY_CACHE.chmod(0o700)
    return gid

def hy_free_listener(s,old=None):
    owned={v['port'] for v in hy_variants(old)} if old and old['server_ip']==s['server_ip'] and hy_active() else set()
    for variant in hy_variants(s):
        if variant['port'] in owned:continue
        try:
            with socket.socket(family(s['server_ip']),socket.SOCK_DGRAM) as sock:
                sock.bind(('::' if ':' in s['server_ip'] else '0.0.0.0',variant['port']))
        except OSError:raise Failure('UDP/'+str(variant['port'])+' is occupied; no service was replaced.')
    if s['mode']=='http':
        # Certmagic holds TCP/80 only during challenges; permit only our own challenge process.
        busy=[r for r in listener_rows() if r['proto']=='tcp' and r['port']==80]
        if busy:raise Failure('TCP/80 is occupied. Use Cloudflare DNS validation or retry after the current ACME challenge.')

def hy_preflight(binary,s,work):
    # Exercise the exact server options and credentials with a temporary certificate.
    probe=copy.deepcopy(s);probe['mode']='self-signed';probe['server_ip']='127.0.0.1'
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:sock.bind(('127.0.0.1',0));probe['port']=sock.getsockname()[1]
    probe.update(hy_certificate('127.0.0.1',work))
    p=pathlib.Path(work);atomic_text(p/'server.crt',probe['certificate']);atomic_text(p/'server.key',probe['private_key'])
    with hy_process(binary,'server',hy_config(probe,p),work,'hy-preflight') as proc:
        time.sleep(.2)
        if proc.poll() is not None:raise Failure('Hysteria staging configuration was rejected.')
        hy_probe(binary,probe,'127.0.0.1',work)

def hy_activate(release,should_start=True):
    old=HY_CURRENT.resolve() if HY_CURRENT.is_symlink() else None
    old_unit=HY_UNIT.read_bytes() if HY_UNIT.exists() else None
    was_active=hy_active();was_enabled=run(['systemctl','is-enabled','--quiet',HY_SERVICE],check=False).returncode==0
    try:
        swap_link(HY_CURRENT,release);atomic_text(HY_UNIT,hy_unit_text(),0o644)
        run(['systemctl','daemon-reload'])
        if should_start:
            run(['systemctl','restart',HY_SERVICE])
            say('Waiting for Hysteria authentication and certificate readiness (up to 3 minutes for ACME) ...')
            hy_health(release,wait=180)
        if old is None:run(['systemctl','enable',HY_SERVICE])
    except BaseException as error:
        try:state=json.loads((release/'state.json').read_text())
        except (OSError,ValueError):state={}
        remember_failure('Hysteria activation / certificate',error,state,journal=True)
        error.diagnostic_saved=True
        say('Hysteria activation failed; restoring previous service/configuration ...')
        run(['systemctl','stop',HY_SERVICE],check=False)
        if old:swap_link(HY_CURRENT,old)
        else:HY_CURRENT.unlink(missing_ok=True)
        if old_unit is None:HY_UNIT.unlink(missing_ok=True)
        else:atomic_text(HY_UNIT,old_unit.decode(),0o644)
        run(['systemctl','daemon-reload'],check=False)
        run(['systemctl','enable' if was_enabled else 'disable',HY_SERVICE],check=False)
        if was_active:
            p=run(['systemctl','start',HY_SERVICE],check=False)
            if p.returncode:say('Previous files restored; Hysteria service needs attention.')
        raise
    if old:swap_link(HY_PREVIOUS,old)

def hy_install(args):
    try:_hy_install(args)
    except Exception as error:
        if not isinstance(error,Cancelled) and not getattr(error,'diagnostic_saved',False):
            remember_failure('Hysteria installation/preflight',error)
            error.diagnostic_saved=True
        raise

def _hy_install(args):
    hy_guard()
    old=hy_state() if HY_CURRENT.exists() else None
    if args.command=='hy2-install' and old:
        say('Hysteria already installed; use hy2-edit or hy2-update.');promote_manager();hy_show_links();return
    if args.command in ('hy2-edit','hy2-update') and not old:raise Failure('Install Hysteria first.')
    saved=hy_validate(json.loads(HY_SAVED.read_text())) if not old and HY_SAVED.exists() else None
    s=copy.deepcopy(old or saved or {'schema':1,'protocol':'hysteria2','port':443,'mode':'self-signed',
        'obfs':'none','password':secrets.token_urlsafe(32),'obfs_password':secrets.token_urlsafe(32)})
    if args.server_ip or not s.get('server_ip'):s['server_ip']=public_ip(args.server_ip)
    for flag,key in (('hy2_port','port'),('hy2_mode','mode'),('hy2_domain','domain'),('hy2_email','email'),('hy2_obfs','obfs')):
        value=getattr(args,flag,None)
        if value is not None:s[key]=value
    if type(s['port']) is not int or not 1<=s['port']<=65535:raise Failure('UDP port must be in 1..65535.')
    with tempfile.TemporaryDirectory(prefix='hy2-install-') as td:
        work=pathlib.Path(td)
        if s['mode']=='self-signed':
            if getattr(args,'hy2_ports',None):raise Failure('--hy2-ports requires domain certificate mode.')
            if not s.get('certificate'):s.update(hy_certificate(s['server_ip'],work))
            for key in ('domain','domains','domain_ports','email','cf_token'):s.pop(key,None)
        else:
            if args.hy2_domain is not None:
                domains,rejected=parse_domain_list(args.hy2_domain)
                if rejected or not domains:raise Failure('Invalid domain list: '+('; '.join(item+': '+why for item,why in rejected) or 'list is empty'))
                s['domain']=domains[0];s['domains']=domains
            else:s['domain']=validate_domain(s.get('domain',''))
            for domain in hy_domains(s):
                say('Checking Hysteria DNS: '+domain+' (up to 15 seconds) ...')
                hy_dns_check(domain,s['server_ip'])
            if s['mode']=='cloudflare':
                if args.hy2_token_file or not s.get('cf_token'):s['cf_token']=hy_token(args.hy2_token_file)
            else:s.pop('cf_token',None)
            for key in ('certificate','private_key','pin'):s.pop(key,None)
        if s['mode']!='self-signed':
            mapping=getattr(args,'hy2_ports',None)
            if mapping:
                try:ports=[int(x) for x in mapping.split(',')]
                except ValueError:raise Failure('--hy2-ports requires comma-separated UDP port numbers.')
                if len(ports)!=len(hy_domains(s)):raise Failure('Provide one UDP port per domain, in the same order.')
                s['domain_ports']=dict(zip(hy_domains(s),ports));s['port']=ports[0]
            elif args.hy2_domain is not None or args.hy2_port is not None or not (old or saved):
                owned={v['port'] for v in hy_variants(old)} if old and hy_active() else set()
                previous=(old or saved or {}).get('domain_ports',{})
                chosen={};used=[]
                for i,domain in enumerate(hy_domains(s)):
                    preferred=s['port'] if i==0 else previous.get(domain,s['port']+i)
                    if preferred>65535:preferred=20000+i
                    port=preferred if i==0 or (preferred not in used and (preferred in owned or port_available(preferred,'udp',s['server_ip']))) else suggested_port('udp',s['server_ip'],preferred,used)
                    chosen[domain]=port;used.append(port)
                s['domain_ports']=chosen;s['port']=chosen[s['domain']]
            for variant in hy_variants(s):say('Hysteria '+variant['domain']+' -> UDP/'+str(variant['port']))
        say('Checking Hysteria configuration and UDP/ACME port availability ...')
        hy_validate(s);hy_free_listener(s,old)
        if args.command=='hy2-edit':binary=HY_CURRENT/'hysteria';version=s['version']
        else:binary,version=hy_download(work,args.hy2_version)
        say('Testing Hysteria locally: QUIC authentication, certificate pin and HTTPS egress ...')
        hy_preflight(binary,s,td);s['version']=version
        gid=hy_prepare();promote_manager()
        release=HY_ROOT/'releases'/(time.strftime('%Y%m%dT%H%M%S')+'-'+secrets.token_hex(3))
        release.mkdir(mode=0o750);release.chmod(0o750);os.chown(release,0,gid)
        old_rules=receipt_data().get('hy_ufw_rules',[])[:]
        try:
            shutil.copyfile(binary,release/'hysteria');(release/'hysteria').chmod(0o750);os.chown(release/'hysteria',0,gid)
            write_json(release/'state.json',s)
            if s['mode']=='self-signed':
                for filename,key in (('server.crt','certificate'),('server.key','private_key')):
                    atomic_text(release/filename,s[key],0o640);os.chown(release/filename,0,gid)
            write_json(release/'config.json',hy_config(s,release),0o640);os.chown(release/'config.json',0,gid)
            hy_write_listeners(s,release,gid)
            atomic_text(release/'links.txt',hy_links_text(s))
            # HTTP certificate issuance needs its firewall rule BEFORE service activation.
            hy_firewall(s,args.no_ufw)
            should_start=old is None or hy_active()
            hy_activate(release,should_start)
        except BaseException:
            hy_remove_rules(keep=old_rules)
            if not HY_CURRENT.is_symlink() or HY_CURRENT.resolve()!=release:shutil.rmtree(release)
            raise
        HY_SAVED.unlink(missing_ok=True)
        # Keep only the current and immediately previous release; old secrets/binaries do not accumulate.
        keep={HY_CURRENT.resolve(),HY_PREVIOUS.resolve()}
        for p in (HY_ROOT/'releases').iterdir():
            if p.is_dir() and not p.is_symlink() and p not in keep and re.fullmatch(r'\d{8}T\d{6}-[0-9a-f]{6}',p.name) and (p/'state.json').is_file():shutil.rmtree(p)
        say('Hysteria saved. Provider firewall/NAT must allow '+', '.join(sorted(hy_needed_rules(s)))+'.')
        if old:say('Password retained. Old owned firewall ports remain available for rollback until uninstall.')
        if not should_start:say('Service remains stopped; the staged configuration was tested. Start it to obtain/verify the live certificate.')
        hy_show_links()

def hy_rollback():
    hy_state()
    if not HY_PREVIOUS.is_symlink():raise Failure('No previous Hysteria release is available.')
    target=HY_PREVIOUS.resolve();s=hy_validate(json.loads((target/'state.json').read_text()))
    hy_firewall(s);hy_activate(target,hy_active());say('Hysteria rollback complete.');hy_show_links()

def hy_uninstall(args):
    hy_guard();confirm_uninstall(args)
    meta=receipt_data(create=True)
    if HY_CURRENT.is_symlink():write_json(HY_SAVED,hy_state())
    if HY_UNIT.exists():
        run(['systemctl','stop',HY_SERVICE])
        if hy_active():raise Failure('Hysteria did not stop; no files deleted.')
        run(['systemctl','disable',HY_SERVICE])
    hy_remove_rules()
    if HY_UNIT.exists():HY_UNIT.unlink();run(['systemctl','daemon-reload'])
    run(['systemctl','reset-failed',HY_SERVICE],check=False)
    if HY_ROOT.exists():shutil.rmtree(HY_ROOT)
    if args.purge:
        HY_SAVED.unlink(missing_ok=True)
        if HY_CACHE.exists() and meta.get('hy_cache_owned'):shutil.rmtree(HY_CACHE)
        if meta.get('hy_user_created') and run(['getent','passwd',HY_USER],check=False).returncode==0:
            run(['userdel',HY_USER])
            if run(['getent','group',HY_USER],check=False).returncode==0:run(['groupdel',HY_USER])
        meta=receipt_data()
        for key in ('hy_cache_owned','hy_user_created','hy_ufw_rules'):meta.pop(key,None)
        write_json(RECEIPT,meta)
        say('Hysteria purged, including password, token, certificates and ACME cache. REALITY and host protection retained.')
    else:say('Hysteria uninstalled. Credentials/certificates/ACME cache retained for hy2-install.')

def hy_status():
    if not HY_CURRENT.exists():say('Hysteria 2: not installed; saved credentials: '+('yes' if HY_SAVED.exists() else 'no'));return
    s=hy_state();say('Hysteria '+s['version']+' | '+('ACTIVE' if hy_active() else 'STOPPED'))
    say('Domains: '+', '.join(hy_domains(s)) if s['mode']!='self-signed' else 'Direct IP / pinned TLS')
    for v in hy_variants(s):say('Endpoint: '+hy_endpoint(v.get('domain') or v['server_ip'],v['port'])+' / UDP | TLS: '+v['mode']+' | Obfuscation: '+v['obfs'])

def hy_dispatch(args):
    c=args.command
    if c in ('hy2-install','hy2-edit','hy2-update'):hy_install(args)
    elif c=='hy2-links':hy_show_links(args.hy2_insecure)
    elif c=='hy2-status':hy_status()
    elif c=='hy2-uninstall':hy_uninstall(args)
    elif c=='hy2-rollback':hy_rollback()
    elif c=='hy2-check':hy_state();hy_health(HY_CURRENT)
    elif c=='hy2-logs':
        if not HY_CURRENT.exists():
            say('No active installation. The saved failure report is available below.');doctor();return
        s=hy_state();output=run(['journalctl','-u',HY_SERVICE,'-n','60','--no-pager']).stdout
        say(redact_diagnostic(output,s))
    elif c in ('hy2-start','hy2-stop','hy2-restart'):
        hy_state();run(['systemctl',c.removeprefix('hy2-'),HY_SERVICE])
        if c!='hy2-stop':hy_health(HY_CURRENT,wait=180)
        say(c+' OK')

def hy_menu():
    while True:
        try:
            hy_status()
            say('\n1) Install  2) Config link  3) Change UDP port  4) Certificate / domain')
            say('5) Obfuscation  6) Test  7) Start  8) Stop  9) Restart  10) Logs')
            say('11) Update Hysteria  12) Rollback  13) Uninstall  14) Purge  0) Back')
            choice=ask('Select Hysteria action: ')
            if choice=='0':return
            operations={'2':['hy2-links'],'6':['hy2-check'],'7':['hy2-start'],'8':['hy2-stop'],
                '9':['hy2-restart'],'10':['hy2-logs'],'11':['hy2-update'],'12':['hy2-rollback'],
                '13':['hy2-uninstall'],'14':['hy2-uninstall','--purge']}
            if choice in operations:command=operations[choice]
            elif choice=='3':
                state=hy_state()
                say('Domain order: '+', '.join(hy_domains(state)))
                command=['hy2-edit','--hy2-ports' if state['mode']!='self-signed' else '--hy2-port',ask('UDP port(s), comma-separated in domain order: ')]
            elif choice=='5':command=['hy2-edit','--hy2-obfs',ask('Obfuscation (none / salamander): ')]
            elif choice in ('1','4'):
                setup_wizard('hysteria',edit_hy=choice=='4');continue
            else:raise Failure('Invalid selection.')
            dispatch(parse_cli(command))
        except Cancelled:return
        except KeyboardInterrupt:say('\nCancelled.');return
        except (Failure,ValueError,subprocess.TimeoutExpired) as e:say('ERROR: '+str(e))
        except SystemExit:say('Invalid input.')


def security_state(create=False):
    receipt_data(create=create)
    for p in (SECURITY,FW_PENDING):
        if p.is_symlink():raise Failure('Security state must not be a symlink.')
    if SECURITY.exists():
        state=json.loads(SECURITY.read_text())
        if state.get('owner')!=OWNER:raise Failure('Unrecognized security state.')
        return state
    return {'owner':OWNER}

def atomic_text(path,text,mode=0o600):
    path=pathlib.Path(path)
    if path.is_symlink():raise Failure('Refusing a symlink: '+str(path))
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+'.tmp-'+secrets.token_hex(4))
    try:
        with temporary.open('x') as f:
            os.chmod(temporary,mode);f.write(text);f.flush();os.fsync(f.fileno())
        temporary.replace(path)
    finally:temporary.unlink(missing_ok=True)

def ensure_packages(packages):
    missing=[p for p in packages if run(['dpkg-query','-W','-f=${Status}',p],check=False).stdout.strip()!='install ok installed']
    if missing:
        say('Installing Ubuntu packages: '+', '.join(missing))
        run(['apt-get','update','-qq'],timeout=600)
        run(['apt-get','install','-y','--no-install-recommends']+missing,timeout=600,
            env={**os.environ,'DEBIAN_FRONTEND':'noninteractive'})

def ssh_connection():
    fields=os.environ.get('SSH_CONNECTION','').split()
    if len(fields)!=4:return None
    try:
        ipaddress.ip_address(fields[0]);ipaddress.ip_address(fields[2])
        if not all(0<int(fields[i])<65536 for i in (1,3)):return None
    except ValueError:return None
    return fields

def listener_rows():
    rows=[]
    for line in run(['ss','-H','-lntup']).stdout.splitlines():
        fields=line.split(None,6)
        if len(fields)<6 or fields[0] not in ('tcp','udp'):
            raise Failure('Cannot safely interpret active listeners: '+line[:160])
        address,sep,port=fields[4].rpartition(':')
        if not sep or not port.isdigit():raise Failure('Cannot identify listener port.')
        address=address.strip('[]').split('%',1)[0]
        try:local=ipaddress.ip_address(address).is_loopback
        except ValueError:local=False
        rows.append({'proto':fields[0],'port':int(port),'local':local,
                     'address':address,'process':fields[6] if len(fields)>6 else ''})
    return rows

def ssh_ports(rows=None):
    rows=listener_rows() if rows is None else rows
    ports={r['port'] for r in rows if r['proto']=='tcp' and '"sshd"' in r['process']}
    info=run(['systemctl','show','ssh.socket','-p','Listen','--value'],check=False).stdout
    ports.update(int(p) for p in re.findall(r':(\d+)\s+\(Stream\)',info))
    if shutil.which('sshd'):
        result=run(['sshd','-T'],check=False)
        ports.update(int(p) for p in re.findall(r'^port (\d+)$',result.stdout,re.M))
    connection=ssh_connection()
    if connection:ports.add(int(connection[3]))
    if not ports or any(not 1<=p<=65535 for p in ports):
        raise Failure('SSH ports could not be detected; firewall and SSH protection were not changed.')
    return sorted(ports)

def port_rules(value):
    if not value:return set()
    result=set()
    for item in value.split(','):
        match=re.fullmatch(r'(\d{1,5})/(tcp|udp)',item.strip())
        if not match or not 1<=int(match[1])<=65535:
            raise Failure('Use explicit port/protocol pairs, for example --allow-ports 80/tcp,443/tcp.')
        result.add((int(match[1]),match[2]))
    return result

def firewall_conflicts():
    conflicts=[]
    for service in ('firewalld','nftables','docker','podman','kubelet','libvirtd','netfilter-persistent'):
        if run(['systemctl','is-active','--quiet',service],check=False).returncode==0:conflicts.append(service)
    if shutil.which('nft'):
        p=run(['nft','list','tables'],check=False)
        if p.returncode:conflicts.append('unreadable nftables rules')
        elif p.stdout.strip():conflicts.append('existing nftables tables')
    for binary in ('iptables-save','ip6tables-save'):
        if shutil.which(binary):
            p=run([binary],check=False)
            if p.returncode:conflicts.append('unreadable '+binary)
            elif re.search(r'^-A |^:\S+ (?:DROP|REJECT) ',p.stdout,re.M):conflicts.append('existing '+binary+' rules')
    return sorted(set(conflicts))

def native_firewall_active():
    return any(run(['systemctl','is-active','--quiet',s],check=False).returncode==0
               for s in ('firewalld','nftables'))

def firewall_timer_cleanup():
    run(['systemctl','disable','--now',FW_TIMER.name],check=False)
    for path in (FW_TIMER,FW_SERVICE):
        if path.is_symlink():raise Failure('Unexpected firewall timer symlink.')
        if path.exists():
            if '# '+OWNER not in path.read_text():raise Failure('Firewall rollback unit is not owned.')
            path.unlink()
    run(['systemctl','daemon-reload'])

def firewall_rollback():
    security_state()
    if not FW_PENDING.exists():say('No pending firewall activation.');return
    saved=json.loads(FW_PENDING.read_text())
    if saved.get('owner')!=OWNER:raise Failure('Unrecognized firewall recovery record.')
    # This recovery operation only exists for an initially INACTIVE firewall.
    run(['ufw','--force','disable'])
    for path,entry in zip(FW_FILES,saved['files']):
        if path.is_symlink():raise Failure('Cannot restore over a symlink: '+str(path))
        if entry is None:path.unlink(missing_ok=True)
        else:
            content=base64.b64decode(entry['data'],validate=True).decode()
            atomic_text(path,content,entry['mode'])
    meta=receipt_data(create=True);meta['ufw_ports']=saved['ufw_ports']
    if saved.get('hy_ufw_rules') is None:meta.pop('hy_ufw_rules',None)
    else:meta['hy_ufw_rules']=saved['hy_ufw_rules']
    write_json(RECEIPT,meta)
    firewall_timer_cleanup();FW_PENDING.unlink()
    say('Firewall activation rolled back; original UFW configuration and inactive state restored.')

def firewall_setup(args):
    reality_state=load_state() if CURRENT.exists() or not HY_CURRENT.exists() else {'nodes':[]}
    if HY_CURRENT.exists():hy_state()
    meta=receipt_data(create=True)
    if FW_PENDING.exists():raise Failure('A firewall activation is pending; confirm it or run firewall-rollback.')
    extra=port_rules(args.allow_ports)
    ensure_packages(['ufw'])
    status=run(['ufw','status']).stdout
    if 'Status: active' in status:
        add_firewall_rules([n for n in reality_state['nodes'] if is_enabled(n)])
        if HY_CURRENT.exists():hy_firewall(hy_state())
        say('UFW was already active. Existing policies, SSH rules and other services were preserved.')
        if extra:say('--allow-ports applies only to first activation; manage additional services with ufw.')
        say(run(['ufw','status','verbose']).stdout);return
    if 'Status: inactive' not in status:raise Failure('Cannot determine UFW state.')
    conflicts=firewall_conflicts()
    if conflicts:raise Failure('Automatic firewall activation stopped: '+', '.join(conflicts)+'. Keep the existing firewall manager.')
    if ufw_rules():raise Failure('Inactive UFW already has user rules. Review and enable it manually; no rules were reset.')
    rows=listener_rows();ports=ssh_ports(rows)
    nodes=[n for n in reality_state['nodes'] if is_enabled(n)]
    hy_rules=hy_needed_rules(hy_state()) if HY_CURRENT.exists() else set()
    hy_allowed={(int(spec.split('/')[0]),spec.split('/')[1]) for spec in hy_rules}
    allowed={(p,'tcp') for p in ports}|{(n['port'],'tcp') for n in nodes}|extra|hy_allowed
    unknown={(r['port'],r['proto']) for r in rows if not r['local'] and
        (r['port'],r['proto']) not in allowed and (r['port'],r['proto']) not in {(68,'udp'),(546,'udp')}}
    if unknown:
        listing=','.join(str(p)+'/'+proto for p,proto in sorted(unknown))
        raise Failure('Other listeners need review: '+listing+'. If these services must remain public, repeat with --allow-ports '+listing)
    for path in (*FW_FILES,FW_SERVICE,FW_TIMER):
        if path.is_symlink():raise Failure('Unexpected firewall configuration symlink: '+str(path))
    if FW_SERVICE.exists() or FW_TIMER.exists():raise Failure('Rollback units already exist; inspect them before retrying.')
    promote_manager()
    saved={'owner':OWNER,'token':secrets.token_hex(8),'connection':ssh_connection(),
        'protect_after_confirm':bool(getattr(args,'secure',False)),
        'deadline':time.time()+180,'ufw_ports':meta['ufw_ports'][:],
        'hy_ufw_rules':copy.deepcopy(meta.get('hy_ufw_rules')),
        'files':[{'data':base64.b64encode(p.read_bytes()).decode(),'mode':p.stat().st_mode&0o777}
                 if p.exists() else None for p in FW_FILES]}
    # Persist recovery and start a boot-enabled watchdog BEFORE any policy change.
    write_json(FW_PENDING,saved)
    try:
        atomic_text(FW_SERVICE,f'''# {OWNER}
[Unit]
Description=Roll back unconfirmed REALITY firewall activation
After=ufw.service
[Service]
Type=oneshot
ExecStart={MANAGER} firewall-rollback
Restart=on-failure
RestartSec=10
''',0o644)
        atomic_text(FW_TIMER,f'''# {OWNER}
[Unit]
Description=REALITY firewall confirmation deadline
[Timer]
OnActiveSec=180s
AccuracySec=1s
Unit={FW_SERVICE.name}
[Install]
WantedBy=timers.target
''',0o644)
        run(['systemctl','daemon-reload']);run(['systemctl','enable','--now',FW_TIMER.name])
        run(['systemctl','is-active','--quiet',FW_TIMER.name])
        default=FW_FILES[0].read_text()
        if not re.search(r'^IPV6=',default,re.M):raise Failure('Missing UFW IPv6 setting.')
        atomic_text(FW_FILES[0],re.sub(r'^IPV6=.*$', 'IPV6=yes',default,flags=re.M),0o644)
        run(['ufw','default','deny','incoming']);run(['ufw','default','allow','outgoing'])
        for port in ports:run(['ufw','allow',str(port)+'/tcp','comment',meta['ufw_tag']+'-ssh'])
        for port,proto in sorted(extra):run(['ufw','allow',str(port)+'/'+proto,'comment',meta['ufw_tag']+'-extra'])
        for node in nodes:
            port=node['port']
            if port not in meta['ufw_ports']:meta['ufw_ports'].append(port)
            write_json(RECEIPT,meta)
            run(['ufw','allow',str(port)+'/tcp','comment',meta['ufw_tag']])
        if HY_CURRENT.exists():hy_firewall(hy_state(),allow_inactive=True)
        run(['ufw','--force','enable'])
        if 'Status: active' not in run(['ufw','status']).stdout:raise Failure('UFW did not become active.')
    except BaseException:
        say('Firewall setup failed; rolling back ...');firewall_rollback();raise
    say('UFW ACTIVE, PENDING CONFIRMATION. SSH TCP ports: '+','.join(map(str,ports)))
    say('Within 3 minutes, open a NEW SSH connection and run:')
    say('sudo --preserve-env=SSH_CONNECTION reality-manager firewall-confirm --token '+saved['token'])
    say('Without confirmation UFW returns to its previous inactive state. Keep this session open.')
    say('Do not edit UFW rules while this activation is pending. Provider firewall/NAT must also allow the ports.')
    if saved['protect_after_confirm']:say('SSH brute-force protection will be installed after successful firewall confirmation.')

def firewall_confirm(args):
    security_state()
    if not FW_PENDING.exists():raise Failure('No pending firewall activation.')
    saved=json.loads(FW_PENDING.read_text())
    if saved.get('owner')!=OWNER or not secrets.compare_digest(args.token or '',saved['token']):
        raise Failure('Wrong firewall confirmation token.')
    if time.time()>=saved['deadline']:
        firewall_rollback();raise Failure('Confirmation expired; firewall was rolled back.')
    current=ssh_connection()
    if not args.console and (not current or current==saved['connection']):
        raise Failure('Reconnect using a NEW SSH TCP connection, preserve SSH_CONNECTION, then confirm. Provider console: add --console.')
    if 'Status: active' not in run(['ufw','status']).stdout:raise Failure('UFW is not active.')
    firewall_timer_cleanup();FW_PENDING.unlink()
    say('Firewall confirmed. SSH and declared services are allowed; other incoming traffic is denied.')
    if saved.get('protect_after_confirm'):ssh_protect()

def ssh_protect():
    state=security_state(create=True);ports=ssh_ports()
    if native_firewall_active():raise Failure('A native nftables/firewalld service is active. Configure Fail2ban using that firewall manager.')
    if len(ports)>15:raise Failure('Too many SSH ports for the managed multiport action; configure Fail2ban manually.')
    managed=state.get('fail2ban')
    previously_installed=run(['dpkg-query','-W','-f=${Status}','fail2ban'],check=False).stdout.strip()=='install ok installed'
    before_running=run(['systemctl','is-active','--quiet','fail2ban'],check=False).returncode==0
    before_enabled=run(['systemctl','is-enabled','--quiet','fail2ban'],check=False).returncode==0
    fresh=not previously_installed and not managed
    if fresh and F2B_JAIL.parent.parent.exists():
        raise Failure('Fail2ban is not installed but old configuration exists. Review it before enabling protection.')
    ensure_packages(['fail2ban','python3-systemd','iptables'])
    if F2B_JAIL.is_symlink():raise Failure('Fail2ban jail path is a symlink.')
    if F2B_JAIL.exists() and (not managed or F2B_JAIL.read_text()!=managed['text']):
        raise Failure('Fail2ban jail was changed outside this manager; inspect it before overwriting.')
    running=run(['systemctl','is-active','--quiet','fail2ban'],check=False).returncode==0
    enabled=before_enabled
    if not fresh and not managed and running and run(['fail2ban-client','status','sshd'],check=False).returncode==0:
        say('An existing sshd Fail2ban jail is active. It was preserved; review its port coverage with security-check.');return
    connection=ssh_connection();ignore=['127.0.0.1/8','::1']
    if connection:ignore.append(str(ipaddress.ip_address(connection[0])))
    # Bans apply only to SSH ports; shared client NAT addresses are not banned from REALITY.
    content=f'''# {OWNER}
[reality-sshd]
enabled = true
filter = sshd
backend = systemd
port = {','.join(map(str,ports))}
protocol = tcp
banaction = iptables-multiport
usedns = no
maxretry = 5
findtime = 600
bantime = 1800
ignoreip = {' '.join(ignore)}
'''
    disable_stock=fresh or bool(managed and managed.get('disable_stock'))
    if disable_stock:
        # Ubuntu enables the stock sshd jail during package installation. Use one
        # journal-backed jail, including on images without /var/log/auth.log.
        content+='\n[sshd]\nenabled = false\n'
    old_text=F2B_JAIL.read_text() if F2B_JAIL.exists() else None
    previous=copy.deepcopy(state)
    state['fail2ban']={'text':content,'was_active':managed['was_active'] if managed else before_running,
        'was_enabled':managed['was_enabled'] if managed else enabled,'disable_stock':disable_stock}
    write_json(SECURITY,state)
    try:
        atomic_text(F2B_JAIL,content,0o644);run(['fail2ban-client','-t'])
        if running:
            run(['fail2ban-client','reload','reality-sshd'])
            if disable_stock and run(['fail2ban-client','status','sshd'],check=False).returncode==0:
                run(['fail2ban-client','stop','sshd'])
        else:run(['systemctl','start','fail2ban'])
        run(['systemctl','enable','fail2ban'])
        for attempt in range(15):
            p=run(['fail2ban-client','status','reality-sshd'],check=False)
            if p.returncode==0:break
            time.sleep(.2)
        else:raise Failure('The SSH protection jail did not start.')
    except BaseException:
        if old_text is None:F2B_JAIL.unlink(missing_ok=True)
        else:atomic_text(F2B_JAIL,old_text,0o644)
        if before_running:
            if managed:run(['fail2ban-client','reload','reality-sshd'],check=False)
            else:run(['fail2ban-client','stop','reality-sshd'],check=False)
        else:run(['systemctl','stop','fail2ban'],check=False)
        if not enabled:run(['systemctl','disable','fail2ban'],check=False)
        write_json(SECURITY,previous);raise
    promote_manager()
    say('SSH protection active: 5 failures / 10 minutes -> 30 minute SSH-only ban.')
    say('SSH TCP ports: '+','.join(map(str,ports))+'. SSH passwords, root login, keys and port settings were preserved.')
    if connection:say('Current administration IP is allowlisted: '+connection[0])

def ssh_unprotect():
    state=security_state();managed=state.get('fail2ban')
    if not managed:say('No SSH protection owned by this manager.');return
    if F2B_JAIL.is_symlink() or (F2B_JAIL.exists() and F2B_JAIL.read_text()!=managed['text']):
        raise Failure('Fail2ban jail has external changes; automatic removal stopped.')
    running=run(['systemctl','is-active','--quiet','fail2ban'],check=False).returncode==0
    if running and run(['fail2ban-client','status','reality-sshd'],check=False).returncode==0:
        run(['fail2ban-client','stop','reality-sshd'])
    F2B_JAIL.unlink(missing_ok=True)
    if running and not managed['was_active']:
        status=run(['fail2ban-client','status']).stdout
        if re.search(r'Number of jail:\s*0\b',status):
            run(['systemctl','stop','fail2ban'])
            if not managed['was_enabled']:run(['systemctl','disable','fail2ban'])
    state.pop('fail2ban');write_json(SECURITY,state)
    say('Managed SSH jail removed; other jails and installed packages were retained.')

def network_tune(bbr=False):
    state=security_state(create=True);managed=state.get('network')
    if SYSCTL_FILE.is_symlink() or (SYSCTL_FILE.exists() and (not managed or SYSCTL_FILE.read_text()!=managed['text'])):
        raise Failure('TCP settings file has external ownership or changes; refusing to overwrite it.')
    target={'net.ipv4.tcp_syncookies':'1','net.ipv4.tcp_mtu_probing':'1'}
    if bbr:
        available=run(['sysctl','-n','net.ipv4.tcp_available_congestion_control']).stdout.split()
        if 'bbr' not in available:
            run(['modprobe','tcp_bbr'],check=False)
            available=run(['sysctl','-n','net.ipv4.tcp_available_congestion_control']).stdout.split()
        if 'bbr' not in available:raise Failure('This kernel does not provide BBR. No TCP settings were changed.')
        target.update({'net.core.default_qdisc':'fq','net.ipv4.tcp_congestion_control':'bbr'})
    # Local administrator settings must not silently override our persistence after reboot.
    local_configs=[SYSCTL_FILE.parent.parent/'sysctl.conf']+list(SYSCTL_FILE.parent.glob('*.conf'))
    for path in local_configs:
        if path==SYSCTL_FILE or not path.is_file():continue
        for line in path.read_text(errors='replace').splitlines():
            match=re.match(r'\s*-?([\w./]+)\s*=\s*([^#;\s]+)',line)
            if match:
                key=match[1].replace('/','.')
                if key in target and match[2]!=target[key]:
                    raise Failure('Conflicting persistent TCP setting in '+str(path)+': '+key+'. Review it first.')
    values=copy.deepcopy(managed['values']) if managed else {}
    before={key:run(['sysctl','-n',key]).stdout.strip() for key in set(target)|set(values)}
    for key,entry in values.items():
        if before[key]!=entry['set']:raise Failure('External change detected for '+key+'; inspect before retuning.')
    for key,value in target.items():
        if key in ('net.ipv4.tcp_syncookies','net.ipv4.tcp_mtu_probing') and before[key]=='2':value='2'
        values[key]={'before':values.get(key,{}).get('before',before[key]),'set':value}
    content='# '+OWNER+'\n'+''.join(k+' = '+v['set']+'\n' for k,v in values.items())
    previous=copy.deepcopy(state);old_text=SYSCTL_FILE.read_text() if SYSCTL_FILE.exists() else None
    state['network']={'text':content,'values':values};write_json(SECURITY,state)
    try:
        atomic_text(SYSCTL_FILE,content,0o644)
        for key,entry in values.items():run(['sysctl','-w',key+'='+entry['set']])
    except BaseException:
        restored=True
        for key,value in before.items():
            if run(['sysctl','-w',key+'='+value],check=False).returncode:restored=False
        if old_text is None:SYSCTL_FILE.unlink(missing_ok=True)
        else:atomic_text(SYSCTL_FILE,old_text,0o644)
        if restored:write_json(SECURITY,previous)
        else:say('Some TCP values could not be restored; recovery data kept. Run network-restore.')
        raise
    promote_manager()
    say('TCP settings applied: SYN cookies and MTU black-hole probing. Defaults for buffers, UDP, IPv6 and forwarding were preserved.')
    if bbr:say('BBR enabled for new TCP connections. fq is the default for newly created queueing disciplines; existing interfaces were not reset. No speed increase is guaranteed.')

def network_restore():
    state=security_state();managed=state.get('network')
    if not managed:say('No TCP settings owned by this manager.');return
    if SYSCTL_FILE.is_symlink() or (SYSCTL_FILE.exists() and SYSCTL_FILE.read_text()!=managed['text']):
        raise Failure('TCP settings file has external changes; automatic restoration stopped.')
    # Removing our persistent file avoids reapplying old values after a reboot.
    SYSCTL_FILE.unlink(missing_ok=True)
    for key,entry in managed['values'].items():
        current=run(['sysctl','-n',key]).stdout.strip()
        if current==entry['set']:run(['sysctl','-w',key+'='+entry['before']])
        elif current!=entry['before']:say('External value retained: '+key+'='+current)
    state.pop('network');write_json(SECURITY,state)
    say('Previous TCP values restored where still managed. External changes were retained.')

def security_check():
    state=security_state()
    say('SECURITY AND NETWORK REPORT (read-only)')
    say('Kernel: '+platform.release())
    for command in (['ss','-s'],['ss','-H','-lntup'],['sysctl','net.ipv4.tcp_syncookies',
        'net.ipv4.tcp_mtu_probing','net.ipv4.tcp_congestion_control','net.core.default_qdisc'],
        ['timedatectl','show','-p','NTPSynchronized'],['systemctl','is-active','unattended-upgrades']):
        p=run(command,check=False);say('$ '+' '.join(command)+'\n'+(p.stdout or p.stderr).strip())
    if shutil.which('ufw'):say(run(['ufw','status','verbose'],check=False).stdout)
    else:say('UFW: not installed')
    try:say('Detected SSH TCP ports: '+','.join(map(str,ssh_ports())))
    except Failure as e:say(str(e))
    if shutil.which('sshd'):
        p=run(['sshd','-T'],check=False)
        say('SSH base settings (Match rules may override):\n'+'\n'.join(line for line in p.stdout.splitlines()
            if line.split(' ',1)[0] in ('passwordauthentication','permitrootlogin','pubkeyauthentication','maxauthtries')))
    if shutil.which('fail2ban-client'):say(run(['fail2ban-client','status'],check=False).stdout)
    if state.get('fail2ban'):say(run(['fail2ban-client','status','reality-sshd'],check=False).stdout)
    say('Managed TCP tuning: '+('yes' if state.get('network') else 'no'))
    if FW_PENDING.exists():say('FIREWALL CONFIRMATION PENDING: confirm from a new connection or it will be rolled back.')
    say('REALITY listens on TCP; tunneled UDP does not need a matching inbound UDP rule.')
    say('Hysteria 2 has its own UDP listener. TCP BBR/sysctl settings do not select its QUIC congestion controller.')
    if HY_CURRENT.exists():hy_status()
    say('Provider firewalls/NAT and external reachability are not tested by this report.')

def protect():
    ssh_protect();network_tune();say('Security setup completed; review the SSH coverage result above.')

def secure_install(args):
    network_tune()
    if args.no_ufw:
        ssh_protect();say('UFW setup skipped because --no-ufw was requested.');return
    try:firewall_setup(args)
    except Failure as e:
        raise Failure('Protocol service is installed; firewall setup stopped: '+str(e)+' Use the Security / network menu to continue.')
    if not FW_PENDING.exists():ssh_protect()

def security_remove():
    if FW_PENDING.exists():firewall_rollback()
    ssh_unprotect();network_restore()
    SECURITY.unlink(missing_ok=True)
    say('Security additions removed. Confirmed UFW, SSH/extra allow rules and Ubuntu packages were retained.')

def security_menu():
    while True:
        say('\nSECURITY / NETWORK')
        say('1) Audit / status        2) Enable SSH protection + safe TCP settings')
        say('3) Set up firewall      4) Confirm firewall from NEW connection')
        say('5) Roll back pending firewall   6) Disable managed SSH protection')
        say('7) Enable BBR (optional) 8) Restore previous TCP settings')
        say('9) Remove security additions   0) Back')
        choice=ask('Select security action: ')
        if choice=='0':return
        command={'1':['security-check'],'2':['protect'],'3':['firewall-setup'],
            '4':['firewall-confirm'],'5':['firewall-rollback'],'6':['ssh-unprotect'],
            '7':['network-tune','--bbr'],'8':['network-restore'],'9':['security-remove']}.get(choice)
        if not command:say('Invalid selection.');continue
        if choice=='3':
            extra=ask('Other public service ports (e.g. 80/tcp,443/tcp), blank for none: ')
            if extra:command+=['--allow-ports',extra]
        if choice=='4':command+=['--token',ask('Firewall confirmation token: ')]
        try:dispatch(parse_cli(command))
        except (Failure,ValueError,subprocess.TimeoutExpired) as e:say('ERROR: '+str(e))

class Cancelled(Exception):pass

def ask(prompt,secret=False):
    # Python source comes from stdin. All interactive input must use the controlling
    # terminal, including when this script was launched by a shell heredoc.
    # Read bytes without TextIO read-ahead; preserve queued answers and tty settings.
    import termios
    fd=None;before=None
    try:
        fd=os.open('/dev/tty',os.O_RDWR|os.O_NOCTTY)
        if os.tcgetpgrp(fd)!=os.getpgrp():
            raise Failure('Menu is not in the foreground. Run sudo reality-manager setup directly from a new SSH shell, outside any heredoc; or run it inside tmux.')
        before=termios.tcgetattr(fd);cooked=copy.deepcopy(before)
        cooked[0]=(cooked[0]|termios.ICRNL)&~(termios.IGNCR|termios.INLCR)
        cooked[3]|=termios.ICANON|termios.ECHO|termios.ISIG
        if secret:cooked[3]&=~termios.ECHO
        termios.tcsetattr(fd,termios.TCSANOW,cooked)
        os.write(fd,prompt.encode('utf-8'))
        answer=bytearray()
        while True:
            char=os.read(fd,1)
            if not char:raise Cancelled()
            if char==b'\n':break
            answer.extend(char)
            if len(answer)>4096:raise Failure('Input too long; enter one short answer.')
        if secret:os.write(fd,b'\n')
        return answer.decode('utf-8',errors='replace').strip()
    except OSError as e:
        raise Failure('Interactive setup needs an SSH terminal (ssh -t). Run: sudo reality-manager setup </dev/tty') from e
    finally:
        if fd is not None:
            try:
                if before is not None:termios.tcsetattr(fd,termios.TCSANOW,before)
            finally:os.close(fd)


def reality_menu():
    while True:
        say('')
        try:
            list_profiles(sys.stderr)
            say('\n1) Show config link     2) Change port       3) Change domain')
            say('4) Rename profile       5) Enable / disable  6) Test profile')
            say('7) Service / maintenance 8) Install REALITY  9) Security / network')
            say('10) Hysteria 2            0) Exit')
            choice=ask('Select action: ')
            if choice=='0':return
            if choice=='9':security_menu();continue
            if choice=='10':hy_menu();continue
            if choice=='8':setup_wizard('reality');continue
            if choice=='7':
                say('\n1) Status  2) Start  3) Stop  4) Restart  5) Logs')
                say('6) Update Xray  7) Reinstall  8) Rollback  9) Uninstall')
                say('10) Purge  11) Retry targets  0) Back')
                maintenance=ask('Select maintenance action: ')
                operations={'1':['status'],'2':['start'],'3':['stop'],'4':['restart'],'5':['logs'],
                    '6':['update'],'7':['reinstall'],'8':['rollback'],'9':['uninstall'],
                    '10':['uninstall','--purge'],'11':['reconfigure']}
                if maintenance=='0':continue
                if maintenance not in operations:raise Failure('Invalid selection.')
                dispatch(parse_cli(operations[maintenance]))
                if maintenance=='10':return
                continue
            if choice not in ('1','2','3','4','5','6'):raise Failure('Invalid selection.')
            selector=ask('Profile number, ID, or port (0 = back, all = show all links): ')
            if selector=='0':continue
            if choice=='1' and selector.casefold()=='all':dispatch(parse_cli(['links']));continue
            row=select_profile(load_state(),selector)
            say('Selected: '+row['label']+' | '+str(row['port'])+' | '+row['domain'])
            if choice=='1':command=['links','--profile',row['label']]
            elif choice=='6':command=['check','--profile',row['label']]
            elif choice=='5':
                flag=ask('Enter enable or disable (blank = cancel): ').lower()
                if not flag:continue
                if flag not in ('enable','disable'):raise Failure('Enter enable or disable.')
                command=[flag,'--profile',row['label']]
            else:
                option,prompt={'2':('--port','New TCP port (blank = cancel): '),
                    '3':('--domain','New domain/SNI, without https:// (blank = cancel): '),
                    '4':('--name','New English display name (blank = cancel): ')}[choice]
                value=ask(prompt)
                if not value:continue
                command=['edit','--profile',row['label'],option,value]
            dispatch(parse_cli(command))
            ask('Press Enter to return to the list ...')
        except Cancelled:return
        except KeyboardInterrupt:say('\nCancelled.');return
        except (Failure,ValueError,subprocess.TimeoutExpired) as e:say('ERROR: '+str(e))
        except SystemExit as e:
            if e.code==0:return
            say('Invalid input; no change was made.')

class Back(Exception):pass

def wizard_answer(prompt,default=None):
    suffix=(' ['+str(default)+']') if default is not None else ''
    value=ask(prompt+suffix+' (b=back, q=cancel): ')
    if value.casefold() in ('b','back'):raise Back()
    if value.casefold() in ('q','quit','cancel'):raise Cancelled()
    return str(default) if not value and default is not None else value

def port_available(port,proto,ip,exclude=()):
    if port in exclude:return False
    try:
        with socket.socket(family(ip),socket.SOCK_DGRAM if proto=='udp' else socket.SOCK_STREAM) as sock:
            sock.bind(('::' if ':' in ip else '0.0.0.0',port))
        return True
    except OSError:return False

def suggested_port(proto,ip,preferred=443,exclude=()):
    if port_available(preferred,proto,ip,exclude):return preferred
    for _ in range(100):
        port=10000+secrets.randbelow(50000)
        if port_available(port,proto,ip,exclude):return port
    raise Failure('No available '+proto.upper()+' port found. Inspect: ss -lntup')

def wizard_port(prompt,proto,ip,default,exclude=(),owned=None):
    value=wizard_answer(prompt,default)
    if value.casefold()=='r':return suggested_port(proto,ip,10000+secrets.randbelow(50000),exclude)
    try:port=int(value)
    except ValueError:raise Failure('Enter a port number, r for a random free port, b or q.')
    if not 1<=port<=65535:raise Failure('Port must be between 1 and 65535.')
    if port!=owned and not port_available(port,proto,ip,exclude):
        raise Failure(proto.upper()+' port '+str(port)+' is occupied or selected twice. Enter r for a free port.')
    return port

def explain_failure(error):
    text=str(error);lower=text.lower()
    say('ERROR: '+text)
    if any(x in lower for x in ('dns','resolve','lookup','nxdomain')):
        say('DNS: check the exact hostname and A/AAAA records. Hysteria needs your own DNS-only domain pointing ONLY to this endpoint. Retry after propagation; remove stale records. REALITY targets remain pointed at their original sites.')
    if any(x in lower for x in ('acme','certificate','tls','quic','hysteria service','challenge')):
        say('TLS/ACME: domain mode needs DNS-only records; HTTP validation needs free, public TCP/80 (also at the provider). Check server time, CAA and CA rate limits. If TCP/80 is busy, choose Cloudflare DNS validation. Do not repeatedly request certificates after a rate limit.')
    if any(x in lower for x in ('quic','timed out','timeout','egress','tunnel')):
        say('Network: check server DNS/outbound HTTPS and local firewall. Hysteria requires inbound UDP; REALITY requires inbound TCP. A local pass cannot prove provider/ISP reachability. Test from a separate client.')
    if any(x in lower for x in ('occupied','address already','bind')):
        say('Port: run ss -lntup; choose another free port. This manager will not stop unrelated services. TCP and UDP may use the same number.')
    if any(x in lower for x in ('401','403','token','unauthorized')):
        say('Cloudflare: use a scoped API token for the correct zone with Zone:DNS:Edit and Zone:Zone:Read. Enter it only in the hidden server prompt, never in chat.')
    if any(x in lower for x in ('sha-256','sha256','checksum')):
        say('Download integrity failed. No unchecked core will run. Retry the official download; never bypass checksum verification.')
    say('Read-only troubleshooting: sudo reality-manager doctor')

def redact_diagnostic(text,state=None):
    for key in ('password','obfs_password','cf_token','private_key','certificate','uuid','short_id'):
        value=(state or {}).get(key)
        if isinstance(value,str) and value:text=text.replace(value,'[redacted]')
    text=re.sub(r'(?:vless|hysteria2|hy2)://[^\s]+','[config link redacted]',text)
    return re.sub(r'-----BEGIN [^-]*PRIVATE KEY-----.*?-----END [^-]*PRIVATE KEY-----','[private key redacted]',text,flags=re.S)

def remember_failure(stage,error,state=None,journal=False):
    # Kept across failed first deployment/rollback; diagnostics are root-only.
    try:
        receipt_data(create=True)
        details=str(error)
        if journal:
            details+='\n'+run(['journalctl','-u',HY_SERVICE,'-n','45','--no-pager','--since','10 minutes ago'],check=False,timeout=10).stdout
        details=redact_diagnostic(details,state)[-12000:]
        write_json(DATA/'last-failure.json',{'time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'stage':stage,'details':details})
        say('Failure details saved: sudo reality-manager doctor')
    except Exception:say('Could not save the failure report; keep the terminal error above.')

def doctor():
    say('READ-ONLY DIAGNOSTICS — no services or firewall settings will be changed.')
    try:
        receipt_data()
        report=DATA/'last-failure.json'
        if report.is_symlink():raise Failure('Unexpected diagnostic report symlink.')
        if report.exists():
            d=json.loads(report.read_text());say('LAST FAILURE (historical): '+d['time_utc']+' | '+d['stage']);explain_failure(d['details'])
    except (Failure,ValueError,OSError) as e:say('State report: '+str(e))
    jobs=[]
    if CURRENT.exists():
        def reality_check():
            s=load_state();say('REALITY '+s['version']+' | '+('ACTIVE' if active() else 'STOPPED'))
            say('Expected provider TCP ports: '+','.join(str(n['port']) for n in s['nodes'] if is_enabled(n)))
            if active():health(CURRENT)
            else:say('Start only when ready: sudo reality-manager start')
        jobs.append(('REALITY',reality_check))
    else:say('REALITY: not installed.')
    if HY_CURRENT.exists():
        def hysteria_check():
            s=hy_state();hy_status();say('Expected provider rules: '+', '.join(sorted(hy_needed_rules(s))))
            for domain in hy_domains(s):
                say('Checking Hysteria DNS: '+domain+' ...');hy_dns_check(domain,s['server_ip'])
            if hy_active():hy_health(HY_CURRENT)
            else:say('Start only when ready: sudo reality-manager hy2-start')
        jobs.append(('Hysteria',hysteria_check))
    else:say('Hysteria: not installed. A failed first activation may still have the report above.')
    jobs.append(('Security / firewall',security_check))
    for label,check in jobs:
        say('Checking '+label+' ...')
        try:check()
        except (Failure,ValueError,OSError,subprocess.TimeoutExpired) as e:explain_failure(e)
    say('Listening sockets:\n'+run(['ss','-lntup'],check=False).stdout)
    say('Clock:\n'+run(['timedatectl','show','-p','NTPSynchronized','-p','TimeUSec'],check=False).stdout)
    say('External provider firewall, NAT and Iranian ISP paths cannot be verified from this server alone.')

def ask_hy_domains(ip,default=None):
    say('Enter one hostname, a comma/space-separated list, or type list for multiline paste (max 10).')
    raw=wizard_answer('Your Hysteria domain(s)',default)
    if raw.casefold()=='list':
        say('Paste one or more hostnames per line. End with a single dot on its own line. b=back, q=cancel.')
        lines=[];size=0
        while True:
            line=wizard_answer('domain list >')
            if line=='.':break
            size+=len(line)+1
            if size>16384:raise Failure('Domain list is too large.')
            lines.append(line)
        raw='\n'.join(lines)
    domains,rejected=parse_domain_list(raw)
    accepted=[]
    for item,reason in rejected:say('REJECT '+item+': '+reason)
    for i,domain in enumerate(domains,1):
        say('['+str(i)+'/'+str(len(domains))+'] Checking DNS: '+domain+' (up to 15 seconds) ...')
        try:hy_dns_check(domain,ip);accepted.append(domain);say('PASS '+domain)
        except (Failure,subprocess.TimeoutExpired) as e:rejected.append((domain,str(e)));say('REJECT '+domain+': '+str(e))
    if not accepted:raise Failure('No usable domains. Correct the list/DNS and retry, or b to change certificate method.')
    say('Accepted '+str(len(accepted))+': '+', '.join(accepted))
    if rejected:
        say('Rejected '+str(len(rejected))+' entries. They will not be configured or exported.')
        answer=wizard_answer('Continue with only the accepted domains? y=yes, n=re-enter','n').lower()
        if answer not in ('y','yes'):raise Failure('Re-enter the corrected list; no domain changes were applied.')
    return accepted

def setup_wizard(only=None,edit_hy=False):
    old_reality=load_state() if CURRENT.exists() else None
    old_hy=hy_state() if HY_CURRENT.exists() else None
    d={'scope':only or 'both','count':1,'mode':old_hy['mode'] if old_hy else 'http','security':'0'}
    if old_hy:d.update(hyport=old_hy['port'],domain=','.join(hy_domains(old_hy)))
    index=0
    say('\nGUIDED SETUP 1.7 | Enter accepts defaults. b = back. q = cancel.')
    say('Settings are collected and checked before installation. Existing protocols are preserved.')
    while True:
        want_r=d['scope'] in ('both','reality')
        want_h=d['scope'] in ('both','hysteria')
        new_r=want_r and not old_reality
        configure_h=want_h and (not old_hy or edit_hy)
        steps=([] if only else ['scope'])+['ip']
        if new_r:
            steps+=['count']
            for i in range(d['count']):steps+=['rp'+str(i),'rd'+str(i)]
        if configure_h:
            steps+=['hymode']
            if d['mode']!='self-signed':steps+=['hydomain']
            steps+=['hp'+str(i) for i in range(len(d.get('domain','').split(',')))] if d['mode']!='self-signed' else ['hyport']
        steps+=['security','review']
        index=min(index,len(steps)-1);step=steps[index]
        try:
            if step=='scope':
                say('\n1) Both REALITY + Hysteria 2 (recommended)  2) REALITY only  3) Hysteria 2 only')
                v=wizard_answer('Install protocols',{'both':'1','reality':'2','hysteria':'3'}[d['scope']])
                if v not in ('1','2','3'):raise Failure('Choose 1, 2 or 3.')
                d['scope']={'1':'both','2':'reality','3':'hysteria'}[v]
            elif step=='ip':
                if 'ip' not in d:
                    say('Detecting public endpoint (up to 36 seconds) ...')
                    try:d['ip']=(old_reality or old_hy or {}).get('server_ip') or public_ip(None)
                    except (Failure,subprocess.TimeoutExpired):say('Detection failed. Enter the public IP from your provider dashboard.')
                d['ip']=valid_ip(wizard_answer('Public server IP; confirm against provider dashboard',d.get('ip')))
            elif step=='count':
                v=wizard_answer('Number of REALITY profiles (1-4)',d['count'])
                if v not in ('1','2','3','4'):raise Failure('Choose 1, 2, 3 or 4 profiles.')
                d['count']=int(v)
            elif step.startswith('rp'):
                i=int(step[2:]);used=[d['rp'+str(j)] for j in range(i)]
                default=d.get(step) or suggested_port('tcp',d['ip'],443 if i==0 else 2025+i,used)
                d[step]=wizard_port('REALITY profile '+str(i+1)+' TCP port (r=random)','tcp',d['ip'],default,used)
            elif step.startswith('rd'):
                i=int(step[2:]);defaults=['www.google.com','chatgpt.com','www.microsoft.com','www.bing.com']
                say('Targets: www.google.com, chatgpt.com, www.bing.com, www.microsoft.com, or another TLS 1.3 / h2 site.')
                domain=validate_domain(wizard_answer('REALITY profile '+str(i+1)+' target hostname',d.get(step,defaults[i])))
                say('Checking target DNS, TLS 1.3, certificate and ALPN h2 (up to 30 seconds) ...')
                try:probe_target(domain)
                except (Failure,subprocess.TimeoutExpired):
                    say('Requested target failed; checking replacements ...')
                    for candidate in REALITY_FALLBACKS:
                        if candidate==domain:continue
                        try:probe_target(candidate);domain=candidate;break
                        except (Failure,subprocess.TimeoutExpired):continue
                    else:raise Failure('No candidate passed preliminary TLS checks. Check DNS/outbound HTTPS and retry.')
                d[step]=domain
                say('Selected '+domain+'. Authenticated tunnel and fallback are checked during installation.')
            elif step=='hymode':
                say('1) Own domain + automatic certificate (TCP/80 required; recommended)')
                say('2) Own domain + Cloudflare DNS token (no TCP/80 challenge)')
                say('3) Server IP + pinned self-signed certificate (client must support pinSHA256)')
                v=wizard_answer('Hysteria certificate method',{'http':'1','cloudflare':'2','self-signed':'3'}[d['mode']])
                if v not in ('1','2','3'):raise Failure('Choose 1, 2 or 3.')
                d['mode']={'1':'http','2':'cloudflare','3':'self-signed'}[v]
            elif step=='hydomain':
                say('Create a DNS-only A (IPv4) or AAAA (IPv6) record pointing to '+d['ip']+'. Disable Cloudflare proxy. No account login is needed for HTTP validation.')
                domains=ask_hy_domains(d['ip'],d.get('domain') or None)
                if d['mode']=='http':
                    if any(r['proto']=='tcp' and r['port']==80 for r in listener_rows()):raise Failure('TCP/80 is occupied. Go back and select Cloudflare DNS validation.')
                    if new_r and any(d['rp'+str(i)]==80 for i in range(d['count'])):raise Failure('REALITY TCP/80 conflicts with HTTP certificate validation. Go back and change the REALITY port, or select Cloudflare DNS validation.')
                d['domain']=','.join(domains);say('PASS DNS for '+str(len(domains))+' domains. Certificates are requested only after Apply; each hostname must pass its live TLS check.')
            elif step.startswith('hp'):
                i=int(step[2:]);domains=d['domain'].split(',');domain=domains[i]
                used=[d['hp'+str(j)] for j in range(i)]
                old_ports=(old_hy or {}).get('domain_ports',{})
                preferred=old_ports.get(domain,8443+i)
                owned=old_ports.get(domain) if old_hy and hy_active() and old_hy['server_ip']==d['ip'] else None
                default=d.get(step) or (owned if owned and owned not in used else suggested_port('udp',d['ip'],preferred,used))
                d[step]=wizard_port('Hysteria '+domain+' UDP port (r=random)','udp',d['ip'],default,used,owned=owned)
                if i==0:d['hyport']=d[step]
            elif step=='hyport':
                owned=old_hy['port'] if old_hy and hy_active() and old_hy['server_ip']==d['ip'] else None
                default=d.get('hyport') or suggested_port('udp',d['ip'])
                d['hyport']=wizard_port('Hysteria UDP port (r=random; may equal a REALITY TCP port)','udp',d['ip'],default,owned=owned)
            elif step=='security':
                say('0) Keep current firewall/security settings (owned protocol rules are added to active UFW)')
                say('1) Configure guarded UFW + SSH protection + safe TCP settings after installation')
                say('Option 1 may require confirmation from a NEW SSH session within 3 minutes; unrelated firewall layouts are not overwritten.')
                v=wizard_answer('Host protection',d['security'])
                if v not in ('0','1'):raise Failure('Choose 0 or 1.')
                d['security']=v
            elif step=='review':
                say('\nREVIEW | New endpoint: '+d['ip'])
                if want_r:
                    if old_reality:say('REALITY: preserve existing profiles, endpoint, credentials, core and service state. Use the REALITY menu to edit them.')
                    else:
                        for i in range(d['count']):say('REALITY '+str(i+1)+': TCP/'+str(d['rp'+str(i)])+' -> '+d['rd'+str(i)])
                if want_h:
                    if not configure_h:say('Hysteria: preserve existing endpoint, credentials, core and service state.')
                    else:
                        say('Hysteria: UDP/'+str(d['hyport'])+' | '+d['mode']+' | '+(d.get('domain') or d['ip'] if d['mode']!='self-signed' else d['ip']))
                        if d['mode']!='self-signed':
                            for i,domain in enumerate(d['domain'].split(',')):say('  '+domain+' -> UDP/'+str(d['hp'+str(i)]))
                        if d['mode']=='cloudflare':say('A hidden Cloudflare token prompt follows only if a token is needed.')
                        if d['mode']=='http':say('Allow public TCP/80 for automatic certificate issuance and renewal.')
                        if d['mode']!='self-signed':say('Proceeding authorizes automatic issuance/renewal under the Let\'s Encrypt subscriber agreement: https://letsencrypt.org/repository/')
                say('Host protection: '+('guarded setup' if d['security']=='1' else 'preserve'))
                v=wizard_answer('Apply these settings? y=yes','y').casefold()
                if v not in ('y','yes'):raise Failure('Enter y to apply, b to go back, or q to cancel.')
                break
            index+=1
        except Back:
            if index==0:say('Returned without installing anything.');return
            index-=1
        except (Cancelled,KeyboardInterrupt):say('\nSetup cancelled before installation.');return
        except (Failure,ValueError,subprocess.TimeoutExpired) as e:explain_failure(e)
    tasks=[]
    if new_r:
        tasks.append(('REALITY',['install','--server-ip',d['ip'],'--ports',','.join(str(d['rp'+str(i)]) for i in range(d['count'])),
                      '--domains',','.join(d['rd'+str(i)] for i in range(d['count']))]))
    if configure_h:
        cmd=['hy2-edit' if old_hy else 'hy2-install','--server-ip',d['ip'],'--hy2-port',str(d['hyport']),'--hy2-mode',d['mode']]
        if d['mode']!='self-signed':cmd+=['--hy2-domain',d['domain'],'--hy2-ports',','.join(str(d['hp'+str(i)]) for i in range(len(d['domain'].split(','))))]
        tasks.append(('Hysteria',cmd))
    failed=False
    for label,command in tasks:
        say('\nINSTALLING '+label+' ... Progress and bounded checks follow.')
        try:dispatch(parse_cli(command))
        except (Failure,ValueError,OSError,subprocess.TimeoutExpired) as e:
            failed=True
            if not getattr(e,'diagnostic_saved',False):remember_failure(label+' setup',e)
            explain_failure(e)
            say(label+' failed. Other successful protocols are retained. Run setup again to retry the missing protocol; use its menu to edit an existing installation.')
        except (KeyboardInterrupt,Cancelled):say('\nInterrupted. Completed protocols are retained; rerun setup to continue.');return
    if d['security']=='1' and not failed:
        try:
            dispatch(parse_cli(['network-tune']))
            firewall_args=parse_cli(['firewall-setup']);firewall_args.secure=True
            dispatch(firewall_args)
            if not FW_PENDING.exists():dispatch(parse_cli(['ssh-protect']))
        except (Failure,ValueError,OSError,subprocess.TimeoutExpired) as e:failed=True;explain_failure(e)
    say('\nSETUP '+('NEEDS ATTENTION' if failed else 'COMPLETE')+'.')
    if want_r and CURRENT.exists():show_links()
    if want_h and HY_CURRENT.exists():hy_show_links()
    say('Import each direct link into a compatible client and test from outside the server. Open management: sudo reality-manager')

def interactive_menu():
    if not CURRENT.exists() and not HY_CURRENT.exists():setup_wizard();return
    while True:
        try:
            say('\nREALITY + HYSTERIA MANAGER 1.7')
            say('1) Guided setup (both / one)  2) REALITY profiles / service')
            say('3) Hysteria / certificates    4) All direct config links')
            say('5) Troubleshoot / doctor      6) Security / network  0) Exit')
            choice=ask('Select action: ')
            if choice=='0':return
            if choice=='1':setup_wizard()
            elif choice=='2':reality_menu()
            elif choice=='3':hy_menu()
            elif choice=='4':
                if CURRENT.exists():dispatch(parse_cli(['links']))
                if HY_CURRENT.exists():dispatch(parse_cli(['hy2-links']))
            elif choice=='5':dispatch(parse_cli(['doctor']))
            elif choice=='6':security_menu()
            else:raise Failure('Choose 0 to 6.')
        except (Cancelled,KeyboardInterrupt):say('\nCancelled.');return
        except (Failure,ValueError,OSError,subprocess.TimeoutExpired) as e:explain_failure(e)


def parse_cli(argv=None):
    parser=argparse.ArgumentParser(description='REALITY Manager 1.7')
    parser.add_argument('command',nargs='?',default='install',choices=[
        'setup','doctor','menu','install','reinstall','uninstall','check','links','list','edit','enable','disable',
        'manager-update','status','start','stop','restart','logs','update','reconfigure','rollback',
        'security','security-check','protect','firewall-setup','firewall-confirm','firewall-rollback',
        'ssh-protect','ssh-unprotect','network-tune','network-restore','security-remove']+HY_COMMANDS)
    parser.add_argument('--server-ip');parser.add_argument('--ports');parser.add_argument('--domains')
    parser.add_argument('--version');parser.add_argument('--no-ufw',action='store_true')
    parser.add_argument('--profile');parser.add_argument('--port',type=int);parser.add_argument('--domain');parser.add_argument('--name')
    parser.add_argument('--purge',action='store_true');parser.add_argument('--yes',action='store_true')
    parser.add_argument('--secure',action='store_true');parser.add_argument('--allow-ports')
    parser.add_argument('--token');parser.add_argument('--console',action='store_true');parser.add_argument('--bbr',action='store_true')
    parser.add_argument('--hy2-mode',choices=['http','cloudflare','self-signed'])
    parser.add_argument('--hy2-ports');parser.add_argument('--hy2-domain');parser.add_argument('--hy2-email');parser.add_argument('--hy2-port',type=int)
    parser.add_argument('--hy2-token-file');parser.add_argument('--hy2-obfs',choices=['none','salamander'])
    parser.add_argument('--hy2-version');parser.add_argument('--hy2-insecure',action='store_true')
    args=parser.parse_args(argv)
    hy_options=any(getattr(args,k) is not None for k in ('hy2_ports','hy2_mode','hy2_domain','hy2_email','hy2_port','hy2_token_file','hy2_obfs','hy2_version'))
    if hy_options and args.command not in ('hy2-install','hy2-edit','hy2-update'):raise Failure('Hysteria settings require hy2-install, hy2-edit or hy2-update.')
    if args.hy2_insecure and args.command!='hy2-links':raise Failure('--hy2-insecure is an explicit hy2-links option.')
    if args.hy2_version and args.command=='hy2-edit':raise Failure('Use hy2-update --hy2-version to change the core.')
    if args.command=='hy2-update' and (args.server_ip or any(getattr(args,k) is not None for k in ('hy2_ports','hy2_mode','hy2_domain','hy2_email','hy2_port','hy2_token_file','hy2_obfs'))):
        raise Failure('Use hy2-edit to change Hysteria endpoints or certificates.')
    if args.command.startswith('hy2'):
        if any([args.ports,args.domains,args.version]):raise Failure('Xray bulk options are not Hysteria options.')
        if (args.hy2_ports or args.hy2_domain or args.hy2_email or args.hy2_token_file) and args.hy2_mode=='self-signed':raise Failure('Self-signed mode uses your server IP; domain/ACME options do not apply.')
    if args.command=='update' and any([args.server_ip,args.domains,args.ports]):
        raise Failure('Use edit or reconfigure to change endpoints.')
    if (args.purge or args.yes) and args.command not in ('uninstall','hy2-uninstall'):raise Failure('--purge/--yes are uninstall options.')
    if args.profile and args.command not in ('links','check','edit','enable','disable'):
        raise Failure('--profile is not valid with this command.')
    if any(getattr(args,k) is not None for k in ('port','domain','name')) and args.command!='edit':
        raise Failure('--port/--domain/--name are edit options.')
    if args.command not in ('install','reinstall','update','reconfigure','hy2-install','hy2-edit') and any([args.server_ip,args.ports,args.domains,args.version]):
        raise Failure('Bulk install options are not valid with this command.')
    if args.no_ufw and args.command not in ('install','reinstall','update','reconfigure','edit','enable','disable','hy2-install','hy2-edit','hy2-update'):
        raise Failure('--no-ufw is not valid with this command.')
    if args.secure and args.command not in ('install','reinstall','hy2-install'):
        raise Failure('--secure is an install/reinstall/hy2-install option.')
    if args.allow_ports is not None and args.command!='firewall-setup' and not (args.command in ('install','reinstall','hy2-install') and args.secure):
        raise Failure('--allow-ports requires firewall-setup or an installation with --secure.')
    if (args.token is not None or args.console) and args.command!='firewall-confirm':raise Failure('--token/--console are firewall-confirm options.')
    if args.bbr and args.command!='network-tune':raise Failure('--bbr is a network-tune option.')
    return args

def dispatch(args):
    with open(LOCK,'w') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|(0 if args.command=='firewall-rollback' else fcntl.LOCK_NB))
        except BlockingIOError:raise Failure('Another reality-manager process is running.')
        if FW_PENDING.exists() and args.command not in ('firewall-confirm','firewall-rollback',
            'doctor','security-check','security-remove','status','list','links','logs','check','hy2-status','hy2-links','hy2-logs','hy2-check'):
            raise Failure('Confirm or roll back the pending firewall before making other changes.')
        if args.command.startswith('hy2-'):
            hy_dispatch(args)
            if args.secure:secure_install(args)
        elif args.command in ('install','reinstall','update','reconfigure'):
            install(args)
            if args.secure:secure_install(args)
        elif args.command=='doctor':doctor()
        elif args.command=='check':
            if args.profile:check_profile(args.profile)
            else:load_state();health(CURRENT)
        elif args.command=='links':show_links(args.profile)
        elif args.command=='list':list_profiles()
        elif args.command in ('edit','enable','disable'):edit_profile(args)
        elif args.command=='manager-update':
            if CURRENT.exists():load_state()
            elif HY_CURRENT.exists():hy_state()
            else:receipt_data(create=True)
            promote_manager();say('Manager updated to 1.7. Existing profiles, core, and service state are unchanged. Run: sudo reality-manager')
        elif args.command=='rollback':rollback()
        elif args.command=='uninstall':uninstall(args)
        elif args.command=='security-check':security_check()
        elif args.command=='protect':protect()
        elif args.command=='firewall-setup':firewall_setup(args)
        elif args.command=='firewall-confirm':firewall_confirm(args)
        elif args.command=='firewall-rollback':firewall_rollback()
        elif args.command=='ssh-protect':ssh_protect()
        elif args.command=='ssh-unprotect':ssh_unprotect()
        elif args.command=='network-tune':network_tune(args.bbr)
        elif args.command=='network-restore':network_restore()
        elif args.command=='security-remove':security_remove()
        else:service_command(args.command)

def main():
    os.umask(0o077);args=parse_cli()
    if args.command=='setup':setup_wizard()
    elif args.command=='menu':interactive_menu()
    elif args.command=='security':security_menu()
    elif args.command=='hy2':hy_menu()
    else:dispatch(args)

if __name__=='__main__':
    try:main()
    except (KeyboardInterrupt,Cancelled):say('\nInterrupted.');sys.exit(130)
    except Exception as e:say('ERROR: '+str(e));sys.exit(1)
PYTHON
