import base64
import hashlib
import io
import pathlib
import tempfile
import unittest
import urllib.parse
import urllib.error
from unittest import mock


SOURCE = pathlib.Path(__file__).resolve().parents[1] / 'extras-oneclick.sh'
program = SOURCE.read_text().split("<<'PYTHON'\n", 1)[1].rsplit('\nPYTHON', 1)[0]
namespace = {'__name__': 'extras_test'}
exec(compile(program, str(SOURCE), 'exec'), namespace)


class ExtraProfiles(unittest.TestCase):
    def setUp(self):
        self.state = {
            'ip': '8.8.8.8',
            'any_domain': 'one.example.com', 'any_port': 9443, 'any_password': 'secret-one',
            'ss1_domain': 'two.example.net', 'ss1_port': 9444,
            'ss1_password': base64.b64encode(b'a' * 32).decode(),
            'ss2_domain': 'three.example.org', 'ss2_port': 9445,
            'ss2_password': base64.b64encode(b'b' * 32).decode(),
        }

    def test_three_independent_client_links(self):
        links = [namespace['uri'](self.state, kind) for kind in namespace['KINDS']]
        self.assertEqual(len(set(links)), 3)
        self.assertIn('insecure=0', links[0])
        self.assertIn('@one.example.com:9443/', links[0])
        for number, domain, port in ((1, 'two.example.net', 9444), (2, 'three.example.org', 9445)):
            parsed = urllib.parse.urlsplit(links[number])
            self.assertEqual(parsed.hostname, domain)
            self.assertEqual(parsed.port, port)
            plugin = urllib.parse.parse_qs(parsed.query)['plugin'][0]
            self.assertEqual(plugin, f'v2ray-plugin;tls;host={domain};path=/vpn')
        self.assertNotEqual(links[1].split('@')[0], links[2].split('@')[0])

    def test_shadowsocks_server_schema_and_isolated_ports(self):
        for kind in ('ss1', 'ss2'):
            config = namespace['config_ss'](self.state, pathlib.Path('/opt/test'), kind)
            self.assertEqual(config['server_port'], self.state[kind + '_port'])
            self.assertEqual(config['mode'], 'tcp_only')
            self.assertIn('server;tls;host=' + self.state[kind + '_domain'], config['plugin_opts'])
            self.assertNotIn('inbounds', config)

    def test_arbitrary_domains_and_public_endpoint(self):
        self.assertEqual(namespace['valid_domain']('GATEWAY.Example.IR.'), 'gateway.example.ir')
        self.assertEqual(namespace['valid_ip']('8.8.8.8'), '8.8.8.8')
        with self.assertRaises(RuntimeError):
            namespace['valid_ip']('127.0.0.1')
        with self.assertRaises(RuntimeError):
            namespace['valid_domain']('https://example.com')

    def test_asset_timeout_retries_then_reuses_verified_cache(self):
        payload = b'official-release-bytes'
        asset = {'name': 'release.tar.gz',
                 'browser_download_url': 'https://github.com/example/project/releases/download/v1.2.3/release.tar.gz'}
        digest = hashlib.sha256(payload).hexdigest()
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch.dict(namespace, {'ARCHIVE_CACHE': pathlib.Path(directory)}):
                with mock.patch('urllib.request.urlopen', side_effect=[TimeoutError('idle socket'), io.BytesIO(payload)]) as fetch:
                    path = namespace['verified_archive']('example/project', 'v1.2.3', asset, 'sha256', digest)
                    self.assertEqual(path.read_bytes(), payload)
                    self.assertEqual(fetch.call_count, 2)
                with mock.patch('urllib.request.urlopen') as fetch:
                    self.assertEqual(namespace['verified_archive']('example/project', 'v1.2.3', asset, 'sha256', digest), path)
                    fetch.assert_not_called()

    def test_asset_failure_explains_retry_without_installing(self):
        asset = {'name': 'release.tar.gz',
                 'browser_download_url': 'https://github.com/example/project/releases/download/v1.2.3/release.tar.gz'}
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch.dict(namespace, {'ARCHIVE_CACHE': pathlib.Path(directory)}):
                with mock.patch('urllib.request.urlopen', side_effect=TimeoutError('idle socket')) as fetch:
                    with mock.patch('time.sleep'):
                        with self.assertRaisesRegex(RuntimeError, 'run sudo reality-extras setup again'):
                            namespace['verified_archive']('example/project', 'v1.2.3', asset, 'sha256', '0'*64)
                    self.assertEqual(fetch.call_count, 3)


if __name__ == '__main__':
    unittest.main()
