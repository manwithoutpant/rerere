#!/usr/bin/env bash
# Optional AnyTLS and Shadowsocks + v2ray-plugin/TLS extension. Ubuntu 22.04+.
# Managed-by: reality-extras-v1
set -Eeuo pipefail
export LC_ALL=C PATH=/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/sbin:/usr/local/bin
[[ $EUID == 0 ]] || { echo 'Run as root.' >&2; exit 1; }
[[ -d /run/systemd/system ]] || { echo 'systemd is required.' >&2; exit 1; }
export REALITY_EXTRAS_SOURCE="$(readlink -f -- "$0")"
exec python3 - "$@" <<'PYTHON'
import base64,contextlib,hashlib,ipaddress,json,os,pathlib,platform,re,secrets,shlex,shutil,socket,ssl,subprocess,sys,tarfile,tempfile,time,urllib.error,urllib.parse
ROOT=pathlib.Path('/opt/reality-extras');CURRENT=ROOT/'current'
SERVICES={'any':'reality-anytls.service','ss1':'reality-shadowsocks-1.service','ss2':'reality-shadowsocks-2.service'}
KINDS=('any','ss1','ss2')
USER='realityextras';TAG='reality-extras-v1';MANAGER=pathlib.Path('/usr/local/sbin/reality-extras')
ARCHIVE_CACHE=pathlib.Path('/var/cache/reality-extras')

def fail(s):raise RuntimeError(s)
def log(s):print(s,file=sys.stderr,flush=True)
def cmd(argv,timeout=60,check=True):
    r=subprocess.run([str(x) for x in argv],text=True,capture_output=True,timeout=timeout)
    if check and r.returncode:fail(pathlib.Path(str(argv[0])).name+': '+(r.stderr or r.stdout)[-900:])
    return r

def api(repo,tag=None):
    import urllib.request
    suffix='/releases/tags/'+tag if tag else '/releases/latest'
    req=urllib.request.Request('https://api.github.com/repos/'+repo+suffix,headers={'User-Agent':'reality-extras/1.0'})
    try:
        with urllib.request.urlopen(req,timeout=25) as r:return json.load(r)
    except (urllib.error.URLError,TimeoutError,OSError) as e:
        fail('GitHub release metadata unavailable for '+repo+': '+str(e))

def verified_archive(repo,tag,asset,algorithm,expected):
    import urllib.request
    cache=ARCHIVE_CACHE
    if cache.is_symlink():fail('Refusing symlink archive cache.')
    cache.mkdir(mode=0o700,parents=True,exist_ok=True);cache.chmod(0o700)
    name=hashlib.sha256((repo+'\0'+tag+'\0'+asset['name']+'\0'+expected).encode()).hexdigest()+'.archive'
    destination=cache/name
    if destination.is_symlink():fail('Refusing symlink cached archive.')
    if destination.is_file():
        if getattr(hashlib,algorithm)(destination.read_bytes()).hexdigest()==expected:
            log('Using verified cached '+repo+' '+tag);return destination
        destination.unlink()
    url=asset['browser_download_url']
    if not url.startswith('https://github.com/'+repo+'/releases/download/'+tag+'/'):
        fail('Unexpected asset URL for '+repo)
    last_error=''
    for attempt in range(1,4):
        staging=cache/(name+'.part-'+secrets.token_hex(6))
        try:
            log('Downloading '+repo+' '+tag+' ('+str(attempt)+'/3; up to 120 seconds) ...')
            req=urllib.request.Request(url,headers={'User-Agent':'reality-extras/1.1'})
            deadline=time.monotonic()+120
            with urllib.request.urlopen(req,timeout=25) as response,staging.open('xb') as out:
                os.chmod(staging,0o600)
                total=0
                while True:
                    if time.monotonic()>deadline:raise TimeoutError('download exceeded 120 seconds')
                    chunk=response.read(1024*1024)
                    if not chunk:break
                    total+=len(chunk)
                    if total>120*1024*1024:fail('Oversized release archive: '+repo)
                    out.write(chunk)
            if getattr(hashlib,algorithm)(staging.read_bytes()).hexdigest()!=expected:
                fail('Official asset hash mismatch: '+repo+' '+tag)
            staging.replace(destination)
            log('Verified '+repo+' '+tag+' ('+str(total)+' bytes).')
            return destination
        except (urllib.error.HTTPError,urllib.error.URLError,TimeoutError,OSError) as e:
            last_error=str(e)
            if isinstance(e,urllib.error.HTTPError) and e.code not in (408,429,500,502,503,504):
                fail('Download rejected for '+repo+' '+tag+': '+last_error)
            log('Download attempt '+str(attempt)+'/3 failed: '+last_error)
            if attempt<3:time.sleep(attempt*2)
        finally:staging.unlink(missing_ok=True)
    fail('Could not download '+repo+' '+tag+' after 3 attempts: '+last_error+'. Check outbound access to github.com and release-assets.githubusercontent.com, then run sudo reality-extras setup again. Previously verified downloads are cached.')

def check_plugin_binary(path):
    # Upstream -V enables VPN mode and keeps running; -version prints and exits.
    result=cmd([path,'-version'],timeout=10)
    if 'v2ray-plugin' not in result.stdout:
        fail('v2ray-plugin version check returned unexpected output.')

def download(repo,pattern,member,out,extra=None):
    import urllib.request
    release=api(repo);tag=release['tag_name']
    if release.get('draft') or release.get('prerelease') or not re.fullmatch(r'v?\d+\.\d+\.\d+',tag):fail('A stable release is required: '+repo)
    matches=[a for a in release['assets'] if re.fullmatch(pattern.format(tag=re.escape(tag)),a['name'])]
    if len(matches)!=1:fail('Official asset not found for '+repo)
    a=matches[0];digest=a.get('digest') or ''
    algorithm='sha256';expected=digest.removeprefix('sha256:')
    if not re.fullmatch(r'sha256:[0-9a-f]{64}',digest):
        if repo!='shadowsocks/v2ray-plugin':fail('No official GitHub SHA-256 digest: '+repo)
        # The older v1.3.1 upstream release publishes SHA-1 for every binary.
        # Use it only when GitHub does not provide a SHA-256 for v1.3.2.
        release=api(repo,'v1.3.1');tag=release['tag_name']
        matches=[asset for asset in release['assets'] if re.fullmatch(pattern,asset['name'])]
        if len(matches)!=1:fail('Pinned upstream plugin asset unavailable.')
        a=matches[0]
        match=re.search(r'(?m)([0-9a-f]{40})\s+(?:bin/)?'+re.escape(a['name'])+r'\b',release.get('body') or '')
        if not match:fail('Official plugin hash unavailable. Refusing unverified binary.')
        algorithm='sha1';expected=match.group(1)
    archive=verified_archive(repo,tag,a,algorithm,expected)
    with tarfile.open(archive,'r:*') as z:
        matches=[i for i in z.getmembers() if i.isfile() and re.fullmatch(member,pathlib.PurePosixPath(i.name).name)]
        if len(matches)!=1:fail('Expected executable missing in '+repo)
        if matches[0].size>80*1024*1024:fail('Oversized executable: '+repo)
        f=z.extractfile(matches[0]);out.write_bytes(f.read())
        if extra:
            extra_matches=[i for i in z.getmembers() if i.isfile() and pathlib.PurePosixPath(i.name).name=='sslocal']
            if len(extra_matches)!=1 or extra_matches[0].size>80*1024*1024:fail('sslocal executable missing from verified release.')
            extra.write_bytes(z.extractfile(extra_matches[0]).read());extra.chmod(0o750)
    out.chmod(0o750)

def valid_domain(value):
    value=value.strip().rstrip('.').lower()
    if not re.fullmatch(r'(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}',value):fail('Enter a plain DNS hostname, not a URL or IP.')
    return value

def valid_port(value):
    try:n=int(value)
    except ValueError:fail('Port must be an integer.')
    if not 1024<=n<=65535:fail('Use a TCP port between 1024 and 65535.')
    return n

def valid_ip(value):
    try:
        ip=ipaddress.ip_address(value)
        if not ip.is_global:fail('Enter a publicly routable server IP.')
        return str(ip)
    except ValueError:fail('Enter a public server IP.')

def endpoint(host,port):return ('['+host+']' if ':' in host else host)+':'+str(port)
def uri(s,kind):
    if kind=='any':return 'anytls://'+urllib.parse.quote(s['any_password'],safe='')+'@'+endpoint(s['any_domain'],s['any_port'])+'/?'+urllib.parse.urlencode({'sni':s['any_domain'],'insecure':'0'})+'#AnyTLS-'+s['any_domain']
    # SIP002 with a SIP003 plugin. Plugin options are consumed only by compatible clients.
    user=base64.urlsafe_b64encode(('2022-blake3-aes-256-gcm:'+s[kind+'_password']).encode()).decode().rstrip('=')
    plugin='v2ray-plugin;tls;host='+s[kind+'_domain']+';path=/vpn'
    return 'ss://'+user+'@'+endpoint(s[kind+'_domain'],s[kind+'_port'])+'/?'+urllib.parse.urlencode({'plugin':plugin})+'#SS-TLS-'+kind+'-'+s[kind+'_domain']

def write(path,obj,mode=0o640):
    if path.is_symlink():fail('Refusing symlink: '+str(path))
    tmp=path.with_name(path.name+'.tmp-'+secrets.token_hex(4));tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.chmod(mode);tmp.replace(path)

def state():
    if not CURRENT.is_symlink():fail('AnyTLS/Shadowsocks extension is not installed.')
    s=json.loads((CURRENT/'state.json').read_text())
    if s.get('owner')!=TAG:fail('Unrecognized extension state.')
    return s

def cert_for(domain):
    live=pathlib.Path('/etc/letsencrypt/live')/domain
    cert,key=live/'fullchain.pem',live/'privkey.pem'
    if not cert.exists() or not key.exists():fail('Certificate is unavailable for '+domain)
    cmd(['openssl','x509','-checkend','86400','-noout','-in',cert])
    # OpenSSL hostname check avoids trusting a stale unrelated certificate.
    cmd(['openssl','x509','-checkhost',domain,'-noout','-in',cert])
    return cert,key

def certificate(domain,ip):
    import socket
    resolved={str(ipaddress.ip_address(row[4][0])) for row in socket.getaddrinfo(domain,None,type=socket.SOCK_STREAM)}
    if resolved!={ip}:fail(domain+' DNS points to '+','.join(sorted(resolved))+'; expected '+ip)
    try:return cert_for(domain)
    except RuntimeError:pass
    busy=bool(cmd(['ss','-H','-ltn','sport','=','80'],check=False).stdout.strip())
    if not shutil.which('certbot'):
        log('Installing Ubuntu certbot for managed certificate renewal ...')
        cmd(['apt-get','update','-qq'],timeout=180)
        cmd(['apt-get','install','-y','-qq','--no-install-recommends','certbot'],timeout=300)
    certargs=['certbot','certonly','--non-interactive','--agree-tos','--register-unsafely-without-email']
    token=os.environ.get('REALITY_EXTRAS_CF_TOKEN','')
    if token:
        if not re.fullmatch(r'[A-Za-z0-9_-]{20,200}',token):fail('Invalid Cloudflare API token format.')
        if not pathlib.Path('/usr/lib/python3/dist-packages/certbot_dns_cloudflare').is_dir():
            cmd(['apt-get','install','-y','-qq','--no-install-recommends','python3-certbot-dns-cloudflare'],timeout=300)
        creds=pathlib.Path('/etc/letsencrypt/credentials/reality-extras.ini')
        creds.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        if creds.exists() and creds.read_text().strip()!='dns_cloudflare_api_token = '+token:fail('Different saved Cloudflare token; refusing to replace it.')
        creds.write_text('dns_cloudflare_api_token = '+token+'\n');creds.chmod(0o600)
        certargs.extend(['--dns-cloudflare','--dns-cloudflare-credentials',str(creds),'--dns-cloudflare-propagation-seconds','30'])
        log('Issuing '+domain+' through Cloudflare DNS-01 ...')
    else:
        if busy:fail('TCP/80 is occupied. Set REALITY_EXTRAS_CF_TOKEN for Cloudflare DNS-01, or provide an existing Let\'s Encrypt certificate.')
        certargs.extend(['--standalone','--preferred-challenges','http'])
        log('Issuing '+domain+' through HTTP-01; public TCP/80 must be reachable ...')
    cmd(certargs+['-d',domain],timeout=240)
    return cert_for(domain)

def renew():
    s=state();p=CURRENT.resolve()
    import grp
    gid=grp.getgrnam(USER).gr_gid
    for kind in KINDS:
        c,k=cert_for(s[kind+'_domain']);copy_cert(c,p/(kind+'.crt'),gid);copy_cert(k,p/(kind+'.key'),gid)
    for kind in KINDS:cmd(['systemctl','restart',SERVICES[kind]],timeout=20)

def renewal_hook():
    p=pathlib.Path('/etc/letsencrypt/renewal-hooks/deploy/reality-extras')
    if p.is_symlink():fail('Refusing renewal-hook symlink.')
    if p.exists() and p.read_text()!='#!/bin/sh\n# '+TAG+'\nexec /usr/local/sbin/reality-extras renew\n':fail('Renewal hook name is already owned by another program.')
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text('#!/bin/sh\n# '+TAG+'\nexec /usr/local/sbin/reality-extras renew\n');p.chmod(0o700)

def firewall(port):
    if shutil.which('ufw') and cmd(['ufw','status'],check=False).stdout.startswith('Status: active'):
        rules=[shlex.split(line) for line in cmd(['ufw','show','added']).stdout.splitlines() if line.startswith('ufw ')]
        expected=['ufw','allow',str(port)+'/tcp','comment',TAG]
        if expected in rules:return
        if any('allow' in rule and (str(port)+'/tcp' in rule or str(port) in rule) for rule in rules):
            log('Existing UFW rule retained for TCP/'+str(port)+'; verify source and family coverage.');return
        cmd(expected,timeout=25)
        log('UFW allowed TCP/'+str(port))

def remove_firewall(s):
    if not shutil.which('ufw'):return
    rules=[shlex.split(line) for line in cmd(['ufw','show','added'],check=False).stdout.splitlines() if line.startswith('ufw ')]
    for kind in KINDS:
        port=s[kind+'_port'];expected=['ufw','allow',str(port)+'/tcp','comment',TAG]
        if expected in rules:cmd(['ufw','--force','delete',*expected[1:]],timeout=25)

def config_any(s,p):
    return {'log':{'level':'warn'},'inbounds':[{'type':'anytls','tag':'anytls-in','listen':'::' if ':' in s['ip'] else '0.0.0.0',
        'listen_port':s['any_port'],'users':[{'name':'managed','password':s['any_password']}],
        'tls':{'enabled':True,'server_name':s['any_domain'],'certificate_path':str(p/'any.crt'),'key_path':str(p/'any.key')}}],
        'outbounds':[{'type':'direct','tag':'direct'}]}

def config_ss(s,p,kind):
    return {'server':'0.0.0.0','server_port':s[kind+'_port'],
      'method':'2022-blake3-aes-256-gcm','password':s[kind+'_password'],
      'mode':'tcp_only','plugin':str(p/'v2ray-plugin'),
      'plugin_opts':'server;tls;host='+s[kind+'_domain']+';cert='+str(p/(kind+'.crt'))+';key='+str(p/(kind+'.key'))+';path=/vpn'}

def copy_cert(src,dst,gid):
    tmp=dst.with_name(dst.name+'.tmp-'+secrets.token_hex(4));tmp.write_bytes(src.read_bytes());tmp.chmod(0o640);os.chown(tmp,0,gid);tmp.replace(dst)

def service(kind):
    command=f'{CURRENT}/sing-box run -c {CURRENT}/any.json' if kind=='any' else f'{CURRENT}/ssserver -c {CURRENT}/{kind}.json'
    return f'''# {TAG}\n[Unit]\nDescription=Managed {kind} proxy\nAfter=network.target\n[Service]\nUser={USER}\nGroup={USER}\nExecStart={command}\nRestart=on-failure\nRestartSec=3\nUMask=0077\nNoNewPrivileges=true\nProtectSystem=strict\nProtectHome=true\nPrivateTmp=true\nRestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX AF_NETLINK\nCapabilityBoundingSet=\nLimitNOFILE=65536\n[Install]\nWantedBy=multi-user.target\n'''

def tcpfree(port):
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as sock:
        try:sock.bind(('0.0.0.0',port))
        except OSError:fail('TCP/'+str(port)+' is occupied.')

def local_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0));return sock.getsockname()[1]

def authenticated_probe(kind,s,p):
    port=local_port();domain=s[kind+'_domain'];remote=s[kind+'_port']
    if kind=='any':
        client={'log':{'level':'error'},'inbounds':[{'type':'socks','listen':'127.0.0.1','listen_port':port}],
          'outbounds':[{'type':'anytls','tag':'remote','server':'127.0.0.1','server_port':remote,
            'password':s['any_password'],'tls':{'enabled':True,'server_name':domain}}]}
        with tempfile.TemporaryDirectory() as d:
            path=pathlib.Path(d)/'client.json';write(path,client,0o600)
            check=cmd([p/'sing-box','check','-c',path],timeout=15)
            probe_process(kind,port,[str(p/'sing-box'),'run','-c',str(path)])
    else:
        client={'server':'127.0.0.1','server_port':remote,'local_address':'127.0.0.1','local_port':port,
          'method':'2022-blake3-aes-256-gcm','password':s[kind+'_password'],'mode':'tcp_only',
          'plugin':str(p/'v2ray-plugin'),'plugin_opts':'tls;host='+domain+';path=/vpn'}
        with tempfile.TemporaryDirectory() as d:
            path=pathlib.Path(d)/'client.json';write(path,client,0o600)
            probe_process(kind,port,[str(p/'sslocal'),'-c',str(path)])

def probe_process(kind,port,argv):
    proc=subprocess.Popen(argv,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:probe_socks(kind,port,proc)
    finally:
        proc.terminate()
        try:proc.wait(timeout=4)
        except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=4)

def probe_socks(kind,port,proc):
    import urllib.request
    # Curl is a real client: this verifies the password, TLS, plugin path and outbound HTTPS.
    last_error=''
    for attempt in range(8):
        if proc.poll() is not None:fail(kind+' local test client exited early (status '+str(proc.returncode)+'). Check journalctl -u '+SERVICES[kind]+'.')
        for dest in ('https://www.google.com/generate_204','https://www.cloudflare.com/cdn-cgi/trace'):
            result=cmd(['curl','-fsS','--noproxy','','--proxy','socks5h://127.0.0.1:'+str(port),
                '--connect-timeout','2','--max-time','8','-o','/dev/null',dest],timeout=10,check=False)
            if result.returncode==0:log('PASS authenticated HTTPS egress: '+kind);return
            last_error='curl exit '+str(result.returncode)+': '+(result.stderr or '').strip()[-200:]
        time.sleep(1)
    fail(kind+' authenticated proxy test failed ('+last_error+'). Use journalctl -u '+SERVICES[kind]+' for server logs.')

def install(s):
    if ROOT.exists():fail('Extension is already installed; use links/status or uninstall first.')
    needed={'curl':'curl','openssl':'openssl','ss':'iproute2'}
    missing=sorted({pkg for binary,pkg in needed.items() if not shutil.which(binary)})
    if missing:
        cmd(['apt-get','update','-qq'],timeout=180)
        cmd(['apt-get','install','-y','-qq','--no-install-recommends',*missing],timeout=300)
    for kind in KINDS:
        s[kind+'_domain']=valid_domain(s[kind+'_domain']);s[kind+'_port']=valid_port(s[kind+'_port'])
    s['ip']=valid_ip(s['ip'])
    ports=[s[kind+'_port'] for kind in KINDS]
    if len(set(ports))!=len(ports):fail('Choose three distinct TCP ports.')
    for port in ports:tcpfree(port)
    for domain in {s[kind+'_domain'] for kind in KINDS}:certificate(domain,s['ip'])
    s['owner']=TAG;s['any_password']=secrets.token_urlsafe(32)
    for kind in ('ss1','ss2'):s[kind+'_password']=base64.b64encode(secrets.token_bytes(32)).decode()
    with tempfile.TemporaryDirectory() as t:
        t=pathlib.Path(t);arch={'x86_64':'amd64','aarch64':'arm64'}.get(platform.machine())
        if not arch:fail('Supported architectures: x86_64 and aarch64.')
        download('SagerNet/sing-box',r'sing-box-\d+\.\d+\.\d+-linux-'+arch+r'\.tar\.gz',r'sing-box',t/'sing-box')
        rustarch='x86_64' if arch=='amd64' else 'aarch64'
        download('shadowsocks/shadowsocks-rust',r'shadowsocks-v?\d+\.\d+\.\d+\.'+rustarch+r'-unknown-linux-gnu\.tar\.xz',r'ssserver',t/'ssserver',t/'sslocal')
        download('shadowsocks/v2ray-plugin',r'v2ray-plugin-linux-'+arch+r'-v?\d+\.\d+\.\d+\.tar\.gz',r'v2ray-plugin_linux_.*|v2ray-plugin',t/'v2ray-plugin')
        cmd([t/'sing-box','version'],timeout=15)
        cmd([t/'ssserver','--version'],timeout=15)
        check_plugin_binary(t/'v2ray-plugin')
        if cmd(['id','-u',USER],check=False).returncode==0:fail('The service account already exists; refusing to take ownership.')
        cmd(['useradd','--system','--user-group','--home-dir',str(ROOT),'--no-create-home','--shell','/usr/sbin/nologin',USER])
        import atexit
        def cleanup_staging():
            if ROOT.exists() and not CURRENT.is_symlink():shutil.rmtree(ROOT)
            cmd(['userdel',USER],check=False)
        atexit.register(cleanup_staging)
        import grp
        gid=grp.getgrnam(USER).gr_gid;ROOT.mkdir(mode=0o750);os.chown(ROOT,0,gid)
        releases=ROOT/'releases';releases.mkdir(mode=0o750);os.chown(releases,0,gid)
        p=releases/(time.strftime('%Y%m%dT%H%M%S')+'-'+secrets.token_hex(3));p.mkdir(mode=0o750);os.chown(p,0,gid)
        for name in ('sing-box','ssserver','sslocal','v2ray-plugin'):
            shutil.copyfile(t/name,p/name);(p/name).chmod(0o750);os.chown(p/name,0,gid)
        for kind in KINDS:
            c,k=cert_for(s[kind+'_domain']);copy_cert(c,p/(kind+'.crt'),gid);copy_cert(k,p/(kind+'.key'),gid)
        write(p/'any.json',config_any(s,p))
        for kind in ('ss1','ss2'):write(p/(kind+'.json'),config_ss(s,p,kind))
        write(p/'state.json',s,0o600)
        for file in ('any.json','ss1.json','ss2.json'):os.chown(p/file,0,gid)
        cmd([p/'sing-box','check','-c',p/'any.json'])
        marker=ROOT/'.managed-by';marker.write_text(TAG);marker.chmod(0o600)
        CURRENT.symlink_to(p)
        units=[]
        try:
            for kind in KINDS:
                u=pathlib.Path('/etc/systemd/system')/SERVICES[kind]
                if u.exists():fail('Service name already occupied: '+str(u))
                u.write_text(service(kind));u.chmod(0o644);units.append(u)
            cmd(['systemctl','daemon-reload'])
            for kind in KINDS:cmd(['systemctl','enable','--now',SERVICES[kind]],timeout=45)
            time.sleep(2)
            for kind in KINDS:
                if cmd(['systemctl','is-active','--quiet',SERVICES[kind]],check=False).returncode:
                    details=cmd(['journalctl','-u',SERVICES[kind],'-n','8','--no-pager','-o','cat'],check=False).stdout[-900:]
                    fail(SERVICES[kind]+' exited during startup. Recent logs: '+details)
            # The real protocol client validates the TLS certificate and SNI,
            # authenticates, and proves HTTPS egress. A bare s_client probe can
            # fail when the application expects protocol data after TLS setup.
            for kind in KINDS:
                log('Testing '+kind.upper()+' via authenticated TLS client ...')
                authenticated_probe(kind,s,p)
            renewal_hook()
            for port in ports:firewall(port)
        except BaseException:
            for kind in KINDS:cmd(['systemctl','disable','--now',SERVICES[kind]],check=False)
            try:remove_firewall(s)
            except Exception:log('Check previously opened UFW rules tagged '+TAG+'.')
            for u in units:u.unlink(missing_ok=True)
            cmd(['systemctl','daemon-reload'],check=False);CURRENT.unlink(missing_ok=True);shutil.rmtree(ROOT)
            cmd(['userdel',USER],check=False)
            raise
        atexit.unregister(cleanup_staging)
    for kind in KINDS:print(kind.upper()+': '+uri(s,kind))
    log('Open provider firewall TCP/'+','.join(map(str,ports))+'.')
    log('The SS plugin link requires a client with SIP003 v2ray-plugin support; import and test from another network.')

def setup():
    def tty(prompt,secret=False):
        import termios
        fd=os.open('/dev/tty',os.O_RDWR|os.O_NOCTTY)
        before=termios.tcgetattr(fd)
        try:
            cooked=before[:];cooked[6]=before[6][:]
            cooked[0]=(cooked[0]|termios.ICRNL)&~(termios.IGNCR|termios.INLCR)
            cooked[3]|=termios.ICANON|termios.ISIG|termios.ECHO
            if secret:cooked[3]&=~termios.ECHO
            termios.tcsetattr(fd,termios.TCSANOW,cooked)
            os.write(fd,prompt.encode());data=bytearray()
            while True:
                c=os.read(fd,1)
                if not c:fail('Terminal closed during setup.')
                if c==b'\n':break
                data.extend(c)
                if len(data)>4096:fail('Input is too long.')
            if secret:os.write(fd,b'\n')
            return data.decode(errors='replace').strip()
        finally:termios.tcsetattr(fd,termios.TCSANOW,before);os.close(fd)
    def answer(prompt,default):return tty(prompt+' ['+str(default)+'] (q=cancel): ') or str(default)
    def ask(prompt,default,validator):
        while True:
            try:
                value=answer(prompt,default)
                if value.lower()=='q':fail('Cancelled; no services changed.')
                return validator(value)
            except (ValueError,RuntimeError) as e:log('Check input: '+str(e))
    if CURRENT.is_symlink():fail('Already installed. Run reality-extras links or status.')
    guess=''
    import urllib.request
    try:
        with urllib.request.urlopen('https://api.ipify.org',timeout=6) as r:guess=valid_ip(r.read(60).decode().strip())
    except Exception:pass
    ip=ask('Public server IP (verify against provider dashboard)',guess,valid_ip)
    a=ask('AnyTLS hostname (DNS-only A/AAAA to server)', '',valid_domain)
    b=ask('Shadowsocks 1 TLS hostname (same domain is allowed)',a,valid_domain)
    c=ask('Shadowsocks 2 TLS hostname (same domain is allowed)',b,valid_domain)
    s={'ip':ip,'any_domain':a,'ss1_domain':b,'ss2_domain':c}
    for kind,default in (('any',9443),('ss1',9444),('ss2',9445)):
        s[kind+'_port']=ask(kind.upper()+' TCP port',default,valid_port)
    for kind in KINDS:log('Review '+kind.upper()+' '+s[kind+'_domain']+':'+str(s[kind+'_port']))
    if not os.environ.get('REALITY_EXTRAS_CF_TOKEN') and cmd(['ss','-H','-ltn','sport','=','80'],check=False).stdout.strip():
        log('TCP/80 is occupied. Existing Let\'s Encrypt certificates work; new domains require DNS-01.')
        value=tty('Cloudflare DNS API token for NEW certificates (leave blank to keep existing certs only): ',secret=True)
        if value:os.environ['REALITY_EXTRAS_CF_TOKEN']=value
    if tty('Apply? [y/N]: ').lower()!='y':return
    install(s)

def main():
    mode=sys.argv[1] if len(sys.argv)>1 else 'setup'
    if mode=='manager-install':
        source=pathlib.Path(os.environ['REALITY_EXTRAS_SOURCE'])
        if MANAGER.is_symlink():fail('Refusing manager symlink.')
        if MANAGER.exists() and not MANAGER.read_text().startswith('#!/usr/bin/env bash\n# Optional AnyTLS and Shadowsocks + v2ray-plugin/TLS extension. Ubuntu 22.04+.\n# Managed-by: '+TAG+'\n'):
            fail('Existing extras manager is not owned by this installer.')
        if source!=MANAGER:shutil.copyfile(source,MANAGER)
        MANAGER.chmod(0o700)
        log('Extras manager installed; service state unchanged. Run: sudo reality-extras setup')
    elif mode=='setup':setup()
    elif mode=='install':
        if len(sys.argv)!=9:fail('Usage: reality-extras install SERVER_IP ANY_DOMAIN ANY_PORT SS1_DOMAIN SS1_PORT SS2_DOMAIN SS2_PORT')
        install(dict(zip(('ip','any_domain','any_port','ss1_domain','ss1_port','ss2_domain','ss2_port'),sys.argv[2:])))
    elif mode=='links':
        s=state()
        for kind in KINDS:print(uri(s,kind))
    elif mode=='status':
        s=state()
        for kind in KINDS:log(SERVICES[kind]+' '+cmd(['systemctl','is-active',SERVICES[kind]],check=False).stdout.strip()+': '+s[kind+'_domain']+':'+str(s[kind+'_port']))
    elif mode=='check':
        s=state();p=CURRENT.resolve()
        for kind in KINDS:
            if cmd(['systemctl','is-active',SERVICES[kind]],check=False).returncode:fail(SERVICES[kind]+' is not active.')
            resolved={str(ipaddress.ip_address(row[4][0])) for row in socket.getaddrinfo(s[kind+'_domain'],None,type=socket.SOCK_STREAM)}
            if resolved!={s['ip']}:fail(kind+' DNS does not exclusively resolve to '+s['ip'])
            cert_for(s[kind+'_domain'])
            authenticated_probe(kind,s,p)
        log('All three authenticated local tests passed. Test public paths from an external client.')
    elif mode=='renew':renew()
    elif mode=='uninstall':
        s=state()
        for kind in KINDS:
            cmd(['systemctl','disable','--now',SERVICES[kind]],check=False)
            u=pathlib.Path('/etc/systemd/system')/SERVICES[kind]
            if u.exists() and u.read_text().startswith('# '+TAG):u.unlink()
        cmd(['systemctl','daemon-reload']);remove_firewall(s);shutil.rmtree(ROOT)
        hook=pathlib.Path('/etc/letsencrypt/renewal-hooks/deploy/reality-extras')
        if hook.exists() and hook.read_text().startswith('#!/bin/sh\n# '+TAG+'\n'):hook.unlink()
        cmd(['userdel',USER],check=False)
        log('Extension removed. Certificates stay managed by certbot.')
    else:fail('Commands: manager-install, setup, install, links, status, check, renew, uninstall')

if __name__=='__main__':
    try:main()
    except (RuntimeError,subprocess.TimeoutExpired,TimeoutError,OSError,ValueError) as e:log('ERROR: '+str(e));sys.exit(1)
PYTHON
