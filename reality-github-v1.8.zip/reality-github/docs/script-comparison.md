# Design choices and comparison

This comparison uses the projects' own documentation. It is not a full source audit or a deployment test of those projects. Their installer code was not copied or executed to build this package.

| Project | Relevant documented features | Choice for this manager |
| --- | --- | --- |
| [XTLS/Xray-install](https://github.com/XTLS/Xray-install) | Core install/update, version selection, systemd, remove/purge | Retain explicit install/update, owned-service removal, and a dedicated service account. |
| [233boy/Xray](https://github.com/233boy/Xray) | Config management, URL/QR export, port/SNI/UUID changes, service commands, multiple protocols | Include an English profile list, independent port/domain edits, direct URI output, and service controls. |
| [MHSanaei/3x-ui](https://github.com/MHSanaei/3x-ui) | Web administration, users, traffic limits, expiration, statistics, QR, subscriptions | Keep this small single-server workflow in the terminal, with direct config links as requested. |

Version 1.2 adds profile editing, names, enable/disable, per-profile checks, and an upgrade command for the manager itself. Existing safeguards include official Xray digest verification, target and authenticated-tunnel checks, retaining credentials, rollback, and [UFW](https://manpages.ubuntu.com/manpages/bionic/man8/ufw.8.html) ownership tracking.

No web panel, database, Python dependency packages, subscription endpoint, billing
system or bandwidth quota is added. Version 1.5 supports 1–4 REALITY profiles and
one Hysteria profile. UUID/key rotation and adding arbitrary profile slots to an
existing installation remain outside the menu's scope.

Xray and Hysteria have independent services. Optional Fail2ban provides SSH
protection; optional conservative TCP tuning and guarded UFW activation are
explained in [security-network.md](security-network.md). The manager itself runs
only on demand. Temporary test clients and servers are cleaned up after checks.

Version 1.5 adds a unified setup wizard, back/cancel navigation, domain/port
validation, terminal-input fixes, and read-only diagnostics. Existing credentials
and core versions are preserved unless a corresponding change is explicitly chosen.
