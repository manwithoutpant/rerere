"""Real official Hysteria binary, isolated loopback HTTPS and UDP fixtures, no host mutations."""
import copy, http.server, pathlib, socket, ssl, struct, sys, tempfile, threading, time, types

script=pathlib.Path(__file__).resolve().parents[1]/'reality-oneclick.sh'
m=types.ModuleType('installer')
exec(compile(script.read_text().split("<<'PYTHON'\n",1)[1].rsplit('\nPYTHON',1)[0],str(script),'exec'),m.__dict__)
if len(sys.argv)!=2:raise SystemExit('Usage: python3 tests/integration_hysteria.py /path/to/official/hysteria')
binary=pathlib.Path(sys.argv[1]).resolve()

class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        body=b'hysteria2-integration-ok';self.send_response(200)
        self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def log_message(self,*args):pass

def udp_port():
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]

def socks_udp(socks_port,target_port):
    with socket.create_connection(('127.0.0.1',socks_port),timeout=3) as tcp:
        tcp.sendall(b'\x05\x01\x00');assert tcp.recv(2)==b'\x05\x00'
        tcp.sendall(b'\x05\x03\x00\x01'+socket.inet_aton('127.0.0.1')+b'\x00\x00')
        reply=tcp.recv(64);assert reply[:4]==b'\x05\x00\x00\x01',reply
        address=socket.inet_ntoa(reply[4:8]);port=struct.unpack('!H',reply[8:10])[0]
        packet=b'\x00\x00\x00\x01'+socket.inet_aton('127.0.0.1')+struct.pack('!H',target_port)+b'udp-payload-ok'
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as udp:
            udp.settimeout(2);udp.sendto(packet,(address,port));return udp.recv(2048)[10:]

with tempfile.TemporaryDirectory(prefix='hy2-integration-') as td:
    work=pathlib.Path(td)
    state={'schema':1,'protocol':'hysteria2','server_ip':'127.0.0.1','port':udp_port(),
        'mode':'self-signed','obfs':'none','password':'A'*43,'obfs_password':'B'*43}
    state.update(m.hy_certificate('127.0.0.1',work))
    m.atomic_text(work/'server.crt',state['certificate']);m.atomic_text(work/'server.key',state['private_key'])
    web=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(work/'server.crt',work/'server.key')
    web.socket=ctx.wrap_socket(web.socket,server_side=True);threading.Thread(target=web.serve_forever,daemon=True).start()
    echo=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);echo.bind(('127.0.0.1',0));echo.settimeout(.2)
    done=threading.Event()
    def udp_echo():
        while not done.is_set():
            try:
                payload,addr=echo.recvfrom(2048);echo.sendto(payload,addr)
            except socket.timeout:pass
            except OSError:break
    threading.Thread(target=udp_echo,daemon=True).start()
    def fetch(socks):
        return m.run(['curl','-fsS','--noproxy','','--proxy','socks5h://127.0.0.1:'+str(socks),
            '--connect-timeout','2','--max-time','4','--cacert',work/'server.crt',
            'https://127.0.0.1:'+str(web.server_port)+'/'],timeout=6,check=False)
    try:
        for obfs in ('none','salamander'):
            state['obfs']=obfs;cfg=m.hy_config(state,work)
            # Loopback egress is allowed ONLY for the isolated fixture, then tested denied below.
            cfg['acl']['inline']=['direct(all)']
            with m.hy_process(binary,'server',cfg,work,'server-'+obfs):
                time.sleep(.2)
                for case in ('pin','ca','wrong-pin','wrong-password','unknown-ca'):
                    socks=m.free_port();client=m.hy_client(state,'127.0.0.1',socks)
                    if case=='ca':client['tls']={'insecure':False,'sni':'127.0.0.1','ca':str(work/'server.crt')}
                    elif case=='wrong-pin':client['tls']['pinSHA256']='0'*64
                    elif case=='wrong-password':client['auth']='wrong-secret'
                    elif case=='unknown-ca':client['tls']={'insecure':False}
                    with m.hy_process(binary,'client',client,work,'client-'+case) as cp:
                        time.sleep(.45)
                        result=fetch(socks)
                        if case in ('pin','ca'):
                            assert result.returncode==0 and result.stdout=='hysteria2-integration-ok',(case,result.stderr)
                            assert socks_udp(socks,echo.getsockname()[1])==b'udp-payload-ok'
                            print('PASS: '+obfs+' / '+case+' authenticates QUIC, HTTPS/TCP and UDP payloads',flush=True)
                        else:
                            assert result.returncode!=0 and 'integration-ok' not in result.stdout,case
                            print('PASS: '+obfs+' / '+case+' rejects connection',flush=True)
            cfg=m.hy_config(state,work)
            with m.hy_process(binary,'server',cfg,work,'restricted-server-'+obfs):
                time.sleep(.2);socks=m.free_port()
                with m.hy_process(binary,'client',m.hy_client(state,'127.0.0.1',socks),work,'restricted-client'):
                    time.sleep(.45);assert fetch(socks).returncode!=0
                    try:socks_udp(socks,echo.getsockname()[1]);raise AssertionError('Private UDP was not blocked')
                    except socket.timeout:pass
                    print('PASS: production ACL blocks private HTTPS/TCP and UDP destinations ('+obfs+')',flush=True)
        # One real listener, two DNS identities, ordinary TLS verification on both.
        cert=work/'multi.crt';key=work/'multi.key'
        m.run(['openssl','req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:prime256v1','-nodes','-days','1',
               '-subj','/CN=one.example','-addext','subjectAltName=DNS:one.example,DNS:two.example','-keyout',key,'-out',cert])
        multi={**state,'mode':'http','domain':'one.example','domains':['one.example','two.example'],'obfs':'none'}
        cfg=m.hy_config(multi,work);cfg.pop('acme');cfg['tls']={'cert':str(cert),'key':str(key),'sniGuard':'dns-san'}
        cfg['acl']['inline']=['direct(all)']
        with m.hy_process(binary,'server',cfg,work,'multi-server'):
            time.sleep(.3)
            for domain in ['one.example','two.example','wrong.example']:
                socks=m.free_port();client=m.hy_client({**multi,'domain':domain},'127.0.0.1',socks);client['tls']['ca']=str(cert)
                with m.hy_process(binary,'client',client,work,'multi-client'):
                    time.sleep(.45);result=fetch(socks)
                    if domain=='wrong.example':assert result.returncode!=0
                    else:assert result.returncode==0 and result.stdout=='hysteria2-integration-ok'
                print('PASS: multi-domain TLS identity '+domain+(' rejected' if domain=='wrong.example' else ' authenticated'),flush=True)
    finally:
        done.set();echo.close();web.shutdown();web.server_close()
