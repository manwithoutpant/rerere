"""Real listeners with fixture certificates; no public ACME, firewall or systemd mutation."""
import json,os,pathlib,shutil,socket,subprocess,sys,tempfile,time,types
p=pathlib.Path(__file__).resolve().parents[1]/'reality-oneclick.sh'
m=types.ModuleType('m');exec(p.read_text().split("<<'PYTHON'\n",1)[1].rsplit('\nPYTHON',1)[0],m.__dict__)
binary=pathlib.Path(sys.argv[1]).resolve()
def port():
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
with tempfile.TemporaryDirectory() as td:
    root=pathlib.Path(td);m.HY_CACHE=root/'cache';m.HY_CACHE.mkdir()
    domains=['one.example','two.example','three.example'];ports=[port() for _ in domains]
    state={'schema':1,'protocol':'hysteria2','server_ip':'127.0.0.1','mode':'http','domain':domains[0],'domains':domains,'port':ports[0],'domain_ports':dict(zip(domains,ports)),'password':'A'*43,'obfs_password':'B'*43,'obfs':'none'}
    for d in domains:
        target=m.HY_CACHE/'certificates'/'fixture-ca'/d;target.mkdir(parents=True)
        m.run(['openssl','req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:prime256v1','-nodes','-days','1','-subj','/CN='+d,'-addext','subjectAltName=DNS:'+d,'-keyout',target/(d+'.key'),'-out',target/(d+'.crt')])
    cfg=m.hy_config(state,root);cfg.pop('acme');primary=m.HY_CACHE/'certificates'/'fixture-ca'/domains[0]
    cfg['tls']={'cert':str(primary/(domains[0]+'.crt')),'key':str(primary/(domains[0]+'.key'))}
    m.write_json(root/'config.json',cfg);shutil.copy2(binary,root/'hysteria');m.hy_write_listeners(state,root,os.getgid())
    runner=root/'listeners.py';runner.write_text(runner.read_text().replace('children.append(child)',"children.append(child); (base/'test-pids.json').write_text(json.dumps([p.pid for p in children]))"))
    with (root/'supervisor.log').open('w+') as log:
        proc=subprocess.Popen([sys.executable,str(root/'listeners.py')],stdout=log,stderr=log)
        try:
            time.sleep(.8)
            assert proc.poll() is None
            for variant in m.hy_variants(state):
                d=variant['domain'];socks=m.free_port();client=m.hy_client(variant,'127.0.0.1',socks)
                client['tls']['ca']=str(m.HY_CACHE/'certificates'/'fixture-ca'/d/(d+'.crt'))
                with m.hy_process(binary,'client',client,root,'client') as cp:
                    m.wait_port(cp,'127.0.0.1',socks)
                print('PASS real QUIC authentication and verified TLS: '+d+':'+str(variant['port']),flush=True)
            wrong=m.hy_client(m.hy_variants(state)[1],'127.0.0.1',m.free_port());wrong['tls']['sni']='wrong.example';wrong['tls']['ca']=client['tls']['ca']
            with m.hy_process(binary,'client',wrong,root,'wrong-client') as cp:
                time.sleep(.5);assert cp.poll() is not None
            print('PASS wrong identity rejected',flush=True)
            # Simulate certificate renewal on disk without restarting the listener.
            d=domains[1];target=m.HY_CACHE/'certificates'/'fixture-ca'/d
            m.run(['openssl','req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:prime256v1','-nodes','-days','1','-subj','/CN='+d,'-addext','subjectAltName=DNS:'+d,'-keyout',target/(d+'.key'),'-out',target/(d+'.crt')])
            socks=m.free_port();renewed=m.hy_client(m.hy_variants(state)[1],'127.0.0.1',socks)
            renewed['tls']['ca']=str(target/(d+'.crt'))
            with m.hy_process(binary,'client',renewed,root,'renewed-client') as cp:m.wait_port(cp,'127.0.0.1',socks)
            print('PASS renewed certificate loaded without listener restart',flush=True)
            children=json.loads((root/'test-pids.json').read_text())
            assert len(children)==3
            os.kill(int(children[-1]),9);proc.wait(timeout=10);assert proc.returncode!=0
            print('PASS listener failure stops group for systemd restart',flush=True)
        finally:
            proc.terminate();proc.wait(timeout=15)
            if proc.returncode:log.seek(0);print(log.read())
        for n in ports:
            with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:sock.bind(('127.0.0.1',n))
        print('PASS all UDP listeners released on stop',flush=True)
