"""Bulk hostname parsing, filtering, state migration and per-SNI verification."""
import contextlib,copy,io,json,os,pathlib,pty,select,signal,tempfile,time,types,unittest,urllib.parse
from unittest.mock import patch
SCRIPT=pathlib.Path(__file__).resolve().parents[1]/'reality-oneclick.sh'
source=SCRIPT.read_text().split("<<'PYTHON'\n",1)[1].rsplit('\nPYTHON',1)[0]
m=types.ModuleType('bulk');exec(compile(source,str(SCRIPT),'exec'),m.__dict__)

class DomainTests(unittest.TestCase):
    def state(self):return {'schema':1,'protocol':'hysteria2','server_ip':'8.8.8.8','port':443,'mode':'http','domain':'one.example','domains':['one.example','two.example'],'password':'A'*43,'obfs_password':'B'*43,'obfs':'none'}

    def test_normalization_url_case_whitespace_dedup(self):
        domains,bad=m.parse_domain_list(' ONE.Example. , https://two.example/path\none.example;three.example،four.example')
        self.assertEqual(domains,['one.example','two.example','three.example','four.example']);self.assertEqual(bad,[])

    def test_invalid_entries_are_reported(self):
        domains,bad=m.parse_domain_list('one.example *.bad.example ftp://bad.example https://u:p@bad.example bad.example:8443 8.8.8.8 https://bad.example:99')
        self.assertEqual(domains,['one.example']);self.assertEqual(len(bad),6)

    def test_limit_prevents_unbounded_cert_requests(self):
        with self.assertRaisesRegex(m.Failure,'At most 10'):m.parse_domain_list(','.join('x'+str(i)+'.example' for i in range(11)))

    def test_multiline_paste_collects_until_dot(self):
        with patch.object(m,'ask',side_effect=['list','one.example','two.example,ONE.example','.']),patch.object(m,'hy_dns_check'),patch.object(m,'say'):
            self.assertEqual(m.ask_hy_domains('8.8.8.8'),['one.example','two.example'])

    def test_rejected_dns_requires_explicit_partial_acceptance(self):
        def dns(domain,ip):
            if domain=='bad.example':raise m.Failure('wrong A record')
        with patch.object(m,'ask',side_effect=['one.example,bad.example','y']),patch.object(m,'hy_dns_check',side_effect=dns),patch.object(m,'say'):
            self.assertEqual(m.ask_hy_domains('8.8.8.8'),['one.example'])
        with patch.object(m,'ask',side_effect=['one.example,bad.example','']),patch.object(m,'hy_dns_check',side_effect=dns),patch.object(m,'say'):
            with self.assertRaisesRegex(m.Failure,'Re-enter'):m.ask_hy_domains('8.8.8.8')

    def test_no_valid_domain_fails_before_apply(self):
        with patch.object(m,'ask',return_value='bad.example'),patch.object(m,'hy_dns_check',side_effect=m.Failure('DNS failed')),patch.object(m,'say'):
            with self.assertRaisesRegex(m.Failure,'No usable'):m.ask_hy_domains('8.8.8.8')

    def test_multiline_back_and_cancel(self):
        for value,exc in [('b',m.Back),('q',m.Cancelled)]:
            with patch.object(m,'ask',side_effect=['list',value]),patch.object(m,'say'):
                with self.assertRaises(exc):m.ask_hy_domains('8.8.8.8')

    def test_config_and_links_cover_all_domains_one_port(self):
        s=self.state();cfg=m.hy_config(s,pathlib.Path('/tmp/fixture'))
        self.assertEqual(cfg['acme']['domains'],s['domains']);self.assertEqual(cfg['listen'],'0.0.0.0:443')
        links=m.hy_links_text(s).splitlines();self.assertEqual(len(links),2)
        for domain,link in zip(s['domains'],links):
            u=urllib.parse.urlsplit(link);self.assertEqual(u.hostname,domain);self.assertEqual(u.port,443)
            self.assertEqual(urllib.parse.parse_qs(u.query)['sni'],[domain])
            self.assertEqual(urllib.parse.parse_qs(u.query)['insecure'],['0'])

    def test_legacy_single_domain_state_still_valid(self):
        s=self.state();s.pop('domains');m.hy_validate(s)
        self.assertEqual(m.hy_domains(s),['one.example']);self.assertEqual(len(m.hy_links_text(s).splitlines()),1)

    def test_corrupt_domain_state_rejected(self):
        for domains in ([],['one.example','one.example'],['two.example'],'one.example',[None]):
            with self.subTest(domains=domains),self.assertRaises(m.Failure):m.hy_validate(dict(self.state(),domains=domains))

    def test_health_authenticates_every_sni(self):
        with tempfile.TemporaryDirectory() as td:
            p=pathlib.Path(td);m.write_json(p/'state.json',self.state())
            with patch.object(m,'hy_active',return_value=True),patch.object(m,'hy_probe') as probe,patch.object(m,'say'):
                m.hy_health(p)
            auth=[c.args[1]['domain'] for c in probe.call_args_list if c.kwargs.get('egress') is False]
            self.assertEqual(auth,['one.example','two.example'])

    def test_second_domain_tls_failure_rejects_health(self):
        def probe(binary,state,*a,**kw):
            if state['domain']=='two.example':raise m.Failure('wrong certificate for second domain')
        with tempfile.TemporaryDirectory() as td:
            p=pathlib.Path(td);m.write_json(p/'state.json',self.state())
            with patch.object(m,'hy_active',return_value=True),patch.object(m,'hy_probe',side_effect=probe),patch.object(m,'say'):
                with self.assertRaisesRegex(m.Failure,'second domain'):m.hy_health(p,wait=0)

    def test_background_tty_is_rejected_before_suspension(self):
        pid,fd=pty.fork()
        if pid==0:
            child=os.fork()
            if child==0:
                os.setpgid(0,0)
                try:m.ask('must not block: ')
                except m.Failure as e:
                    os.write(2,('EXPECTED: '+str(e)+'\n').encode());os._exit(0)
                os._exit(1)
            _,status=os.waitpid(child,os.WUNTRACED)
            if os.WIFSTOPPED(status):os.kill(child,signal.SIGKILL);os.waitpid(child,0);os._exit(2)
            os._exit(os.waitstatus_to_exitcode(status))
        out=b'';finished=False
        try:
            deadline=time.monotonic()+3
            while time.monotonic()<deadline:
                if select.select([fd],[],[],.1)[0]:
                    try:data=os.read(fd,4096)
                    except OSError:break
                    if not data:break
                    out+=data
            self.assertIn(b'EXPECTED: Menu is not in the foreground',out)
            _,status=os.waitpid(pid,0);finished=True;self.assertEqual(os.waitstatus_to_exitcode(status),0)
        finally:
            os.close(fd)
            if not finished:
                try:os.kill(pid,signal.SIGKILL)
                except ProcessLookupError:pass
                os.waitpid(pid,0)

if __name__=='__main__':unittest.main()
