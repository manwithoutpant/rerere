import base64
import pathlib
import unittest
import urllib.parse


SOURCE = pathlib.Path(__file__).resolve().parents[1] / 'extras-oneclick.sh'
program = SOURCE.read_text().split("<<'PYTHON'\n", 1)[1].rsplit('\nPYTHON', 1)[0]
namespace = {'__name__': 'extras_test'}
exec(compile(program, str(SOURCE), 'exec'), namespace)


class ExtraProfiles(unittest.TestCase):
    def setUp(self):
        self.state = {
            'ip': '8.8.8.8',
            'any_domain': 'one.example.com', 'any_port': 9443, 'any_password': 'secret-one',
            'ss1_domain': 'two.example.net', 'ss1_port': 9444,
            'ss1_password': base64.b64encode(b'a' * 32).decode(),
            'ss2_domain': 'three.example.org', 'ss2_port': 9445,
            'ss2_password': base64.b64encode(b'b' * 32).decode(),
        }

    def test_three_independent_client_links(self):
        links = [namespace['uri'](self.state, kind) for kind in namespace['KINDS']]
        self.assertEqual(len(set(links)), 3)
        self.assertIn('insecure=0', links[0])
        self.assertIn('@one.example.com:9443/', links[0])
        for number, domain, port in ((1, 'two.example.net', 9444), (2, 'three.example.org', 9445)):
            parsed = urllib.parse.urlsplit(links[number])
            self.assertEqual(parsed.hostname, domain)
            self.assertEqual(parsed.port, port)
            plugin = urllib.parse.parse_qs(parsed.query)['plugin'][0]
            self.assertEqual(plugin, f'v2ray-plugin;tls;host={domain};path=/vpn')
        self.assertNotEqual(links[1].split('@')[0], links[2].split('@')[0])

    def test_shadowsocks_server_schema_and_isolated_ports(self):
        for kind in ('ss1', 'ss2'):
            config = namespace['config_ss'](self.state, pathlib.Path('/opt/test'), kind)
            self.assertEqual(config['server_port'], self.state[kind + '_port'])
            self.assertEqual(config['mode'], 'tcp_only')
            self.assertIn('server;tls;host=' + self.state[kind + '_domain'], config['plugin_opts'])
            self.assertNotIn('inbounds', config)

    def test_arbitrary_domains_and_public_endpoint(self):
        self.assertEqual(namespace['valid_domain']('GATEWAY.Example.IR.'), 'gateway.example.ir')
        self.assertEqual(namespace['valid_ip']('8.8.8.8'), '8.8.8.8')
        with self.assertRaises(RuntimeError):
            namespace['valid_ip']('127.0.0.1')
        with self.assertRaises(RuntimeError):
            namespace['valid_domain']('https://example.com')


if __name__ == '__main__':
    unittest.main()
