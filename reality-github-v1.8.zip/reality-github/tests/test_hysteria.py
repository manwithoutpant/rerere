"""Hysteria lifecycle/firewall/TLS fault tests; no host service or firewall is changed."""
import contextlib, copy, io, json, pathlib, shlex, subprocess, tempfile, types, unittest, urllib.parse
from unittest.mock import patch

SCRIPT=pathlib.Path(__file__).resolve().parents[1]/'reality-oneclick.sh'
source=SCRIPT.read_text().split("<<'PYTHON'\n",1)[1].rsplit('\nPYTHON',1)[0]
m=types.ModuleType('hy_installer');exec(compile(source,str(SCRIPT),'exec'),m.__dict__)

class HysteriaTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=pathlib.Path(self.tmp.name)
        self.ctx=contextlib.ExitStack();self.addCleanup(self.ctx.close);self.addCleanup(self.tmp.cleanup)
        root=self.base/'hy';data=self.base/'data'
        for k,v in dict(HY_ROOT=root,HY_CURRENT=root/'current',HY_PREVIOUS=root/'previous',HY_MARKER=root/'.managed-by',
            HY_CACHE=self.base/'cache',HY_UNIT=self.base/'hy.service',HY_SAVED=data/'hy-saved.json',
            DATA=data,RECEIPT=data/'ownership.json',SAVED=data/'saved.json',MANAGER=self.base/'manager',
            ROOT=self.base/'reality',CURRENT=self.base/'reality/current',PREVIOUS=self.base/'reality/previous',
            UNIT=self.base/'reality.service',MARKER=self.base/'reality/.managed-by',
            SECURITY=data/'security.json',FW_PENDING=data/'pending.json',LOCK=self.base/'lock').items():
            self.ctx.enter_context(patch.object(m,k,v))
        self.running=True;self.enabled=True;self.calls=[];self.rules=[];self.ufw=True;self.fail_stop=False
        self.ctx.enter_context(patch.object(m,'run',side_effect=self.fake_run))
        self.ctx.enter_context(patch.object(m.shutil,'which',return_value='/fake/ufw'))
        self.ctx.enter_context(patch.object(m,'say'))
        self.ctx.enter_context(patch.dict(m.os.environ,{'REALITY_INSTALLER_SOURCE':str(SCRIPT)}))
        self.meta=m.receipt_data(create=True)
        self.state={'schema':1,'protocol':'hysteria2','server_ip':'8.8.8.8','port':443,'mode':'self-signed',
            'password':'A'*43,'obfs_password':'B'*43,'obfs':'none','certificate':'fixture cert',
            'private_key':'fixture key','pin':'c'*64,'version':'app/v2.12.3'}
        self.old=root/'releases'/'old';self.old.mkdir(parents=True)
        m.HY_MARKER.write_text(m.OWNER);m.HY_CURRENT.symlink_to(self.old)
        m.HY_UNIT.write_text(m.hy_unit_text());m.MANAGER.write_text(SCRIPT.read_text())
        m.write_json(self.old/'state.json',self.state);m.write_json(self.old/'config.json',m.hy_config(self.state,self.old))
        (self.old/'hysteria').write_text('fixture binary')

    def fake_run(self,args,check=True,**kw):
        a=list(map(str,args));self.calls.append(a);out='';code=0
        if a[0]=='systemctl':
            if a[1]=='is-active':code=0 if self.running else 3
            elif a[1]=='is-enabled':code=0 if self.enabled else 1
            elif a[1]=='stop':
                if self.fail_stop:code=1
                else:self.running=False
            elif a[1] in ('start','restart'):self.running=True
            elif a[1]=='disable':self.enabled=False
            elif a[1]=='enable':self.enabled=True
        elif a[:2]==['ufw','status']:out='Status: '+('active' if self.ufw else 'inactive')
        elif a[:3]==['ufw','show','added']:out='\n'.join(map(shlex.join,self.rules))
        elif a[:2]==['ufw','allow']:self.rules.append(a)
        elif a[:3]==['ufw','--force','delete']:self.rules.remove(['ufw']+a[3:])
        elif a[0]=='getent':code=2
        r=subprocess.CompletedProcess(a,code,out,'injected error' if code else '')
        if code and check:raise m.Failure('injected error')
        return r

    def mock_install(self):
        def prepare():
            m.HY_ROOT.mkdir(exist_ok=True);(m.HY_ROOT/'releases').mkdir(exist_ok=True)
            m.HY_MARKER.write_text(m.OWNER);return 0
        self.ctx.enter_context(patch.object(m,'hy_prepare',side_effect=prepare))
        self.ctx.enter_context(patch.object(m,'hy_preflight'))
        self.ctx.enter_context(patch.object(m,'hy_free_listener'))
        self.ctx.enter_context(patch.object(m.os,'chown'))

    def test_selfsigned_link_is_pinned_and_encodes_ipv6(self):
        s={**self.state,'server_ip':'2606:4700:4700::1111'}
        uri=m.hy_link(s);p=urllib.parse.urlsplit(uri);q=urllib.parse.parse_qs(p.query)
        self.assertEqual(p.hostname,s['server_ip']);self.assertEqual(q['pinSHA256'],[s['pin']])
        self.assertEqual(q['insecure'],['1']);self.assertNotIn('sni',q)

    def test_domain_link_verifies_tls_and_excludes_api_secret(self):
        s={**self.state,'mode':'cloudflare','domain':'vpn.example.com','email':'a@example.com','cf_token':'D'*40}
        uri=m.hy_link(s);q=urllib.parse.parse_qs(urllib.parse.urlsplit(uri).query)
        self.assertEqual(q['insecure'],['0']);self.assertEqual(q['sni'],['vpn.example.com'])
        self.assertNotIn(s['cf_token'],uri);self.assertNotIn('pinSHA256',q)

    def test_bare_insecure_requires_explicit_link_flag(self):
        self.assertNotIn('pinSHA256',m.hy_link(self.state,True))
        with self.assertRaises(m.Failure):m.parse_cli(['hy2-install','--hy2-insecure'])
        self.assertTrue(m.parse_cli(['hy2-links','--hy2-insecure']).hy2_insecure)

    def test_cloudflare_config_has_dns_challenge_and_no_tls_section(self):
        s={**self.state,'mode':'cloudflare','domain':'vpn.example.com','email':'a@example.com','cf_token':'D'*40}
        cfg=m.hy_config(s,self.old)
        self.assertEqual(cfg['acme']['type'],'dns');self.assertNotIn('tls',cfg)
        self.assertEqual(cfg['acme']['dns']['config']['cloudflare_api_token'],s['cf_token'])
        self.assertEqual(m.hy_needed_rules(s),{'443/udp'})

    def test_http_requires_only_udp_plus_http_challenge(self):
        s={**self.state,'mode':'http','domain':'vpn.example.com','email':'a@example.com'}
        self.assertEqual(m.hy_needed_rules(s),{'443/udp','80/tcp'})
        self.assertEqual(m.hy_config(s,self.old)['acme']['type'],'http')

    def test_private_destination_acl_applies_both_protocols(self):
        cfg=m.hy_config(self.state,self.old)
        self.assertIn('reject(169.254.0.0/16)',cfg['acl']['inline'])
        self.assertIn('reject(fc00::/7)',cfg['acl']['inline'])
        self.assertFalse(cfg['disableUDP']);self.assertTrue(cfg['ignoreClientBandwidth'])
        self.assertNotIn('bandwidth',cfg)

    def test_salamander_password_matches_uri_and_both_configs(self):
        s={**self.state,'obfs':'salamander'}
        self.assertEqual(m.hy_config(s,self.old)['obfs'],m.hy_client(s,'127.0.0.1',1234)['obfs'])
        q=urllib.parse.parse_qs(urllib.parse.urlsplit(m.hy_link(s)).query)
        self.assertEqual(q['obfs-password'],[s['obfs_password']])

    def test_active_ufw_keeps_tcp_and_unrelated_rules(self):
        original=[['ufw','allow','443/tcp','comment','web'],['ufw','allow','22/tcp']]
        self.rules=copy.deepcopy(original);m.hy_firewall(self.state)
        self.assertTrue(all(r in self.rules for r in original))
        self.assertEqual(m.receipt_data()['hy_ufw_rules'],['443/udp'])
        m.hy_remove_rules();self.assertEqual(self.rules,original)

    def test_existing_udp_allow_is_never_owned_or_removed(self):
        self.rules=[['ufw','allow','443/udp','comment','admin']]
        m.hy_firewall(self.state);self.assertFalse(m.receipt_data().get('hy_ufw_rules'))
        m.hy_remove_rules();self.assertEqual(len(self.rules),1)

    def test_no_ufw_and_inactive_ufw_do_not_mutate_rules(self):
        m.hy_firewall(self.state,disabled=True);self.assertFalse(self.rules)
        self.ufw=False;m.hy_firewall(self.state);self.assertFalse(self.rules)

    def test_failed_activation_restores_release_unit_and_running_state(self):
        target=m.HY_ROOT/'releases'/'new';target.mkdir();m.write_json(target/'state.json',self.state)
        with patch.object(m,'hy_health',side_effect=m.Failure('bad certificate')):
            with self.assertRaisesRegex(m.Failure,'bad certificate'):m.hy_activate(target)
        self.assertEqual(m.HY_CURRENT.resolve(),self.old);self.assertTrue(self.running);self.assertTrue(self.enabled)
        self.assertEqual(m.HY_UNIT.read_text(),m.hy_unit_text());self.assertFalse(m.HY_PREVIOUS.exists())

    def test_fresh_activation_failure_keeps_redacted_report_after_rollback(self):
        m.HY_CURRENT.unlink();m.HY_UNIT.unlink();self.running=False;self.enabled=False
        target=m.HY_ROOT/'releases'/'fresh';target.mkdir();m.write_json(target/'state.json',self.state)
        with patch.object(m,'hy_health',side_effect=m.Failure('ACME failed '+self.state['password'])):
            with self.assertRaises(m.Failure):m.hy_activate(target)
        self.assertFalse(m.HY_CURRENT.exists());self.assertFalse(m.HY_UNIT.exists());self.assertFalse(self.running)
        report=json.loads((m.DATA/'last-failure.json').read_text())
        self.assertEqual(report['stage'],'Hysteria activation / certificate')
        self.assertNotIn(self.state['password'],report['details'])
        self.assertIn('ACME failed',report['details'])

    def test_edit_stopped_service_keeps_stopped_credentials_and_pin(self):
        self.mock_install();self.running=False
        with patch.object(m,'hy_health') as health,contextlib.redirect_stdout(io.StringIO()):
            m.hy_install(m.parse_cli(['hy2-edit','--hy2-port','8443']))
            health.assert_not_called()
        state=m.hy_state()
        self.assertEqual(state['port'],8443);self.assertFalse(self.running)
        for key in ('password','obfs_password','certificate','private_key','pin'):self.assertEqual(state[key],self.state[key])
        self.assertEqual(m.HY_PREVIOUS.resolve(),self.old)

    def test_failed_edit_cleans_only_new_firewall_rules(self):
        self.mock_install();m.hy_firewall(self.state);rules=copy.deepcopy(self.rules)
        with patch.object(m,'hy_health',side_effect=m.Failure('bad pin')):
            with self.assertRaises(m.Failure):m.hy_install(m.parse_cli(['hy2-edit','--hy2-port','8443']))
        self.assertEqual(self.rules,rules);self.assertEqual(m.HY_CURRENT.resolve(),self.old)

    def test_uninstall_saves_certificates_and_keeps_reality(self):
        m.ROOT.mkdir();(m.ROOT/'sentinel').write_text('keep');m.hy_firewall(self.state)
        m.hy_uninstall(m.parse_cli(['hy2-uninstall','--yes']))
        self.assertEqual(json.loads(m.HY_SAVED.read_text()),self.state)
        self.assertEqual((m.ROOT/'sentinel').read_text(),'keep');self.assertFalse(m.HY_ROOT.exists());self.assertFalse(self.rules)

    def test_stop_failure_prevents_runtime_deletion(self):
        self.fail_stop=True
        with self.assertRaises(m.Failure):m.hy_uninstall(m.parse_cli(['hy2-uninstall','--yes','--purge']))
        self.assertTrue(m.HY_CURRENT.exists());self.assertTrue(m.HY_SAVED.exists())

    def test_symlink_runtime_and_unowned_unit_rejected(self):
        m.HY_UNIT.write_text('foreign unit')
        with self.assertRaisesRegex(m.Failure,'another'):m.hy_guard()
        m.HY_UNIT.unlink();m.HY_UNIT.symlink_to(self.old/'state.json')
        with self.assertRaisesRegex(m.Failure,'symlink'):m.hy_guard()

    def test_token_file_permissions_and_symlink_rejected(self):
        token=self.base/'token';token.write_text('D'*40);token.chmod(0o644)
        with self.assertRaises(m.Failure):m.hy_token(str(token))
        alias=self.base/'token-link';alias.symlink_to(token)
        with self.assertRaises(m.Failure):m.hy_token(str(alias))

    def test_dns_rejects_proxy_address_and_stale_aaaa(self):
        with patch.object(m,'run',return_value=subprocess.CompletedProcess([],0,'["8.8.8.8", "2606:4700::1"]','')):
            with self.assertRaisesRegex(m.Failure,'Disable Cloudflare proxy'):m.hy_dns_check('vpn.example.com','8.8.8.8')

    def test_digest_missing_or_prerelease_download_refused(self):
        for release in ({'tag_name':'app/v2.12.3','prerelease':True},{'tag_name':'app/v2.12.3','assets':[]}):
            with patch.object(m,'curl',return_value=json.dumps(release)):
                with self.assertRaises(m.Failure):m.hy_download(self.base)

    def test_config_and_state_are_not_publicly_readable(self):
        self.mock_install();self.running=False
        old_mask=m.os.umask(0o077)
        try:
            with contextlib.redirect_stdout(io.StringIO()):m.hy_install(m.parse_cli(['hy2-edit','--hy2-port','8443']))
        finally:m.os.umask(old_mask)
        self.assertEqual(m.HY_CURRENT.resolve().stat().st_mode&0o777,0o750)
        self.assertEqual((m.HY_CURRENT/'state.json').stat().st_mode&0o777,0o600)
        self.assertEqual((m.HY_CURRENT/'config.json').stat().st_mode&0o777,0o640)
        self.assertEqual((m.HY_CURRENT/'server.key').stat().st_mode&0o777,0o640)

    def test_pending_firewall_blocks_hysteria_mutation(self):
        m.FW_PENDING.write_text('{}')
        with self.assertRaisesRegex(m.Failure,'pending firewall'):m.dispatch(m.parse_cli(['hy2-edit','--hy2-port','8443']))

    def test_unit_only_grants_bind_capability_and_cache_write(self):
        unit=m.hy_unit_text();self.assertIn('ProtectSystem=strict',unit)
        self.assertIn('ReadWritePaths='+str(m.HY_CACHE),unit);self.assertNotIn('CAP_NET_ADMIN',unit)
        self.assertIn('User=hysteriasvc',unit)

    def test_bulk_domain_edit_preserves_password_and_exports_each_sni(self):
        self.mock_install();self.running=False
        with patch.object(m,'hy_dns_check'),contextlib.redirect_stdout(io.StringIO()) as output:
            m.hy_install(m.parse_cli(['hy2-edit','--hy2-mode','http','--hy2-domain','one.example,two.example']))
        state=m.hy_state();self.assertEqual(state['domains'],['one.example','two.example'])
        self.assertEqual(state['password'],self.state['password']);self.assertFalse(self.running)
        self.assertEqual(len(output.getvalue().splitlines()),2)
        config=json.loads((m.HY_CURRENT/'config.json').read_text())
        self.assertEqual(config['acme']['domains'],state['domains'])
        self.assertEqual(len((m.HY_CURRENT/'links.txt').read_text().splitlines()),2)

    def test_bad_second_domain_leaves_original_release_unchanged(self):
        self.mock_install()
        with patch.object(m,'hy_dns_check',side_effect=[None,m.Failure('DNS mismatch second domain')]):
            with self.assertRaisesRegex(m.Failure,'second domain'):
                m.hy_install(m.parse_cli(['hy2-edit','--hy2-mode','http','--hy2-domain','one.example,two.example']))
        self.assertEqual(m.HY_CURRENT.resolve(),self.old);self.assertEqual(m.hy_state(),self.state)

    def test_reality_purge_retains_hysteria_and_manager(self):
        m.ROOT.mkdir();m.MARKER.write_text(m.OWNER)
        m.uninstall(m.parse_cli(['uninstall','--purge','--yes']))
        self.assertFalse(m.ROOT.exists());self.assertTrue(m.HY_CURRENT.exists())
        self.assertTrue(m.MANAGER.exists());self.assertTrue(m.RECEIPT.exists())

if __name__=='__main__':unittest.main()
