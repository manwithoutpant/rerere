import copy,json,pathlib,tempfile,types,unittest
from unittest.mock import patch
import test_domains
m=test_domains.m

class PortTests(unittest.TestCase):
    def state(self):
        s=test_domains.DomainTests().state();s['domain_ports']={'one.example':443,'two.example':8444};return s
    def test_links_and_firewall_match_mapping(self):
        s=self.state();m.hy_validate(s)
        self.assertIn('@two.example:8444/',m.hy_links_text(s))
        self.assertEqual(m.hy_needed_rules(s),{'443/udp','8444/udp','80/tcp'})
    def test_reject_bad_mapping(self):
        for ports in ({'one.example':443},{'one.example':443,'two.example':443},{'one.example':444,'two.example':8444},{'one.example':443,'two.example':70000}):
            with self.assertRaises(m.Failure):m.hy_validate(dict(self.state(),domain_ports=ports))
    def test_secondary_has_no_acme_owner(self):
        with tempfile.TemporaryDirectory() as td,patch.object(m.os,'chown'):
            p=pathlib.Path(td);m.hy_write_listeners(self.state(),p,0)
            spec=json.loads((p/'listeners.json').read_text())['listeners'][0]
            self.assertEqual(spec['config']['listen'],'0.0.0.0:8444');self.assertNotIn('acme',spec['config'])
            self.assertEqual(spec['domain'],'two.example')
            compile((p/'listeners.py').read_text(),'runner','exec')
    def test_secondary_occupied_aborts(self):
        import socket
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
            sock.bind(('0.0.0.0',0));s=self.state();s['server_ip']='8.8.8.8';s['domain_ports']['two.example']=sock.getsockname()[1]
            with patch.object(m,'listener_rows',return_value=[]),self.assertRaisesRegex(m.Failure,'occupied'):m.hy_free_listener(s)
    def test_cli_explicit_map_and_update_rejection(self):
        self.assertEqual(m.parse_cli(['hy2-edit','--hy2-ports','8443,8444']).hy2_ports,'8443,8444')
        with self.assertRaises(m.Failure):m.parse_cli(['hy2-update','--hy2-ports','8443,8444'])
