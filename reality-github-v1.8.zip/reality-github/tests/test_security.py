"""Fault-injection tests: all firewall, SSH and sysctl operations use a fake host."""
import base64, contextlib, copy, io, json, pathlib, shlex, subprocess, tempfile, types, unittest
from unittest.mock import patch

SCRIPT=pathlib.Path(__file__).resolve().parents[1]/'reality-oneclick.sh'
source=SCRIPT.read_text().split("<<'PYTHON'\n",1)[1].rsplit('\nPYTHON',1)[0]
m=types.ModuleType('security_installer');exec(compile(source,str(SCRIPT),'exec'),m.__dict__)

class SecurityTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=pathlib.Path(self.tmp.name)
        self.addCleanup(self.tmp.cleanup);self.ctx=contextlib.ExitStack();self.addCleanup(self.ctx.close)
        data=self.base/'data';etc=self.base/'etc'
        for key,value in dict(DATA=data,RECEIPT=data/'ownership.json',SAVED=data/'saved-state.json',
            SECURITY=data/'security.json',FW_PENDING=data/'firewall-pending.json',
            MANAGER=self.base/'manager',F2B_JAIL=etc/'fail2ban/jail.d/reality.conf',
            SYSCTL_FILE=etc/'sysctl.d/90-reality.conf',
            FW_TIMER=etc/'systemd/system/reality-firewall-rollback.timer',
            FW_SERVICE=etc/'systemd/system/reality-firewall-rollback.service',LOCK=self.base/'lock',
            FW_FILES=[etc/'default/ufw',etc/'ufw/ufw.conf',etc/'ufw/user.rules',etc/'ufw/user6.rules']).items():
            self.ctx.enter_context(patch.object(m,key,value))
        self.ctx.enter_context(patch.dict(m.os.environ,{'SSH_CONNECTION':'198.51.100.5 45670 192.0.2.5 2222'}))
        self.ctx.enter_context(patch.object(m,'say'))
        self.ctx.enter_context(patch.object(m,'ensure_packages'))
        self.ctx.enter_context(patch.object(m,'promote_manager'))
        self.ctx.enter_context(patch.object(m.shutil,'which',return_value='/fake/tool'))
        self.ctx.enter_context(patch.object(m,'run',side_effect=self.fake_run))
        self.node={'label':'Google','port':2025,'enabled':True}
        self.ctx.enter_context(patch.object(m,'load_state',return_value={'nodes':[self.node]}))
        self.live=set();self.enabled=set();self.rules=[];self.ufw=False;self.calls=[];self.fail=None
        self.jails=set();self.nft_tables='';self.iptables='';self.sock='[::]:2222 (Stream)\n'
        self.installed=False
        self.listeners='tcp LISTEN 0 4096 [::]:2222 [::]:* users:(("systemd",pid=1,fd=100))\n'
        self.listeners+='tcp LISTEN 0 4096 0.0.0.0:2025 0.0.0.0:* users:(("xray",pid=123,fd=3))\n'
        self.listeners+='udp UNCONN 0 0 127.0.0.53:53 0.0.0.0:* users:(("systemd-resolve",pid=44,fd=2))\n'
        self.sysctl={'net.ipv4.tcp_syncookies':'1','net.ipv4.tcp_mtu_probing':'0',
            'net.ipv4.tcp_congestion_control':'cubic','net.core.default_qdisc':'fq_codel',
            'net.ipv4.tcp_available_congestion_control':'reno cubic bbr'}
        for path,content in zip(m.FW_FILES,['IPV6=yes\nDEFAULT_INPUT_POLICY="ACCEPT"\n','ENABLED=no\n','*filter\nCOMMIT\n','*filter\nCOMMIT\n']):
            path.parent.mkdir(parents=True,exist_ok=True);path.write_text(content)
        self.original=[p.read_bytes() for p in m.FW_FILES]
        m.receipt_data(create=True)

    def fake_run(self,args,check=True,**kw):
        a=list(map(str,args));self.calls.append(a);out='';code=0
        if self.fail and self.fail(a):code=1
        elif a[0]=='dpkg-query':out='install ok installed' if self.installed else ''
        elif a[0]=='systemctl':
            op=a[1];service=a[-1]
            if op=='show':out=self.sock
            elif op=='is-active':code=0 if service in self.live else 3
            elif op=='is-enabled':code=0 if service in self.enabled else 1
            elif op in ('enable','disable'):
                if op=='enable':self.enabled.add(service)
                else:self.enabled.discard(service)
                if '--now' in a:
                    if op=='enable':self.live.add(service)
                    else:self.live.discard(service)
            elif op=='start':
                self.live.add(service)
                if service=='fail2ban' and m.F2B_JAIL.exists():self.jails.add('reality-sshd')
            elif op=='stop':self.live.discard(service)
        elif a[:2]==['ufw','status']:out='Status: '+('active' if self.ufw else 'inactive')+'\n'
        elif a[:3]==['ufw','show','added']:out='\n'.join(map(shlex.join,self.rules))
        elif a[:2]==['ufw','allow']:
            self.rules.append(a)
            with m.FW_FILES[2].open('a') as f:f.write(shlex.join(a)+'\n')
        elif a[:3]==['ufw','--force','enable']:self.ufw=True;m.FW_FILES[1].write_text('ENABLED=yes\n')
        elif a[:3]==['ufw','--force','disable']:self.ufw=False;self.rules=[]
        elif a[:2]==['ufw','default']:
            with m.FW_FILES[0].open('a') as f:f.write(shlex.join(a)+'\n')
        elif a[0]=='ss':out=self.listeners
        elif a[0]=='sshd':out='port 22\npasswordauthentication yes\npermitrootlogin yes\n'
        elif a[:3]==['nft','list','tables']:out=self.nft_tables
        elif a[0] in ('iptables-save','ip6tables-save'):out=self.iptables
        elif a[:2]==['sysctl','-n']:out=self.sysctl[a[2]]+'\n'
        elif a[:2]==['sysctl','-w']:
            key,_,value=a[2].partition('=');self.sysctl[key]=value
        elif a[0]=='fail2ban-client':
            if a[1]=='status':
                if len(a)==3:code=0 if a[2] in self.jails else 1
                else:out='Status\n|- Number of jail: '+str(len(self.jails))+'\n`- Jail list: '+','.join(self.jails)
            elif a[1]=='reload':self.jails.add(a[-1])
            elif a[1]=='stop':self.jails.discard(a[2])
        p=subprocess.CompletedProcess(a,code,out,'injected failure' if code else '')
        if code and check:raise m.Failure('injected failure: '+' '.join(a))
        return p

    def setup_firewall(self,*flags):m.firewall_setup(m.parse_cli(['firewall-setup']+list(flags)))

    def test_hysteria_firewall_activation_and_rollback_preserve_receipt(self):
        current=self.base/'hy-current';current.mkdir()
        state={'port':443,'mode':'http','domain':'vpn.example'}
        original=m.receipt_data()
        self.listeners+='udp UNCONN 0 0 0.0.0.0:443 0.0.0.0:* users:(("hysteria",pid=55,fd=4))\n'
        with patch.object(m,'HY_CURRENT',current),patch.object(m,'CURRENT',current),patch.object(m,'hy_state',return_value=state):
            self.setup_firewall()
            self.assertEqual(set(m.receipt_data()['hy_ufw_rules']),{'443/udp','80/tcp'})
            self.assertTrue(any('443/udp' in r for r in self.rules))
            m.firewall_rollback()
        self.assertFalse(self.ufw);self.assertEqual(m.receipt_data(),original)

    def confirm(self,**kw):
        token=json.loads(m.FW_PENDING.read_text())['token']
        m.firewall_confirm(types.SimpleNamespace(token=token,console=kw.get('console',False)))

    def test_detect_socket_ssh_and_ipv6_with_connection_port(self):
        self.assertEqual(m.ssh_ports(),[22,2222])
        self.assertEqual(len(m.listener_rows()),3)
        self.assertTrue(m.listener_rows()[2]['local'])

    def test_unknown_service_stops_before_policy_change(self):
        self.listeners+='tcp LISTEN 0 511 *:8443 *:* users:(("nginx",pid=5,fd=7))\n'
        with self.assertRaisesRegex(m.Failure,'8443/tcp'):self.setup_firewall()
        self.assertFalse(m.FW_PENDING.exists());self.assertFalse(self.ufw)
        self.assertFalse(any(a[:2]==['ufw','default'] for a in self.calls))

    def test_firewall_timer_is_started_before_rules_and_no_udp_vpn_rule(self):
        self.setup_firewall('--allow-ports','443/tcp,8443/udp')
        self.assertTrue(self.ufw);self.assertTrue(m.FW_PENDING.exists())
        timer=self.calls.index(['systemctl','enable','--now',m.FW_TIMER.name])
        policy=self.calls.index(['ufw','default','deny','incoming'])
        self.assertLess(timer,policy)
        specs=[a[2] for a in self.rules]
        self.assertIn('2222/tcp',specs);self.assertIn('22/tcp',specs)
        self.assertIn('2025/tcp',specs);self.assertNotIn('2025/udp',specs)
        self.assertIn('8443/udp',specs)
        self.assertIn('Restart=on-failure',m.FW_SERVICE.read_text())

    def test_rollback_restores_all_four_files_and_receipt(self):
        before=m.receipt_data();self.setup_firewall();m.firewall_rollback()
        self.assertFalse(self.ufw);self.assertFalse(m.FW_PENDING.exists())
        self.assertEqual([p.read_bytes() for p in m.FW_FILES],self.original)
        self.assertEqual(m.receipt_data(),before)
        self.assertFalse(m.FW_TIMER.exists());self.assertFalse(m.FW_SERVICE.exists())

    def test_policy_failure_rolls_back_and_preserves_recovery_if_restore_fails(self):
        self.fail=lambda a:a==['ufw','--force','enable']
        with self.assertRaises(m.Failure):self.setup_firewall()
        self.assertFalse(self.ufw);self.assertFalse(m.FW_PENDING.exists())
        self.assertEqual([p.read_bytes() for p in m.FW_FILES],self.original)

    def test_timer_failure_never_enables_firewall(self):
        self.fail=lambda a:a[:3]==['systemctl','enable','--now']
        with self.assertRaises(m.Failure):self.setup_firewall()
        self.assertNotIn(['ufw','--force','enable'],self.calls)
        self.assertFalse(m.FW_PENDING.exists())

    def test_failed_disable_keeps_recovery_record_for_retry(self):
        self.setup_firewall();self.fail=lambda a:a==['ufw','--force','disable']
        with self.assertRaises(m.Failure):m.firewall_rollback()
        self.assertTrue(m.FW_PENDING.exists());self.assertTrue(m.FW_SERVICE.exists())
        self.fail=None;m.firewall_rollback();self.assertFalse(self.ufw)

    def test_confirmation_requires_new_connection(self):
        self.setup_firewall()
        with self.assertRaisesRegex(m.Failure,'NEW SSH'):self.confirm()
        with patch.dict(m.os.environ,{'SSH_CONNECTION':'198.51.100.5 45671 192.0.2.5 2222'}):self.confirm()
        self.assertTrue(self.ufw);self.assertFalse(m.FW_PENDING.exists())
        self.assertFalse(m.FW_TIMER.exists())

    def test_wrong_token_leaves_watchdog_armed(self):
        self.setup_firewall()
        with self.assertRaises(m.Failure):m.firewall_confirm(types.SimpleNamespace(token='wrong',console=True))
        self.assertTrue(m.FW_TIMER.exists());self.assertTrue(m.FW_PENDING.exists())

    def test_expired_confirmation_rolls_back(self):
        self.setup_firewall()
        with patch.object(m.time,'time',return_value=10**12):
            with self.assertRaisesRegex(m.Failure,'expired'):self.confirm(console=True)
        self.assertFalse(self.ufw);self.assertFalse(m.FW_PENDING.exists())

    def test_pending_activation_blocks_other_mutations(self):
        self.setup_firewall()
        with self.assertRaisesRegex(m.Failure,'pending firewall'):m.dispatch(m.parse_cli(['update']))

    def test_active_ufw_does_not_change_ssh_or_default_policy(self):
        self.ufw=True;self.rules=[['ufw','allow','2222/tcp','comment','user-ssh']]
        self.setup_firewall()
        self.assertIn(['ufw','allow','2222/tcp','comment','user-ssh'],self.rules)
        self.assertFalse(any(a[:2]==['ufw','default'] for a in self.calls))
        self.assertFalse(m.FW_PENDING.exists())

    def test_existing_inactive_rules_are_not_reset(self):
        self.rules=[['ufw','allow','80/tcp']]
        with self.assertRaisesRegex(m.Failure,'already has user rules'):self.setup_firewall()
        self.assertEqual(self.rules,[['ufw','allow','80/tcp']]);self.assertFalse(self.ufw)

    def test_native_firewall_or_docker_prevents_ufw_takeover(self):
        for service in ('nftables','docker','firewalld'):
            with self.subTest(service=service):
                self.live={service}
                with self.assertRaisesRegex(m.Failure,'existing firewall manager'):self.setup_firewall()
                self.assertFalse(m.FW_PENDING.exists())
        self.live=set();self.nft_tables='table inet myfirewall\n'
        with self.assertRaises(m.Failure):self.setup_firewall()

    def test_owned_paths_reject_symlinks(self):
        other=self.base/'other';other.write_text('keep')
        m.FW_FILES[0].unlink();m.FW_FILES[0].symlink_to(other)
        with self.assertRaisesRegex(m.Failure,'symlink'):self.setup_firewall()
        self.assertEqual(other.read_text(),'keep')

    def test_safe_network_tuning_and_idempotent_restore(self):
        before=copy.deepcopy(self.sysctl);m.network_tune();m.network_tune()
        self.assertEqual(self.sysctl['net.ipv4.tcp_mtu_probing'],'1')
        self.assertEqual(self.sysctl['net.ipv4.tcp_congestion_control'],'cubic')
        m.network_restore();self.assertEqual(self.sysctl,before)
        self.assertFalse(m.SYSCTL_FILE.exists());self.assertNotIn('network',m.security_state())

    def test_bbr_opt_in_preserves_original_values_for_restore(self):
        before=copy.deepcopy(self.sysctl);m.network_tune();m.network_tune(True)
        self.assertEqual(self.sysctl['net.ipv4.tcp_congestion_control'],'bbr')
        self.assertEqual(self.sysctl['net.core.default_qdisc'],'fq')
        m.network_restore();self.assertEqual(self.sysctl,before)

    def test_bbr_unavailable_makes_no_sysctl_changes(self):
        self.sysctl['net.ipv4.tcp_available_congestion_control']='reno cubic'
        before=copy.deepcopy(self.sysctl)
        with self.assertRaisesRegex(m.Failure,'does not provide BBR'):m.network_tune(True)
        self.assertEqual(self.sysctl,before);self.assertFalse(m.SYSCTL_FILE.exists())

    def test_sysctl_failure_restores_prior_values_and_file(self):
        before=copy.deepcopy(self.sysctl)
        self.fail=lambda a:a==['sysctl','-w','net.ipv4.tcp_mtu_probing=1']
        with self.assertRaises(m.Failure):m.network_tune()
        self.assertEqual(self.sysctl,before);self.assertFalse(m.SYSCTL_FILE.exists())
        self.assertNotIn('network',m.security_state())

    def test_network_restore_preserves_external_change(self):
        m.network_tune();self.sysctl['net.ipv4.tcp_mtu_probing']='2';m.network_restore()
        self.assertEqual(self.sysctl['net.ipv4.tcp_mtu_probing'],'2')
        self.assertFalse(m.SYSCTL_FILE.exists())

    def test_persistent_conflict_prevents_network_change(self):
        m.SYSCTL_FILE.parent.mkdir(parents=True)
        (m.SYSCTL_FILE.parent/'other.conf').write_text('net.ipv4.tcp_mtu_probing = 0\n')
        before=copy.deepcopy(self.sysctl)
        with self.assertRaisesRegex(m.Failure,'Conflicting persistent'):m.network_tune()
        self.assertEqual(before,self.sysctl)

    def test_ssh_jail_only_bans_ssh_preserves_admin_ip(self):
        m.ssh_protect();text=m.F2B_JAIL.read_text()
        self.assertIn('port = 22,2222',text);self.assertNotIn('2025',text)
        self.assertIn('backend = systemd',text);self.assertIn('198.51.100.5',text)
        self.assertIn('iptables-multiport',text);self.assertIn('reality-sshd',self.jails)
        self.assertFalse(any(a[0] in ('sed','sshd') and '-T' not in a for a in self.calls))

    def test_bad_fail2ban_configuration_restores_old_state(self):
        self.fail=lambda a:a==['fail2ban-client','-t']
        with self.assertRaises(m.Failure):m.ssh_protect()
        self.assertFalse(m.F2B_JAIL.exists());self.assertNotIn('fail2ban',m.security_state())

    def test_existing_sshd_jail_is_not_overridden(self):
        self.installed=True;self.live.add('fail2ban');self.jails.add('sshd');m.ssh_protect()
        self.assertFalse(m.F2B_JAIL.exists());self.assertEqual(self.jails,{'sshd'})

    def test_new_package_stock_jail_is_replaced_by_journal_backed_jail(self):
        def package_install(_):
            self.installed=True;self.live.add('fail2ban');self.enabled.add('fail2ban');self.jails.add('sshd')
        with patch.object(m,'ensure_packages',side_effect=package_install):m.ssh_protect()
        self.assertEqual(self.jails,{'reality-sshd'})
        self.assertIn('[sshd]\nenabled = false',m.F2B_JAIL.read_text())
        m.ssh_unprotect();self.assertNotIn('fail2ban',self.live)
        self.assertNotIn('fail2ban',self.enabled)

    def test_native_firewall_prevents_incompatible_ban_action(self):
        self.live.add('nftables')
        with self.assertRaises(m.Failure):m.ssh_protect()
        self.assertFalse(m.F2B_JAIL.exists())

    def test_unprotect_preserves_other_jails_and_service(self):
        m.ssh_protect();self.jails.add('web');m.ssh_unprotect()
        self.assertEqual(self.jails,{'web'});self.assertIn('fail2ban',self.live)
        self.assertFalse(m.F2B_JAIL.exists())

    def test_unprotect_stops_new_empty_daemon(self):
        m.ssh_protect();m.ssh_unprotect()
        self.assertNotIn('fail2ban',self.live);self.assertNotIn('fail2ban',self.enabled)

    def test_modified_security_file_is_never_deleted(self):
        m.network_tune();m.SYSCTL_FILE.write_text('external\n')
        with self.assertRaises(m.Failure):m.security_remove()
        self.assertEqual(m.SYSCTL_FILE.read_text(),'external\n');self.assertTrue(m.SECURITY.exists())

    def test_parser_rejects_misplaced_security_flags(self):
        for args in (['links','--bbr'],['update','--secure'],['list','--token','aaa'],['network-tune','--allow-ports','80/tcp']):
            with self.subTest(args=args),self.assertRaises(m.Failure):m.parse_cli(args)

    def test_secure_install_defers_fail2ban_until_new_connection_confirmation(self):
        m.secure_install(m.parse_cli(['install','--secure']))
        self.assertTrue(m.FW_PENDING.exists());self.assertFalse(m.F2B_JAIL.exists())
        self.assertTrue(m.SYSCTL_FILE.exists())
        with patch.dict(m.os.environ,{'SSH_CONNECTION':'198.51.100.5 45671 192.0.2.5 2222'}):self.confirm()
        self.assertTrue(m.F2B_JAIL.exists());self.assertIn('reality-sshd',self.jails)

    def test_secure_install_with_active_firewall_does_not_need_confirmation(self):
        self.ufw=True;m.secure_install(m.parse_cli(['install','--secure']))
        self.assertFalse(m.FW_PENDING.exists());self.assertTrue(m.F2B_JAIL.exists())

    def test_secure_install_honors_no_ufw(self):
        m.secure_install(m.parse_cli(['install','--secure','--no-ufw']))
        self.assertFalse(m.FW_PENDING.exists());self.assertTrue(m.F2B_JAIL.exists())
        self.assertFalse(any(a[0]=='ufw' for a in self.calls))

if __name__=='__main__':unittest.main()
