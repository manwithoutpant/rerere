"""Guided setup and actual PTY regression tests; all deployment operations are isolated."""
import contextlib, copy, json, os, pathlib, pty, select, signal, socket, tempfile, termios, time, types, unittest
from unittest.mock import patch
SCRIPT=pathlib.Path(__file__).resolve().parents[1]/'reality-oneclick.sh'
source=SCRIPT.read_text().split("<<'PYTHON'\n",1)[1].rsplit('\nPYTHON',1)[0]
m=types.ModuleType('setup_installer');exec(compile(source,str(SCRIPT),'exec'),m.__dict__)

class SetupTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.base=pathlib.Path(self.tmp.name)
        self.ctx=contextlib.ExitStack();self.addCleanup(self.ctx.close)
        for name,path in {'CURRENT':'r/current','HY_CURRENT':'h/current','DATA':'data','RECEIPT':'data/ownership.json','SAVED':'data/saved.json','FW_PENDING':'data/pending.json'}.items():
            self.ctx.enter_context(patch.object(m,name,self.base/path))
        self.calls=[];self.output=[]
        self.ctx.enter_context(patch.object(m,'say',side_effect=self.output.append))
        self.ctx.enter_context(patch.object(m,'public_ip',return_value='8.8.8.8'))
        self.ctx.enter_context(patch.object(m,'probe_target'))
        self.ctx.enter_context(patch.object(m,'hy_dns_check'))
        self.ctx.enter_context(patch.object(m,'listener_rows',return_value=[]))
        self.ctx.enter_context(patch.object(m,'port_available',return_value=True))
        self.ctx.enter_context(patch.object(m,'dispatch',side_effect=lambda args:self.calls.append(args)))

    def run_answers(self,answers,**kw):
        with patch.object(m,'ask',side_effect=answers):m.setup_wizard(**kw)

    def test_default_both_distinct_ports_domain_and_no_email(self):
        self.run_answers(['','','','','','','vpn.example.com','','',''])
        self.assertEqual([a.command for a in self.calls],['install','hy2-install'])
        self.assertEqual(self.calls[0].ports,'443');self.assertEqual(self.calls[1].hy2_port,8443)
        self.assertEqual(self.calls[1].hy2_domain,'vpn.example.com');self.assertIsNone(self.calls[1].hy2_email)
        self.assertEqual(self.calls[0].domains,'www.google.com')

    def test_complete_zip_adds_extras_without_replacing_existing_protocol_tasks(self):
        original_file=pathlib.Path.is_file
        original_link=pathlib.Path.is_symlink
        def is_file(path):
            return True if str(path)=='/usr/local/sbin/reality-extras' else original_file(path)
        seen={'extras':0}
        def is_link(path):
            if str(path)=='/opt/reality-extras/current':
                seen['extras']+=1
                return seen['extras']>1
            return original_link(path)
        import subprocess
        with patch.object(pathlib.Path,'is_file',is_file),patch.object(pathlib.Path,'is_symlink',is_link), \
             patch.object(m.subprocess,'run',return_value=subprocess.CompletedProcess([],0)) as run:
            self.run_answers(['4','','','','','','vpn.example.com','','',''])
        self.assertEqual([a.command for a in self.calls],['install','hy2-install'])
        self.assertTrue(any(c.args[0]==['/usr/local/sbin/reality-extras','setup'] for c in run.call_args_list))

    def test_invalid_port_and_bad_target_retry_same_step(self):
        m.probe_target.side_effect=[m.Failure('TLS target not suitable'),None]
        self.run_answers(['2','','','70000','443','bad.example','',''])
        self.assertEqual(len(self.calls),1);self.assertEqual(self.calls[0].domains,'www.google.com')
        self.assertTrue(any('Port must' in line for line in self.output))

    def test_back_from_port_to_domain_and_recheck_dns(self):
        self.run_answers(['3','','','first.example','b','second.example','8443','',''])
        self.assertEqual(self.calls[0].hy2_domain,'second.example');self.assertEqual(self.calls[0].hy2_port,8443)
        self.assertEqual(m.hy_dns_check.call_count,2)

    def test_wrong_dns_retries_without_mutation(self):
        m.hy_dns_check.side_effect=[m.Failure('DNS must resolve only to endpoint'),None]
        self.run_answers(['3','','','wrong.example','vpn.example','','',''])
        self.assertEqual(len(self.calls),1);self.assertEqual(self.calls[0].hy2_domain,'vpn.example')

    def test_back_changes_protocol_selection(self):
        self.run_answers(['','b','2','','','','','',''])
        self.assertEqual([a.command for a in self.calls],['install'])

    def test_cancel_has_no_deployment(self):
        self.run_answers(['','','q']);self.assertEqual(self.calls,[])

    def test_selfsigned_path_does_not_ask_domain(self):
        self.run_answers(['3','','3','','',''])
        self.assertEqual(self.calls[0].hy2_mode,'self-signed');self.assertIsNone(self.calls[0].hy2_domain)
        m.hy_dns_check.assert_not_called()

    def test_cloudflare_path_does_not_collect_token_in_draft(self):
        self.run_answers(['3','','2','vpn.example','','',''])
        self.assertEqual(self.calls[0].hy2_mode,'cloudflare');self.assertIsNone(self.calls[0].hy2_token_file)

    def test_existing_reality_kept_while_hysteria_installs(self):
        m.CURRENT.mkdir(parents=True)
        with patch.object(m,'load_state',return_value={'server_ip':'8.8.8.8'}),patch.object(m,'show_links'):
            self.run_answers(['','','','vpn.example','','',''])
        self.assertEqual([a.command for a in self.calls],['hy2-install'])

    def test_four_profiles_are_collected_sequentially(self):
        self.run_answers(['2','','4','','','','','','','','','',''])
        self.assertEqual(len(self.calls[0].ports.split(',')),4)
        self.assertEqual(len(set(self.calls[0].ports.split(','))),4)

    def test_http_rejects_realty_port80_before_mutation(self):
        self.run_answers(['','','','80','','','vpn.example','b','2','vpn.example','','',''])
        self.assertEqual(self.calls[1].hy2_mode,'cloudflare')
        self.assertTrue(any('conflicts' in x for x in self.output))

    def test_busy_http_port_allows_back_to_dns_challenge(self):
        m.listener_rows.return_value=[{'proto':'tcp','port':80}]
        self.run_answers(['3','','','vpn.example','b','2','vpn.example','','',''])
        self.assertEqual(self.calls[0].hy2_mode,'cloudflare')

    def test_partial_failure_is_not_reported_as_complete(self):
        def deploy(args):
            self.calls.append(args)
            if args.command=='hy2-install':raise m.Failure('certificate issuance failed')
        m.dispatch.side_effect=deploy
        self.run_answers(['','','','','','','vpn.example','','',''])
        self.assertEqual([a.command for a in self.calls],['install','hy2-install'])
        self.assertTrue(any('SETUP NEEDS ATTENTION' in x for x in self.output))
        self.assertFalse(any('SETUP COMPLETE' in x for x in self.output))

    def test_guarded_security_requests_ssh_protection_after_confirmation(self):
        def deploy(args):
            self.calls.append(args)
            if args.command=='firewall-setup':m.FW_PENDING.parent.mkdir(exist_ok=True);m.FW_PENDING.write_text('{}')
        m.dispatch.side_effect=deploy
        self.run_answers(['3','','3','','1',''])
        firewall=next(a for a in self.calls if a.command=='firewall-setup')
        self.assertTrue(firewall.secure)
        self.assertNotIn('ssh-protect',[a.command for a in self.calls])

    def test_optional_email_still_rejects_invalid_value(self):
        state={'schema':1,'protocol':'hysteria2','server_ip':'8.8.8.8','port':443,'mode':'http','domain':'vpn.example','password':'a'*43,'obfs_password':'b'*43,'obfs':'none'}
        self.assertEqual(m.hy_validate(state),state)
        self.assertEqual(m.hy_config(state,self.base)['acme']['email'],'')
        with self.assertRaises(m.Failure):m.hy_validate(dict(state,email='invalid'))

    def test_failure_report_redacts_secrets_and_is_private(self):
        state={'password':'TopSecretPassword','cf_token':'HiddenCloudflareToken'}
        m.remember_failure('test','TopSecretPassword HiddenCloudflareToken hysteria2://abc@host',state)
        report=m.DATA/'last-failure.json';content=report.read_text()
        self.assertNotIn('TopSecret',content);self.assertNotIn('HiddenCloud',content);self.assertNotIn('abc@host',content)
        self.assertEqual(report.stat().st_mode&0o777,0o600)

    def test_tcp_udp_same_number_is_available_independently(self):
        with socket.socket() as s:
            s.bind(('127.0.0.1',0));port=s.getsockname()[1]
            # Call the real function hidden behind the per-test network mock.
            namespace={};exec(source,namespace)
            self.assertFalse(namespace['port_available'](port,'tcp','127.0.0.1'))
            self.assertTrue(namespace['port_available'](port,'udp','127.0.0.1'))

class RealTerminalTests(unittest.TestCase):
    def run_pty(self,child,answers,timeout=6):
        pid,fd=pty.fork()
        if pid==0:
            try:
                # Matches an installer launched using <<'BASH': exhausted stdin.
                os.dup2(os.open('/dev/null',os.O_RDONLY),0)
                child();os.write(2,b'CHILD_OK\n');os._exit(0)
            except BaseException:
                import traceback;traceback.print_exc();os._exit(1)
        out=b'';sent=0;finished=False;deadline=time.monotonic()+timeout
        try:
            while time.monotonic()<deadline:
                if select.select([fd],[],[],.05)[0]:
                    try:chunk=os.read(fd,16384)
                    except OSError:break
                    if not chunk:break
                    out+=chunk
                    # Each entry is a distinct prompt, consumed once in sequence.
                    if sent<len(answers) and answers[sent][0] in out:
                        os.write(fd,answers[sent][1]);sent+=1
                    if b'CHILD_OK' in out:break
            self.assertIn(b'CHILD_OK',out,out.decode(errors='replace'))
            _,status=os.waitpid(pid,0);finished=True;self.assertEqual(os.waitstatus_to_exitcode(status),0)
            return out
        finally:
            os.close(fd)
            if not finished:
                try:os.kill(pid,signal.SIGKILL)
                except ProcessLookupError:pass
                os.waitpid(pid,0)

    def test_cr_enter_normalizes_and_restores_tty_flags(self):
        def child():
            fd=os.open('/dev/tty',os.O_RDWR);before=termios.tcgetattr(fd);before[0]&=~termios.ICRNL;termios.tcsetattr(fd,termios.TCSANOW,before)
            assert m.ask('FIRST: ')=='1';assert termios.tcgetattr(fd)==before
            assert m.ask('SECOND: ')=='';assert termios.tcgetattr(fd)==before
        self.run_pty(child,[(b'FIRST: ',b'1\r'),(b'SECOND: ',b'\r')])

    def test_pasted_answers_are_not_lost_between_prompts(self):
        def child():
            assert [m.ask(x+': ') for x in ('ONE','TWO','THREE')]==['first','second','third']
        self.run_pty(child,[(b'ONE: ',b'first\nsecond\nthird\n')])

    def test_hidden_input_does_not_echo_secret(self):
        def child():assert m.ask('SECRET: ',secret=True)=='do-not-print-this'
        out=self.run_pty(child,[(b'SECRET: ',b'do-not-print-this\r')]);self.assertNotIn(b'do-not-print-this',out)

    def test_hysteria_menu_install_reaches_domain_and_returns_on_cancel(self):
        def child():
            with tempfile.TemporaryDirectory() as td,contextlib.ExitStack() as ctx:
                for k in ('CURRENT','HY_CURRENT'):ctx.enter_context(patch.object(m,k,pathlib.Path(td)/k))
                ctx.enter_context(patch.object(m,'hy_status'));ctx.enter_context(patch.object(m,'public_ip',return_value='8.8.8.8'))
                m.hy_menu()
        out=self.run_pty(child,[(b'Select Hysteria action: ',b'1\r'),(b'Public server IP;',b'\r'),
            (b'Hysteria certificate method',b'\r'),(b'Your Hysteria domain',b'q\r'),(b'Setup cancelled before installation.',b'0\r')])
        self.assertIn(b'Your Hysteria domain',out)

    def test_full_both_wizard_pty_with_redirected_stdin(self):
        def child():
            with tempfile.TemporaryDirectory() as td,contextlib.ExitStack() as ctx:
                for k in ('CURRENT','HY_CURRENT','FW_PENDING'):ctx.enter_context(patch.object(m,k,pathlib.Path(td)/k))
                for k,v in {'public_ip':'8.8.8.8','port_available':True,'listener_rows':[]}.items():ctx.enter_context(patch.object(m,k,return_value=v))
                for k in ('probe_target','hy_dns_check'):ctx.enter_context(patch.object(m,k))
                calls=[];ctx.enter_context(patch.object(m,'dispatch',side_effect=lambda a:calls.append(a.command)))
                m.setup_wizard();assert calls==['install','hy2-install'],calls
        self.run_pty(child,[(b'Install protocols',b'\r'),(b'Public server IP;',b'\r'),(b'Number of REALITY profiles',b'\r'),
          (b'REALITY profile 1 TCP port',b'\r'),(b'REALITY profile 1 target hostname',b'\r'),(b'Hysteria certificate method',b'\r'),
          (b'Your Hysteria domain',b'vpn.example\r'),(b'Hysteria vpn.example UDP port',b'\r'),(b'Host protection [',b'\r'),(b'Apply these settings?',b'\r')])

if __name__=='__main__':unittest.main()
